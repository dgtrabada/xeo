/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.util.Vector;

public class statistic {
    double a0,a1; //  y= a0 + a1*x
    double b0,b1,b2; // y=b0 + b1*x +b2*x**2
    double S0,S1,S2,S3,S4;
    double Sy,Sxy,Sx2y;
    double RMS;
    double x,y;
    Vector Datos = new Vector();
    Vector X = new Vector();
    Vector Y = new Vector();
    reader reader = new reader();
    String salida;
    
    /** Creates a new instance of statistic */
    public statistic() {
        x=0; y=0;
        a0=0;a1=0;
        b0=0;b1=0;b2=0;
        S0=0;S1=0; S2=0;S3=0;S4=0;
        Sy=0;Sxy=0;Sx2y=0;
        RMS=0;
    }
    void Load(){   //cargamos un vector que tiene el archivo que queremos leeer, dos columnas x,y
        String str="";
        for(int i = 0; i<Datos.size() ; i++){
            str=Datos.get(i).toString();
            if(!str.trim().equals("")&& reader.nCol(str)>1)
                try{
                    x = Double.valueOf(reader.readCol(1,str)).doubleValue();
                    y = Double.valueOf(reader.readCol(2,str)).doubleValue();
                    X.add((double) x);
                    Y.add(y);
                }catch(NumberFormatException ex){System.out.println("error read col "+i);}
        }
        
    }
    
    void filtro(double PORCNT){
        String str="";
        double y_min=0;
        int i_min=0;
        for(int i = 0; i<Datos.size() ; i++){
            str=Datos.get(i).toString();
            if(!str.trim().equals("")&& reader.nCol(str)>1)
                try{
                    x = Double.valueOf(reader.readCol(1,str)).doubleValue();
                    y = Double.valueOf(reader.readCol(2,str)).doubleValue();
                    if(i==0) y_min=y;
                    else if(y_min>y) {y_min=y;i_min=i;}
                }catch(NumberFormatException ex){System.out.println("error read col "+i);}
        }
        //pasamos filtro:
        X.clear();
        Y.clear();
        double ini=(i_min*(100-PORCNT)/100-1);
        double fin=(i_min+PORCNT*(Datos.size()-i_min)/100)+1;
        for(int i = 0; i<Datos.size() ; i++){
            str=Datos.get(i).toString();
            if(!str.trim().equals("")&& reader.nCol(str)>1)
                try{
                    x = Double.valueOf(reader.readCol(1,str)).doubleValue();
                    y = Double.valueOf(reader.readCol(2,str)).doubleValue();
                    if(i>=ini && i<=fin) {
                        X.add(x);
                        Y.add(y);
                        //  System.out.println(x+" "+y+" "+i_min+" "+i+" "+ini+" "+fin );
                    }
                }catch(NumberFormatException ex){System.out.println("error read col "+i);}
        }
    }
    
    
//----SUMATORIOS-----
    
    double Suma(Vector A, int j){
        double suma=0;
        for(int i=0;i<A.size();i++){
            suma+=Math.pow(Double.valueOf(A.get(i).toString()).doubleValue(),j);
        }
        return suma;
    }
    double Suma(Vector A, int j, Vector B, int k){
        double suma=0;
        for(int i=0;i<A.size();i++){
            suma+=Math.pow(Double.valueOf(A.get(i).toString()).doubleValue(),j)*
                    Math.pow(Double.valueOf(B.get(i).toString()).doubleValue(),k);
        }
        return suma;
    }
    
    
    void RectaMinimosCuadrados(){
     /*
     -------- MINIMOS CUADRADOS ----------
     y= a0 + a1*x
      
     Suma{X**0}*a0 + Suma{X**1}*a1 = Suma{Y}  = S0*a0 + S1*a1 = Sy
     Suma{X**1}*a0 + Suma{X**2}*a1 = Suma{XY} = S1*a0 + S2*a1 = Sxy
      */
        // primero Load() filtro(%);
        S0=Suma(X,0);
        S1=Suma(X,1);
        S2=Suma(X,2);
        Sy=Suma(Y,1);
        Sxy=Suma(X,1,Y,1);
        double C11,C12,C21,C22,A1,A2;
        C11=S0;    C12=S1;    A1=Sy;
        C21=S1;    C22=S2;    A2=Sxy;
        C11-=C21*C12/C22;    A1-=A2*C12/C22;   C12-=C22*C12/C22;  //ojo al orden
        C22-=C12*C21/C11;    A2-=A1*C21/C11;   C21-=C11*C21/C11;  //ojo al orden
        a0=A1/C11;
        a1=A2/C22;
        double E=0;
        for(int i=0;i<Y.size();i++){
            double Yk=0,Xk=0;
            Yk=Double.valueOf(Y.get(i).toString()).doubleValue();
            Xk=Double.valueOf(X.get(i).toString()).doubleValue();
            E+=Math.pow(a1*Xk+a0 - Yk,2);
        }
        RMS=Math.pow(E/Y.size(),0.5);
        salida="y= a0 + a1*x \n";
        salida+="a0 = "+a0+"\n";
        salida+="a1 = "+a1+"\n";
        salida+="RMS = "+RMS;
    }
    
    void ParabolaMinimosCuadrados(){
     /*
     -------- MINIMOS CUADRADOS ----------
    y=b0 + b1*x +b2*x**2
      
     S0*b0 + S1*b1 + S2*b2 = Sy
     S1*b1 + S2*b2 + S3*b3 = Sxy
     S2*b2 + S3*b3 + S4*b4 = Sx2y
      */
        //   Load() o filtro(%)
        S0=Suma(X,0);
        S1=Suma(X,1);
        S2=Suma(X,2);
        S3=Suma(X,3);
        S4=Suma(X,4);
        Sy=Suma(Y,1);
        Sxy=Suma(X,1,Y,1);
        Sx2y=Suma(X,2,Y,1);
        double C11,C12,C13,C21,C22,C23,C31,C32,C33,A1,A2,A3;
        C11=S0;    C12=S1;    C13=S2;     A1=Sy;
        C21=S1;    C22=S2;    C23=S3;     A2=Sxy;
        C31=S2;    C32=S3;    C33=S4;     A3=Sx2y;
        C22-=C32*C23/C33;   C21-=C31*C23/C33;    A2-=A3*C23/C33;     C23-=C33*C23/C33;
        C12-=C32*C13/C33;   C11-=C31*C13/C33;    A1-=A3*C13/C33;     C13-=C33*C13/C33;
        C11-=C21*C12/C22;   C13-=C23*C12/C22;    A1-=A2*C12/C22;     C12-=C22*C12/C22;
        C31-=C21*C32/C22;   C33-=C23*C32/C22;    A3-=A2*C32/C22;     C32-=C22*C32/C22;
        C22-=C12*C21/C11;   C23-=C13*C21/C11;    A2-=A1*C21/C11;     C21-=C11*C21/C11;
        C32-=C12*C31/C11;   C33-=C13*C31/C11;    A3-=A1*C31/C11;     C31-=C11*C31/C11;
        b0=A1/C11;
        b1=A2/C22;
        b2=A3/C33;
        double E=0;
        for(int i=0;i<Y.size();i++){
            double Yk=0,Xk=0;
            Yk=Double.valueOf(Y.get(i).toString()).doubleValue();
            Xk=Double.valueOf(X.get(i).toString()).doubleValue();
            E+=Math.pow(b2*Xk*Xk+b1*Xk+b0 - Yk,2);
        }
        // y=b0 + b1*x +b2*x**2
        RMS=Math.pow(E/Y.size(),0.5);
        salida="b0 + b1*x +b2*x**2 \n";
        salida+="b0 = "+b0+"\n";
        salida+="b1 = "+b1+"\n";
        salida+="b2 = "+b2+"\n";
        salida+="RMS = "+RMS;
    }
    
    
    void print(){
        System.out.println(salida);
    }
    
   /*
       //ajuste a parabola  y = Ax^2 + Bx + C
       void AjustarParabola(double x0,double y0,double x1,double y1,double x2,double y2){
        A=(y2*(x1-x0)+y1*(x0-x2)+y0*(x2-x1))/(x2*x2*(x1-x0)+x1*x1*(x0-x2)+x0*x0*(x2-x1));
        B=((y1-y0)-A*(x1*x1-x0*x0))/(x1-x0);
        C=y0-A*x0*x0-B*x0;
        X_min=-B/2/A;
        Y_min=A*X_min*X_min+B*X_min+C;
    }
    */
    
}
