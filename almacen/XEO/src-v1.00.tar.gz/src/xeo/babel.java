/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.Vector;

public class babel {
    String path;  // work path (project use at the this moument)
    int sort; // unknown, fireball, CASTEP ...
    File inputFile;
    
    String [] nameSort={"unknown","xyz","castep","abinit","vasp","fireball"};   //put first the new ...
    String [] nameSign={"","xyz",".cell",".in","POSCAR","script.input"}; //finish in nameSign
    //Importante el 0 y el 1 es para unknown y xyz : NO PONER NADA ANTES
    
    read_fireball read_fireball = new read_fireball();
    read_castep read_castep = new read_castep();
    read_abinit read_abinit = new read_abinit();
    read_vasp read_vasp = new read_vasp();
    
    info_bas infBas = new info_bas();
    
    boolean Error;
    String Error_out;
    
    File aux;
    File [] fileList;
    Vector out = new Vector();
    
    public babel() {
        Error=false;
        path="./";
        aux=null;
    }
    
    ///-----------------
    //----------- LEER ARCHIVOS----------------------
    
    void loadBabel(){
        SORT();
        INPUT();
    }
    
    void SORT(){
        sort=0;
        fileList = new File(path).listFiles();
        //ls=System.out.println(fileList[idx].getName());
        for (int idx = 0; idx < fileList.length; idx++)
            for(int i = 2; i<nameSign.length; i++) //i=0 unknown and i=1 xyz
                if(fileList[idx].getName().length()>=nameSign[i].length())
                    if((fileList[idx].getName().substring(fileList[idx].getName().length()-nameSign[i].length(),fileList[idx].getName().length())).equals(nameSign[i]))
                        sort=i;
        
        if(sort==0) //miramos en este caso si hay algun xyz
            for (int idx = 0; idx < fileList.length; idx++)
                if(fileList[idx].getName().length()>4)
                    if((fileList[idx].getName().substring(fileList[idx].getName().length()-4,fileList[idx].getName().length())).equals(".xyz"))
                        sort=1;
    }
    
    void INPUT(){
        fileList = new File(path).listFiles();
        for (int idx = 0; idx < fileList.length; idx++)
            if(fileList[idx].getName().length()>=nameSign[sort].length())
                if((fileList[idx].getName().substring(fileList[idx].getName().length()-nameSign[sort].length(),fileList[idx].getName().length())).equals(nameSign[sort]))
                    inputFile=fileList[idx];
    }
    
    
    File getOutput(){
        aux=null;
        fileList = new File(path).listFiles();
        //ls=System.out.println(fileList[idx].getName());
        if(nameSort[sort].equals("fireball")) {
            for (int idx = 0; idx < fileList.length; idx++)
                if(!fileList[idx].isDirectory()) {
                try{
                    BufferedReader in = new BufferedReader(new FileReader(fileList[idx].getAbsolutePath()));
                    String str=in.readLine();
                    if(infBas.cadena.nCol(str)>=3)
                        if(infBas.cadena.readCol(3,str).trim().equals("FIREBALL"))
                            aux=fileList[idx];
                    in.close();
                }catch (IOException oe) {System.out.println("error read basfile");}
                }
        }
        if(nameSort[sort].equals("castep"))
            for (int idx = 0; idx < fileList.length; idx++)
                if(!fileList[idx].isDirectory())
                    if(fileList[idx].getName().length()>7)
                        if(fileList[idx].getName().substring(fileList[idx].getName().length()-7,fileList[idx].getName().length()).equals(".castep"))
                            aux=fileList[idx];
        
        if(nameSort[sort].equals("xyz"))
            for (int idx = 0; idx < fileList.length; idx++)
                if(!fileList[idx].isDirectory())
                    if(fileList[idx].getName().length()>4)
                        if(fileList[idx].getName().substring(fileList[idx].getName().length()-4,fileList[idx].getName().length()).equals(".xyz"))
                            aux=fileList[idx];
        return  aux;
    }
    
    File getXYZ(){
        aux=null;
        fileList = new File(path).listFiles();
        for (int idx = 0; idx < fileList.length; idx++)
            if(fileList[idx].getName().length()>4)
                if((fileList[idx].getName().substring(fileList[idx].getName().length()-4,fileList[idx].getName().length())).equals(".xyz"))
                    aux=fileList[idx];
        return  aux;
    }
    
    void load_Values(){
        Error=false;
        if(nameSort[sort].equals("fireball")) {
            read_fireball.loadScript(path);
            read_fireball.load_bas();
            read_fireball.load_lvs();
            read_fireball.load_frag();
            read_fireball.load_charges();  //no read unlesss ....
            infBas.bas=read_fireball.bas;
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    infBas.lvs[i][j] = read_fireball.lvs[i][j];
            Error=read_fireball.Error;
            Error_out=read_fireball.Error_out;
        }
        if(nameSort[sort].equals("castep")){
            read_castep.LoadCell(inputFile);
            infBas.bas=read_castep.bas;
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    infBas.lvs[i][j] = read_castep.lvs[i][j];
            Error=read_castep.Error;
            Error_out=read_castep.Error_out;
        }
        if(nameSort[sort].equals("abinit")){
            read_abinit.Load(inputFile);
            infBas.bas=read_abinit.bas;
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    infBas.lvs[i][j] = read_abinit.lvs[i][j];
            Error=read_abinit.Error;
            Error_out=read_abinit.Error_out;
        }
        if(nameSort[sort].equals("vasp")){
            read_vasp.Load(inputFile);
            infBas.bas=read_vasp.bas;
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    infBas.lvs[i][j] = read_vasp.lvs[i][j];
            Error=read_vasp.Error;
            Error_out=read_vasp.Error_out;
        }
        
        if(nameSort[sort].equals("xyz")) {
            for (int idx = 0; idx < fileList.length; idx++)
                if(fileList[idx].getName().length()>4)
                    if((fileList[idx].getName().substring(fileList[idx].getName().length()-4,fileList[idx].getName().length())).equals(".xyz"))
                        aux=fileList[idx];
            firstStepXYZ(aux);
        }
        
        if(infBas.seeCell_Vol) infBas.Adj_Vol();
        if(infBas.seeCell_ijk) infBas.Adj_ijk();
        if(infBas.seeBond) infBas.load_enlaces();
    }
    
    Vector save_positions(){
        out.clear();
        if(nameSort[sort].equals("fireball")) {
            read_fireball.res=1;
            inputFile=read_fireball.basfile;
            read_fireball.bas=infBas.bas;
            out=read_fireball.outbas();
        }
        
        if(nameSort[sort].equals("castep")) {
            read_castep.bas=infBas.bas;
            out=read_castep.savePos(inputFile);
        }
        
        if(nameSort[sort].equals("vasp")) {
            read_vasp.bas=infBas.bas;
            out=read_vasp.savePosFix(inputFile,true);
        }
        
        if(nameSort[sort].equals("xyz")) {
            out=infBas.outXYZ();
        }
        
        return out;
    }
    Vector save_fix(){
        out.clear();
        if(nameSort[sort].equals("fireball")) {
            inputFile=new File(path+System.getProperty("file.separator") +"FRAGMENTS");
            read_fireball.res=1;
            infBas.orderBas();
            read_fireball.bas=infBas.bas;
            out=read_fireball.fix(false);
        }
        if(nameSort[sort].equals("castep")) {
            infBas.orderBas();
            read_castep.bas=infBas.bas;
            out=read_castep.savefix(inputFile);
        }
        
        if(nameSort[sort].equals("vasp")) {
            infBas.order_Castep();
            read_vasp.bas=infBas.bas;
            out=read_vasp.savePosFix(inputFile,false);
        }
        
        return out;
    }
    void save_project(File pos){ //para esto no hay prevew
        
        
    }
    
    //--leemos projecto de xyz ---
    void firstStepXYZ(File fileXYZ){
        int il=0;
        if(fileXYZ!=null)
            if(fileXYZ.exists()){
            try{
                String str="";
                infBas.bas.clear();
                BufferedReader inbas = new BufferedReader(new FileReader(fileXYZ.getAbsolutePath()));
                int natom=0;
                str = inbas.readLine();
                try{natom =(int) Double.valueOf(infBas.cadena.readCol(1,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read numero de atomos bas");}
                str = inbas.readLine();
                str = inbas.readLine(); //leemos otra linea
                for(int k=0;k<natom;k++){
                    // while ((str = inbas.readLine()) != null){
                    atom atom = new atom();
                    atom.posBas=il;
                    atom.posOut=il;
                    try{atom.Z=(infBas.periodicTable.getZ(infBas.cadena.readCol(1,str).trim())); }catch(NumberFormatException ex){System.out.println("error read Z bas");}
                    for(int i=0;i<3;i++)
                        try{atom.R[i]=(Double.valueOf(infBas.cadena.readCol(i+2,str)).doubleValue()); }catch(NumberFormatException ex){System.out.println("error read "+i+" bas");}
                    atom.symbol=infBas.periodicTable.getSymbol(atom.Z);
                    infBas.bas.add(atom);
                    il++;
                    str = inbas.readLine();
                }
                inbas.close();
            }catch (IOException oe) {System.out.println("error read basfile");}
            if(infBas.seeCell_Vol)infBas.Adj_Vol();
            if(infBas.seeCell_ijk )infBas.Adj_ijk();
            infBas.load_enlaces();
            }
    }
    
}
