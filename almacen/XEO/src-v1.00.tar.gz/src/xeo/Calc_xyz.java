/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.Vector;

public class Calc_xyz {
    Vector codigo = new Vector();
    reader cadena = new reader();
    File xyzfile;
    File outfile;
    double timeStep;
    
    /** Creates a new instance of Calc_xyz */
    public Calc_xyz() {
    }
    
    void loadCodigo(String aux){
        for(int i=1;i<=cadena.nLine(aux);i++)
            if(!cadena.readCol(1,cadena.readLine(i,aux)).equals("0.0"))
                codigo.addElement(cadena.readLine(i,aux));
    }
    
    void calculator_xyz(){
        Vector atomsXYZ= new Vector();
        try{
            BufferedReader input = new BufferedReader(new FileReader(xyzfile)) ;
            FileOutputStream archivo_ant = new FileOutputStream(outfile);
            DataOutputStream archivo = new DataOutputStream(archivo_ant);
            String str="";
            int natoms=0,iatoms=0;
            double time=0;
            natoms=(int) Double.valueOf(cadena.readCol(1,input.readLine())).doubleValue();
            input.readLine() ; //only with .xyz
            atomsXYZ.add(iatoms,time);
            SustCalculator expresion = new SustCalculator();
            while ((str = input.readLine()) != null) {
                iatoms++;
                atomsXYZ.add(iatoms,str);
                if(iatoms==natoms){
                    iatoms=0;
                    archivo.writeBytes(time+"  "+expresion.compilar_xyz(atomsXYZ,codigo)+"\n");
                    time+=timeStep;
                    input.readLine();
                    input.readLine();
                    atomsXYZ.clear();
                    atomsXYZ.add(0,time);
                }
            }
            input.close();
            archivo.close();
            archivo_ant.close();
        }catch (IOException oe) {System.out.println("hay error/es E10");}
    }
    
}
