/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;


import java.awt.event.KeyEvent;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.io.*;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import java.util.ArrayList;

public class xeo extends javax.swing.JFrame {
    //---externos ------
    String homexeo;    // where do you install it
    String HOME;            // cd ~
    //------------------
    Vector dir = new Vector();   // load the projects
    Vector ins = new Vector();
    int nInsp = 0 ;
    //--------------------------
    Vector botones = new Vector();
    reader cadena = new reader();
    
    pintar2D pintar2D_out = new pintar2D();
    pintar2D pintar2D_dinamic = new pintar2D();
    fireballOut fireballOut = new fireballOut();
    bulk bulk = new bulk();
    povray pov = new povray();
    Vector g2d = new Vector();
    Vector out = new Vector();
    mol pintarMol  = new mol();
    Calc_bas cal = new Calc_bas();
    BufferedImage screen5Buffered ;
    BufferedImage screenMiniejes ;
    int atom1,atom2,atom3,atom4;
    Runtime run;
    Process proc;
    File newFile;
    boolean modeTreeB;
    
    //--ordago---
    int dIc=5;
    long tiempo;
    String SEP;
    public xeo() {
        initComponents();
        SEP = System.getProperty("file.separator");
        //-------------------
        homexeo = "."+SEP;
        HOME="."+SEP;
        //-------------------
        atom1=atom2=atom3=atom4=-1;
        run = Runtime.getRuntime();
        modeTreeB=false;
        //-------------------
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Código Generado ">//GEN-BEGIN:initComponents
    private void initComponents() {
        menuProject = new javax.swing.JPopupMenu();
        jMenuItem9 = new javax.swing.JMenuItem();
        jSeparator13 = new javax.swing.JSeparator();
        jMenuIadd = new javax.swing.JMenuItem();
        jMedelete = new javax.swing.JMenuItem();
        rename1 = new javax.swing.JMenuItem();
        Up1 = new javax.swing.JMenuItem();
        Down1 = new javax.swing.JMenuItem();
        menuInspctor = new javax.swing.JPopupMenu();
        InspAdd1 = new javax.swing.JMenuItem();
        InspDelete1 = new javax.swing.JMenuItem();
        menuA = new javax.swing.JPopupMenu();
        open = new javax.swing.JMenuItem();
        jMenulOPEN = new javax.swing.JMenuItem();
        rename = new javax.swing.JMenuItem();
        delete_entry = new javax.swing.JMenuItem();
        Down = new javax.swing.JMenuItem();
        Up = new javax.swing.JMenuItem();
        jSeparator10 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jInspector = new javax.swing.JMenuItem();
        InspAdd = new javax.swing.JMenuItem();
        InspDelete = new javax.swing.JMenuItem();
        menuB = new javax.swing.JPopupMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jSeparator12 = new javax.swing.JSeparator();
        edit_entry1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuPlotNY = new javax.swing.JMenuItem();
        jMenuIPlotXNY = new javax.swing.JMenuItem();
        jMenuIshowPicture = new javax.swing.JMenuItem();
        jColorChooser1 = new javax.swing.JColorChooser();
        GroupExcited = new javax.swing.ButtonGroup();
        GroupExchange = new javax.swing.ButtonGroup();
        mv_axis = new javax.swing.ButtonGroup();
        projectChooser = new javax.swing.JDialog();
        path_project = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        ProjectTree = new javax.swing.JTree();
        tipo = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        OpenProject2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        note_text = new javax.swing.JTextField();
        OpenProject = new javax.swing.JButton();
        Frame_Bulk = new javax.swing.JFrame();
        file_Bulk = new javax.swing.JTextField();
        jButton53 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        fileBulk = new javax.swing.JRadioButton();
        bcc = new javax.swing.JRadioButton();
        fcc = new javax.swing.JRadioButton();
        file_Bulk_lvs = new javax.swing.JTextField();
        jButton54 = new javax.swing.JButton();
        jButton55 = new javax.swing.JButton();
        zincblende = new javax.swing.JRadioButton();
        OptBulk = new javax.swing.JCheckBox();
        jScrollPane7 = new javax.swing.JScrollPane();
        edit_Bulk = new javax.swing.JTextArea();
        jButton57 = new javax.swing.JButton();
        bulkRadiobutton = new javax.swing.ButtonGroup();
        Options = new javax.swing.JDialog();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jButton18 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        colorEjes = new javax.swing.JPanel();
        colorFondo = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        verEjes = new javax.swing.JCheckBox();
        jButton21 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jT_cx = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jT_cy = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jT_cz = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        PERS = new javax.swing.JSlider();
        labelPers = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        seeArrows = new javax.swing.JCheckBox();
        jLabel15 = new javax.swing.JLabel();
        rescalateArrow = new javax.swing.JTextField();
        jButton23 = new javax.swing.JButton();
        colorArrows = new javax.swing.JPanel();
        seeArrowsColor = new javax.swing.JCheckBox();
        jButton9 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        xyztFile = new javax.swing.JTextField();
        jButton58 = new javax.swing.JButton();
        xyzt = new javax.swing.JCheckBox();
        jPanel26 = new javax.swing.JPanel();
        Sinter2 = new javax.swing.JSlider();
        Clabel = new javax.swing.JLabel();
        Sinter1 = new javax.swing.JSlider();
        color_inter_1 = new javax.swing.JButton();
        color_ini = new javax.swing.JButton();
        color_inter_2 = new javax.swing.JButton();
        color_fin = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        seeBordes = new javax.swing.JCheckBox();
        jLabel24 = new javax.swing.JLabel();
        pixel = new javax.swing.JTextField();
        jPopupMenuDinamic = new javax.swing.JPopupMenu();
        jMenuopen = new javax.swing.JMenuItem();
        jMenuSave = new javax.swing.JMenuItem();
        jMenSee = new javax.swing.JMenuItem();
        jMenuReload = new javax.swing.JMenuItem();
        jMenureloadAdjust = new javax.swing.JMenuItem();
        jMenuOption = new javax.swing.JMenuItem();
        jMenuFile = new javax.swing.JMenuItem();
        jMenuHelp = new javax.swing.JMenuItem();
        JFrame_dinamic = new javax.swing.JFrame();
        TAB_dinamic = new javax.swing.JPanel();
        jButton32 = new javax.swing.JButton();
        open_dinamic = new javax.swing.JButton();
        save_dinamic = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        reload_dinamic = new javax.swing.JButton();
        dos_help1 = new javax.swing.JButton();
        timeStep_Text = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jSplitPane3 = new javax.swing.JSplitPane();
        screen_xyz = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        codeText = new javax.swing.JTextArea();
        OptionDinamic = new javax.swing.JButton();
        fileDinamic = new javax.swing.JButton();
        jFrame_castep = new javax.swing.JFrame();
        jPanel21 = new javax.swing.JPanel();
        Btn_cell = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        rescalateCastep = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jFrame_POVRAY = new javax.swing.JFrame();
        jPanel9 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        antialias = new javax.swing.JTextField();
        use_radio = new javax.swing.JCheckBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        bonds = new javax.swing.JTextField();
        radio = new javax.swing.JTextField();
        angle = new javax.swing.JTextField();
        jPanel41 = new javax.swing.JPanel();
        seePovray2 = new javax.swing.JButton();
        seePovray16 = new javax.swing.JButton();
        seePovray3 = new javax.swing.JButton();
        obtainGif = new javax.swing.JTextField();
        jPanel42 = new javax.swing.JPanel();
        seePovray1 = new javax.swing.JButton();
        seePovray4 = new javax.swing.JButton();
        jButtonPovray = new javax.swing.JButton();
        jButtonPovray1 = new javax.swing.JButton();
        Frame_FIREBALL = new javax.swing.JFrame();
        jPanel47 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        mol_bas = new javax.swing.JTextField();
        mol_lvs = new javax.swing.JTextField();
        jButton52 = new javax.swing.JButton();
        jButton51 = new javax.swing.JButton();
        loadBasLvs = new javax.swing.JButton();
        jLabel47 = new javax.swing.JLabel();
        seeCharges = new javax.swing.JCheckBox();
        jLabel21 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        xyz_load1 = new javax.swing.JButton();
        jLabel48 = new javax.swing.JLabel();
        xyz_load2 = new javax.swing.JButton();
        xyz_load3 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        rescalateFIREBALL = new javax.swing.JTextField();
        jFrame_VASP = new javax.swing.JFrame();
        jPanel23 = new javax.swing.JPanel();
        Btn_vasp = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        rescalateVASP = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jPopupMenuScript = new javax.swing.JPopupMenu();
        jMenuSave1 = new javax.swing.JMenuItem();
        jMenSee1 = new javax.swing.JMenuItem();
        jMenuReload1 = new javax.swing.JMenuItem();
        jMenuOption1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuHelp1 = new javax.swing.JMenuItem();
        script = new javax.swing.JFrame();
        TAB_out = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        screen_out = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        outText = new javax.swing.JTextField();
        jButton39 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        parameters = new javax.swing.JTextField();
        jButton38 = new javax.swing.JButton();
        reload_out = new javax.swing.JButton();
        JDRename = new javax.swing.JDialog();
        renameText = new javax.swing.JTextField();
        OpenProject3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        newName = new javax.swing.JTextField();
        jDCalc = new javax.swing.JDialog();
        rescalateCalc = new javax.swing.JButton();
        resText = new javax.swing.JTextField();
        jButton25 = new javax.swing.JButton();
        rotText = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        CalcZ = new javax.swing.JTextField();
        CalcY = new javax.swing.JTextField();
        CalcX = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton26 = new javax.swing.JButton();
        dos_help2 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jSplitForm = new javax.swing.JSplitPane();
        jSplitFix = new javax.swing.JSplitPane();
        jScrollPaneTreeA = new javax.swing.JScrollPane();
        TreeA = new javax.swing.JTree();
        jSplitPaneFix = new javax.swing.JSplitPane();
        jScrollPaneTreeB = new javax.swing.JScrollPane();
        TreeB = new javax.swing.JTree();
        jPanel13 = new javax.swing.JPanel();
        jButton19 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        InspLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TABXEO = new javax.swing.JPanel();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel14 = new javax.swing.JPanel();
        Tdespl = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        MiniEjes = new javax.swing.JLabel();
        axis_1 = new javax.swing.JRadioButton();
        axis_2 = new javax.swing.JRadioButton();
        axis_3 = new javax.swing.JRadioButton();
        axis_4 = new javax.swing.JRadioButton();
        jPanel33 = new javax.swing.JPanel();
        previewPos = new javax.swing.JButton();
        savePos = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        Z_all = new javax.swing.JTextField();
        jButton36 = new javax.swing.JButton();
        copy = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        paste = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        CheckFragments = new javax.swing.JCheckBox();
        selectFixAtoms = new javax.swing.JButton();
        previewFix = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        saveFix = new javax.swing.JButton();
        jPanel32 = new javax.swing.JPanel();
        seeBond = new javax.swing.JCheckBox();
        grosor = new javax.swing.JTextField();
        TOL = new javax.swing.JSlider();
        diffRadio = new javax.swing.JCheckBox();
        rad = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        seePos = new javax.swing.JCheckBox();
        jButton43 = new javax.swing.JButton();
        jButton44 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        savePos1 = new javax.swing.JButton();
        previewPos1 = new javax.swing.JButton();
        jPanel38 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        mol_Yini = new javax.swing.JTextField();
        mol_Yfin = new javax.swing.JTextField();
        mol_Zini = new javax.swing.JTextField();
        mol_Zfin = new javax.swing.JTextField();
        mol_Xini = new javax.swing.JTextField();
        mol_Xfin = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        mol_seeVol = new javax.swing.JCheckBox();
        jButton62 = new javax.swing.JButton();
        mol_seeIndex = new javax.swing.JCheckBox();
        jLabel42 = new javax.swing.JLabel();
        mol_lvs_1 = new javax.swing.JTextField();
        mol_lvs_3 = new javax.swing.JTextField();
        mol_lvs_2 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        atomo_1 = new javax.swing.JTextField();
        loadRot = new javax.swing.JButton();
        jButton67 = new javax.swing.JButton();
        Giro_centro = new javax.swing.JTextField();
        Giro_X = new javax.swing.JTextField();
        atomo_3 = new javax.swing.JTextField();
        atomo_2 = new javax.swing.JTextField();
        Giro_Z = new javax.swing.JTextField();
        screen5 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        xyz_mas = new javax.swing.JButton();
        xyz_menos = new javax.swing.JButton();
        xyz_step = new javax.swing.JTextField();
        xyz_load_step = new javax.swing.JButton();
        xyz_end = new javax.swing.JLabel();
        xyz_jSlider = new javax.swing.JSlider();
        jButton56 = new javax.swing.JButton();
        CenterXYZ = new javax.swing.JCheckBox();
        menos_mol = new javax.swing.JButton();
        yx_mol = new javax.swing.JButton();
        xz_mol = new javax.swing.JButton();
        xy_mol = new javax.swing.JButton();
        zy_mol = new javax.swing.JButton();
        mas_mol = new javax.swing.JButton();
        menuPpal = new javax.swing.JMenuBar();
        Menu_project = new javax.swing.JMenu();
        Menu_open = new javax.swing.JMenuItem();
        load = new javax.swing.JMenuItem();
        open_mol = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        hideJtree = new javax.swing.JMenuItem();
        save_mol_gif = new javax.swing.JMenuItem();
        open_mol1 = new javax.swing.JMenuItem();
        open_mol3 = new javax.swing.JMenuItem();
        utilities = new javax.swing.JMenu();
        jMenuDinamic = new javax.swing.JMenuItem();
        Calc = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        jMenuIPovray = new javax.swing.JMenuItem();
        jMenu_stm = new javax.swing.JMenuItem();
        jMenuItemBulk = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        jhelp = new javax.swing.JMenuItem();
        jMenu_Format = new javax.swing.JMenu();
        jMenuFireball = new javax.swing.JMenu();
        jMenuItem_export = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JSeparator();
        jMenu_out = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenu_begin = new javax.swing.JMenuItem();
        jMenuIhopping = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JSeparator();
        jhelpFire = new javax.swing.JMenuItem();
        jMenuCastep = new javax.swing.JMenu();
        jMenu_castep = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JSeparator();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuVasp = new javax.swing.JMenu();
        jMenu_vasp = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JSeparator();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jSeparator2 = new javax.swing.JSeparator();
        helpTypes = new javax.swing.JMenuItem();
        jMenuOptions = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenu_about = new javax.swing.JMenuItem();
        jMenu_ayuda = new javax.swing.JMenuItem();

        jMenuItem9.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem9.setText("change");
        jMenuItem9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem9MousePressed(evt);
            }
        });

        menuProject.add(jMenuItem9);

        menuProject.add(jSeparator13);

        jMenuIadd.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuIadd.setText("add inspector");
        jMenuIadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuIaddMousePressed(evt);
            }
        });

        menuProject.add(jMenuIadd);

        jMedelete.setFont(new java.awt.Font("Dialog", 0, 12));
        jMedelete.setText("close inspector");
        jMedelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMedeleteMousePressed(evt);
            }
        });

        menuProject.add(jMedelete);

        rename1.setFont(new java.awt.Font("Dialog", 0, 12));
        rename1.setText("rename (path)  F2 ");
        rename1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rename1MousePressed(evt);
            }
        });

        menuProject.add(rename1);

        Up1.setFont(new java.awt.Font("Dialog", 0, 12));
        Up1.setText("move up");
        Up1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Up1MousePressed(evt);
            }
        });

        menuProject.add(Up1);

        Down1.setFont(new java.awt.Font("Monospaced", 0, 12));
        Down1.setText("move down");
        Down1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Down1MousePressed(evt);
            }
        });

        menuProject.add(Down1);

        InspAdd1.setFont(new java.awt.Font("Dialog", 0, 12));
        InspAdd1.setText("add inspector");
        InspAdd1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                InspAdd1MousePressed(evt);
            }
        });

        menuInspctor.add(InspAdd1);

        InspDelete1.setFont(new java.awt.Font("Dialog", 0, 12));
        InspDelete1.setText("close inspector");
        InspDelete1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                InspDelete1MousePressed(evt);
            }
        });

        menuInspctor.add(InspDelete1);

        menuA.setFont(new java.awt.Font("Monospaced", 0, 12));
        open.setFont(new java.awt.Font("Dialog", 0, 12));
        open.setText("load");
        open.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                openMousePressed(evt);
            }
        });

        menuA.add(open);

        jMenulOPEN.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenulOPEN.setText("open project (here)");
        jMenulOPEN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenulOPENMousePressed(evt);
            }
        });

        menuA.add(jMenulOPEN);

        rename.setFont(new java.awt.Font("Dialog", 0, 12));
        rename.setText("rename (path)  F2 ");
        rename.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                renameMousePressed(evt);
            }
        });

        menuA.add(rename);

        delete_entry.setFont(new java.awt.Font("Dialog", 0, 12));
        delete_entry.setText("close entry");
        delete_entry.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                delete_entryMousePressed(evt);
            }
        });

        menuA.add(delete_entry);

        Down.setFont(new java.awt.Font("Monospaced", 0, 12));
        Down.setText("move down");
        Down.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                DownMousePressed(evt);
            }
        });

        menuA.add(Down);

        Up.setFont(new java.awt.Font("Dialog", 0, 12));
        Up.setText("move up");
        Up.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UpMousePressed(evt);
            }
        });

        menuA.add(Up);

        menuA.add(jSeparator10);

        menuA.add(jSeparator11);

        jInspector.setFont(new java.awt.Font("Dialog", 0, 12));
        jInspector.setText("Inspector F7");
        jInspector.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jInspectorMousePressed(evt);
            }
        });

        menuA.add(jInspector);

        InspAdd.setFont(new java.awt.Font("Dialog", 0, 12));
        InspAdd.setText("add inspector");
        InspAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                InspAddMousePressed(evt);
            }
        });

        menuA.add(InspAdd);

        InspDelete.setFont(new java.awt.Font("Dialog", 0, 12));
        InspDelete.setText("close inspector");
        InspDelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                InspDeleteMousePressed(evt);
            }
        });

        menuA.add(InspDelete);

        menuB.setFont(new java.awt.Font("Monospaced", 0, 12));
        jMenuItem8.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem8.setText("change");
        jMenuItem8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem8MousePressed(evt);
            }
        });

        menuB.add(jMenuItem8);

        menuB.add(jSeparator12);

        edit_entry1.setFont(new java.awt.Font("Monospaced", 0, 12));
        edit_entry1.setText("Edit(Text)");
        edit_entry1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                edit_entry1MousePressed(evt);
            }
        });

        menuB.add(edit_entry1);

        jMenu2.setText("Graphics");
        jMenu2.setFont(new java.awt.Font("Monospaced", 0, 12));
        jMenuPlotNY.setFont(new java.awt.Font("Monospaced", 0, 12));
        jMenuPlotNY.setText("plot NY");
        jMenuPlotNY.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuPlotNYMousePressed(evt);
            }
        });

        jMenu2.add(jMenuPlotNY);

        jMenuIPlotXNY.setFont(new java.awt.Font("Monospaced", 0, 12));
        jMenuIPlotXNY.setText("plot XNY");
        jMenuIPlotXNY.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuIPlotXNYMousePressed(evt);
            }
        });

        jMenu2.add(jMenuIPlotXNY);

        jMenuIshowPicture.setFont(new java.awt.Font("Monospaced", 0, 12));
        jMenuIshowPicture.setText("show picture");
        jMenuIshowPicture.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuIshowPictureMousePressed(evt);
            }
        });

        jMenu2.add(jMenuIshowPicture);

        menuB.add(jMenu2);

        projectChooser.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        projectChooser.setTitle("Project Chooser");
        projectChooser.setAlwaysOnTop(true);
        projectChooser.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        path_project.setFocusCycleRoot(true);
        path_project.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                path_projectKeyPressed(evt);
            }
        });

        ProjectTree.setExpandsSelectedPaths(false);
        ProjectTree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProjectTreeMouseClicked(evt);
            }
        });
        ProjectTree.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                ProjectTreeTreeWillExpand(evt);
            }
        });

        jScrollPane1.setViewportView(ProjectTree);

        tipo.setText("..");

        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        OpenProject2.setText("insert the note");
        OpenProject2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                OpenProject2MousePressed(evt);
            }
        });

        jLabel11.setText("insert the text of the note:");

        note_text.setText("---");
        note_text.setFocusCycleRoot(true);
        note_text.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                note_textKeyPressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel10Layout = new org.jdesktop.layout.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel10Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(note_text, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 317, Short.MAX_VALUE)
                    .add(jPanel10Layout.createSequentialGroup()
                        .add(jLabel11)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 27, Short.MAX_VALUE)
                        .add(OpenProject2)))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel10Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(OpenProject2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel11))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(note_text, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        OpenProject.setText("Open selected projects");
        OpenProject.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                OpenProjectMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout projectChooserLayout = new org.jdesktop.layout.GroupLayout(projectChooser.getContentPane());
        projectChooser.getContentPane().setLayout(projectChooserLayout);
        projectChooserLayout.setHorizontalGroup(
            projectChooserLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, projectChooserLayout.createSequentialGroup()
                .addContainerGap()
                .add(projectChooserLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 345, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, path_project, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 345, Short.MAX_VALUE)
                    .add(jPanel10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, projectChooserLayout.createSequentialGroup()
                        .add(tipo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 163, Short.MAX_VALUE)
                        .add(OpenProject)))
                .addContainerGap())
        );
        projectChooserLayout.setVerticalGroup(
            projectChooserLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(projectChooserLayout.createSequentialGroup()
                .addContainerGap()
                .add(path_project, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(projectChooserLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tipo)
                    .add(OpenProject, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        Frame_Bulk.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        Frame_Bulk.setTitle("BULK");

        jButton53.setText("open file");
        jButton53.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButton53.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton53MousePressed(evt);
            }
        });

        jPanel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        bulkRadiobutton.add(fileBulk);
        fileBulk.setText(" use file for lattice vectors");
        fileBulk.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        fileBulk.setMargin(new java.awt.Insets(0, 0, 0, 0));

        bulkRadiobutton.add(bcc);
        bcc.setText("bcc");
        bcc.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        bcc.setMargin(new java.awt.Insets(0, 0, 0, 0));

        bulkRadiobutton.add(fcc);
        fcc.setText("fcc");
        fcc.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        fcc.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jButton54.setText("...");
        jButton54.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton54MousePressed(evt);
            }
        });

        jButton55.setText("calcular");
        jButton55.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton55MousePressed(evt);
            }
        });

        bulkRadiobutton.add(zincblende);
        zincblende.setSelected(true);
        zincblende.setText("zincblende");
        zincblende.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        zincblende.setMargin(new java.awt.Insets(0, 0, 0, 0));

        OptBulk.setSelected(true);
        OptBulk.setText("opt");
        OptBulk.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        OptBulk.setMargin(new java.awt.Insets(0, 0, 0, 0));

        org.jdesktop.layout.GroupLayout jPanel11Layout = new org.jdesktop.layout.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel11Layout.createSequentialGroup()
                        .add(fcc)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bcc)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(zincblende))
                    .add(fileBulk, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 190, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel11Layout.createSequentialGroup()
                        .add(OptBulk)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jButton55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 81, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel11Layout.createSequentialGroup()
                        .add(file_Bulk_lvs, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton54, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel11Layout.createSequentialGroup()
                        .add(fileBulk)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(fcc)
                            .add(bcc)
                            .add(zincblende)
                            .add(jButton55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(OptBulk)))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel11Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jButton54, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(file_Bulk_lvs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        edit_Bulk.setColumns(20);
        edit_Bulk.setRows(5);
        jScrollPane7.setViewportView(edit_Bulk);

        jButton57.setText("help");
        jButton57.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButton57.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton57MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout Frame_BulkLayout = new org.jdesktop.layout.GroupLayout(Frame_Bulk.getContentPane());
        Frame_Bulk.getContentPane().setLayout(Frame_BulkLayout);
        Frame_BulkLayout.setHorizontalGroup(
            Frame_BulkLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(Frame_BulkLayout.createSequentialGroup()
                .addContainerGap()
                .add(Frame_BulkLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel11, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jScrollPane7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, Frame_BulkLayout.createSequentialGroup()
                        .add(file_Bulk, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton53)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton57)))
                .addContainerGap())
        );
        Frame_BulkLayout.setVerticalGroup(
            Frame_BulkLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(Frame_BulkLayout.createSequentialGroup()
                .addContainerGap()
                .add(Frame_BulkLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton57, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton53, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(file_Bulk, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
                .addContainerGap())
        );
        Options.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        Options.setTitle("Options");
        Options.setAlwaysOnTop(true);
        Options.setResizable(false);
        jTabbedPane1.setFont(new java.awt.Font("Monospaced", 0, 12));
        jPanel45.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton18.setText("...");
        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton18MousePressed(evt);
            }
        });

        jButton20.setText("...");
        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton20MousePressed(evt);
            }
        });

        colorEjes.setBackground(new java.awt.Color(166, 166, 167));
        colorEjes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorEjesLayout = new org.jdesktop.layout.GroupLayout(colorEjes);
        colorEjes.setLayout(colorEjesLayout);
        colorEjesLayout.setHorizontalGroup(
            colorEjesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorEjesLayout.setVerticalGroup(
            colorEjesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );

        colorFondo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorFondoLayout = new org.jdesktop.layout.GroupLayout(colorFondo);
        colorFondo.setLayout(colorFondoLayout);
        colorFondoLayout.setHorizontalGroup(
            colorFondoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorFondoLayout.setVerticalGroup(
            colorFondoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel8.setText("background");

        verEjes.setFont(new java.awt.Font("Dialog", 0, 12));
        verEjes.setText("see Axis");
        verEjes.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        verEjes.setMargin(new java.awt.Insets(0, 0, 0, 0));
        verEjes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verEjesMouseClicked(evt);
            }
        });

        jButton21.setText("OK");
        jButton21.setEnabled(false);
        jButton21.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton21MousePressed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel19.setText("Change center : X=");

        jT_cx.setText("0.0");

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel4.setText(", Y=");

        jT_cy.setText("0.0");

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel5.setText(", Z=");

        jT_cz.setText("0.0");

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(jLabel19)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jT_cx, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(1, 1, 1)
                .add(jLabel4)
                .add(1, 1, 1)
                .add(jT_cy, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel5)
                .add(3, 3, 3)
                .add(jT_cz, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                .add(jLabel19)
                .add(jT_cx, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(jLabel4)
                .add(jT_cy, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(jT_cz, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(jLabel5))
        );

        org.jdesktop.layout.GroupLayout jPanel45Layout = new org.jdesktop.layout.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel45Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel45Layout.createSequentialGroup()
                        .add(jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel45Layout.createSequentialGroup()
                                .add(jButton20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(colorEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel45Layout.createSequentialGroup()
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jButton18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(colorFondo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel45Layout.createSequentialGroup()
                                .add(jLabel8)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 146, Short.MAX_VALUE)
                                .add(jButton21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 36, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jPanel45Layout.createSequentialGroup()
                                .add(9, 9, 9)
                                .add(verEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 91, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel45Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(jButton18, 0, 0, Short.MAX_VALUE)
                    .add(colorFondo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel8)
                        .add(jButton21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel45Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, colorEjes, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jButton20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.BASELINE, verEjes, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PERS.setToolTipText("");
        PERS.setValue(100);
        PERS.setEnabled(false);
        PERS.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PERSMouseDragged(evt);
            }
        });

        labelPers.setFont(new java.awt.Font("Dialog", 0, 12));
        labelPers.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelPers.setText("perspective");
        labelPers.setEnabled(false);

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .add(PERS, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel5Layout.createSequentialGroup()
                .add(133, 133, 133)
                .add(labelPers, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                .add(128, 128, 128))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel5Layout.createSequentialGroup()
                .add(labelPers)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(PERS, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel19.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        seeArrows.setFont(new java.awt.Font("Dialog", 0, 12));
        seeArrows.setText("see arrows");
        seeArrows.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeArrows.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jLabel15.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel15.setText("rescalate:");

        rescalateArrow.setText("1");

        jButton23.setText("...");
        jButton23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton23MousePressed(evt);
            }
        });

        colorArrows.setBackground(new java.awt.Color(166, 166, 167));
        colorArrows.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorArrowsLayout = new org.jdesktop.layout.GroupLayout(colorArrows);
        colorArrows.setLayout(colorArrowsLayout);
        colorArrowsLayout.setHorizontalGroup(
            colorArrowsLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorArrowsLayout.setVerticalGroup(
            colorArrowsLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );

        seeArrowsColor.setFont(new java.awt.Font("Dialog", 0, 12));
        seeArrowsColor.setText(" use diferents colors for arrows.");
        seeArrowsColor.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeArrowsColor.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jButton9.setText("OK");
        jButton9.setEnabled(false);
        jButton9.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton9MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel19Layout = new org.jdesktop.layout.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel19Layout.createSequentialGroup()
                        .add(seeArrowsColor)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 76, Short.MAX_VALUE)
                        .add(jButton9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 32, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel19Layout.createSequentialGroup()
                        .add(jButton23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(colorArrows, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(seeArrows)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 47, Short.MAX_VALUE)
                        .add(jLabel15)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rescalateArrow, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jButton23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(seeArrows)
                            .add(colorArrows, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(rescalateArrow, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel15)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel19Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(seeArrowsColor)
                    .add(jButton9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel19, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel45, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jTabbedPane1.addTab("visualization", jPanel2);

        jPanel22.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton58.setText("...");
        jButton58.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton58MousePressed(evt);
            }
        });

        xyzt.setFont(new java.awt.Font("Dialog", 0, 12));
        xyzt.setText("see the file (x,y,z,t)");
        xyzt.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xyzt.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jPanel26.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Sinter2.setValue(40);
        Sinter2.setAlignmentX(0.0F);
        Sinter2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                Sinter2MouseDragged(evt);
            }
        });

        Clabel.setBackground(new java.awt.Color(255, 255, 255));
        Clabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Sinter1.setValue(10);
        Sinter1.setAlignmentX(0.0F);
        Sinter1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                Sinter1MouseDragged(evt);
            }
        });

        color_inter_1.setBackground(new java.awt.Color(255, 255, 255));
        color_inter_1.setForeground(new java.awt.Color(153, 153, 255));
        color_inter_1.setText("...");
        color_inter_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_inter_1MousePressed(evt);
            }
        });

        color_ini.setBackground(new java.awt.Color(255, 255, 255));
        color_ini.setForeground(new java.awt.Color(153, 153, 255));
        color_ini.setText("...");
        color_ini.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_iniMousePressed(evt);
            }
        });

        color_inter_2.setBackground(new java.awt.Color(255, 255, 255));
        color_inter_2.setForeground(new java.awt.Color(153, 153, 255));
        color_inter_2.setText("...");
        color_inter_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_inter_2MousePressed(evt);
            }
        });

        color_fin.setBackground(new java.awt.Color(255, 255, 255));
        color_fin.setForeground(new java.awt.Color(153, 153, 255));
        color_fin.setText("...");
        color_fin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_finMousePressed(evt);
            }
        });

        jButton49.setText("accept");
        jButton49.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton49.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton49MousePressed(evt);
            }
        });

        seeBordes.setFont(new java.awt.Font("Dialog", 0, 12));
        seeBordes.setText("don't see the borders");
        seeBordes.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeBordes.setMargin(new java.awt.Insets(0, 0, 0, 0));

        org.jdesktop.layout.GroupLayout jPanel26Layout = new org.jdesktop.layout.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel26Layout.createSequentialGroup()
                        .add(color_ini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(color_inter_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 179, Short.MAX_VALUE)
                        .add(color_inter_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(color_fin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel26Layout.createSequentialGroup()
                        .add(seeBordes)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 96, Short.MAX_VALUE)
                        .add(jButton49))
                    .add(Clabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 283, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(Sinter1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 283, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(Sinter2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 283, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(color_ini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(color_inter_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(color_fin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(color_inter_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Sinter1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Clabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Sinter2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton49)
                    .add(seeBordes))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel24.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel24.setText("pixel");

        pixel.setText("2");

        org.jdesktop.layout.GroupLayout jPanel22Layout = new org.jdesktop.layout.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel22Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel22Layout.createSequentialGroup()
                        .add(xyztFile, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel22Layout.createSequentialGroup()
                        .add(xyzt)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 107, Short.MAX_VALUE)
                        .add(jLabel24)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pixel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 36, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel22Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(xyzt)
                    .add(pixel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel22Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(xyztFile, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout jPanel18Layout = new org.jdesktop.layout.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jTabbedPane1.addTab("xyzt file", jPanel18);

        jTabbedPane1.getAccessibleContext().setAccessibleName(" ");

        org.jdesktop.layout.GroupLayout OptionsLayout = new org.jdesktop.layout.GroupLayout(Options.getContentPane());
        Options.getContentPane().setLayout(OptionsLayout);
        OptionsLayout.setHorizontalGroup(
            OptionsLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
        );
        OptionsLayout.setVerticalGroup(
            OptionsLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 280, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jMenuopen.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuopen.setText("open");
        jMenuopen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuopenMousePressed1(evt);
            }
        });

        jPopupMenuDinamic.add(jMenuopen);

        jMenuSave.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuSave.setText("save");
        jMenuSave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuSaveMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenuSave);

        jMenSee.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenSee.setIcon(new javax.swing.ImageIcon("..."));
        jMenSee.setText("preview");
        jMenSee.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenSeeMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenSee);

        jMenuReload.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuReload.setText("reload");
        jMenuReload.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuReloadMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenuReload);

        jMenureloadAdjust.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenureloadAdjust.setText("reload rescalate");
        jMenureloadAdjust.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenureloadAdjustMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenureloadAdjust);

        jMenuOption.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuOption.setText("options");
        jMenuOption.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuOptionMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenuOption);

        jMenuFile.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuFile.setText("file");
        jMenuFile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuFileMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenuFile);

        jMenuHelp.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuHelp.setText("help");
        jMenuHelp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuHelpMousePressed(evt);
            }
        });

        jPopupMenuDinamic.add(jMenuHelp);

        JFrame_dinamic.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        JFrame_dinamic.setTitle("dinamic");
        jButton32.setText("xyz");
        jButton32.setEnabled(false);
        jButton32.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton32MousePressed(evt);
            }
        });

        open_dinamic.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/open.gif"));
        open_dinamic.setAlignmentY(0.0F);
        open_dinamic.setDisabledIcon(new javax.swing.ImageIcon(""));
        open_dinamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                open_dinamicMousePressed(evt);
            }
        });

        save_dinamic.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/save.gif"));
        save_dinamic.setEnabled(false);
        save_dinamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                save_dinamicMousePressed(evt);
            }
        });

        jButton33.setText("...");
        jButton33.setEnabled(false);
        jButton33.setPreferredSize(new java.awt.Dimension(56, 32));
        jButton33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton33MousePressed(evt);
            }
        });

        reload_dinamic.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/reload.gif"));
        reload_dinamic.setEnabled(false);
        reload_dinamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                reload_dinamicMousePressed(evt);
            }
        });

        dos_help1.setText("help");
        dos_help1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        dos_help1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dos_help1MousePressed(evt);
            }
        });

        timeStep_Text.setText("1");
        timeStep_Text.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                timeStep_TextKeyPressed(evt);
            }
        });

        jLabel14.setText("time step");
        jLabel14.setPreferredSize(new java.awt.Dimension(59, 10));

        jSplitPane3.setDividerLocation(250);
        jSplitPane3.setDividerSize(5);
        jSplitPane3.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        screen_xyz.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        screen_xyz.setEnabled(false);
        screen_xyz.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                screen_xyzMouseWheelMoved(evt);
            }
        });
        screen_xyz.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                screen_xyzMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                screen_xyzMouseReleased(evt);
            }
        });
        screen_xyz.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                screen_xyzMouseDragged(evt);
            }
        });

        jSplitPane3.setTopComponent(screen_xyz);

        jScrollPane6.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jScrollPane6ComponentResized(evt);
            }
        });

        codeText.setColumns(10);
        codeText.setRows(1);
        codeText.setTabSize(1);
        codeText.setText("z[1]\nz[2]\n");
        jScrollPane6.setViewportView(codeText);

        jSplitPane3.setRightComponent(jScrollPane6);

        OptionDinamic.setText("Opt.");
        OptionDinamic.setEnabled(false);
        OptionDinamic.setMargin(new java.awt.Insets(0, 0, 0, 0));
        OptionDinamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                OptionDinamicMousePressed(evt);
            }
        });

        fileDinamic.setText("file");
        fileDinamic.setEnabled(false);
        fileDinamic.setMargin(new java.awt.Insets(0, 0, 0, 0));
        fileDinamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                fileDinamicMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout TAB_dinamicLayout = new org.jdesktop.layout.GroupLayout(TAB_dinamic);
        TAB_dinamic.setLayout(TAB_dinamicLayout);
        TAB_dinamicLayout.setHorizontalGroup(
            TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_dinamicLayout.createSequentialGroup()
                .addContainerGap()
                .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jSplitPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
                    .add(TAB_dinamicLayout.createSequentialGroup()
                        .add(open_dinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(save_dinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton33, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(reload_dinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(OptionDinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton32, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(fileDinamic, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(dos_help1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 122, Short.MAX_VALUE)
                        .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(timeStep_Text, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        TAB_dinamicLayout.setVerticalGroup(
            TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_dinamicLayout.createSequentialGroup()
                .addContainerGap()
                .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(save_dinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(open_dinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(reload_dinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jButton33, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(TAB_dinamicLayout.createSequentialGroup()
                            .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(jLabel14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(dos_help1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, Short.MAX_VALUE))
                            .add(5, 5, 5)
                            .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(timeStep_Text, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(fileDinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(TAB_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(OptionDinamic, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jButton32, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSplitPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE)
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout JFrame_dinamicLayout = new org.jdesktop.layout.GroupLayout(JFrame_dinamic.getContentPane());
        JFrame_dinamic.getContentPane().setLayout(JFrame_dinamicLayout);
        JFrame_dinamicLayout.setHorizontalGroup(
            JFrame_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_dinamic, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        JFrame_dinamicLayout.setVerticalGroup(
            JFrame_dinamicLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_dinamic, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame_castep.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jFrame_castep.setTitle("CASTEP");
        jPanel21.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Btn_cell.setFont(new java.awt.Font("Dialog", 0, 12));
        Btn_cell.setText("Positions of the atoms");
        Btn_cell.setEnabled(false);
        Btn_cell.setMargin(new java.awt.Insets(0, 0, 0, 0));
        Btn_cell.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Btn_cellMousePressed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel20.setText("rescalate:");

        rescalateCastep.setText("1");

        jLabel23.setText("CASTEP");

        jLabel25.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel25.setText("See the position of the atoms and fix atoms");

        jLabel26.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel26.setText("with CASTEP format:");

        org.jdesktop.layout.GroupLayout jPanel21Layout = new org.jdesktop.layout.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jLabel23)
                    .add(jLabel25)
                    .add(jPanel21Layout.createSequentialGroup()
                        .add(jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jLabel20)
                            .add(jLabel26))
                        .add(3, 3, 3)
                        .add(jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(rescalateCastep, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
                            .add(Btn_cell, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel23)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel25)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel26)
                    .add(Btn_cell, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel21Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel20)
                    .add(rescalateCastep, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jFrame_castepLayout = new org.jdesktop.layout.GroupLayout(jFrame_castep.getContentPane());
        jFrame_castep.getContentPane().setLayout(jFrame_castepLayout);
        jFrame_castepLayout.setHorizontalGroup(
            jFrame_castepLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel21, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame_castepLayout.setVerticalGroup(
            jFrame_castepLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jFrame_POVRAY.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jFrame_POVRAY.setTitle("POV-Ray");
        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel22.setText("POV-RAY");

        jPanel40.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel1.setText("angle");

        antialias.setText("0.1");

        use_radio.setFont(new java.awt.Font("Dialog", 0, 12));
        use_radio.setText("use radio");
        use_radio.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        use_radio.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel2.setText("antialias");

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel9.setText("Bonds");

        bonds.setText("1");

        radio.setText("2");

        angle.setText("1");

        org.jdesktop.layout.GroupLayout jPanel40Layout = new org.jdesktop.layout.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel40Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel40Layout.createSequentialGroup()
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(angle, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel40Layout.createSequentialGroup()
                        .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jLabel2)
                            .add(use_radio)
                            .add(jLabel9))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(antialias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(radio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bonds, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel40Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(angle, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(antialias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel2))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(radio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(use_radio))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel40Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bonds, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel9))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel41.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        seePovray2.setFont(new java.awt.Font("Dialog", 0, 12));
        seePovray2.setText("all frames (Povray)");
        seePovray2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seePovray2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                seePovray2MousePressed(evt);
            }
        });

        seePovray16.setFont(new java.awt.Font("Dialog", 0, 12));
        seePovray16.setText("all frames (xeo)");
        seePovray16.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seePovray16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                seePovray16MousePressed(evt);
            }
        });

        seePovray3.setFont(new java.awt.Font("Dialog", 0, 12));
        seePovray3.setText("make gif, run process :");
        seePovray3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seePovray3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                seePovray3MousePressed(evt);
            }
        });

        obtainGif.setText("convert -delay 100  frames/*.jpg out.gif");

        org.jdesktop.layout.GroupLayout jPanel41Layout = new org.jdesktop.layout.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel41Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel41Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, obtainGif, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel41Layout.createSequentialGroup()
                        .add(seePovray2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(seePovray16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 105, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, seePovray3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel41Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel41Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(seePovray2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(seePovray16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(seePovray3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(obtainGif, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel42.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        seePovray1.setFont(new java.awt.Font("Dialog", 0, 12));
        seePovray1.setText("see povray");
        seePovray1.setEnabled(false);
        seePovray1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seePovray1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                seePovray1MousePressed(evt);
            }
        });

        seePovray4.setFont(new java.awt.Font("Dialog", 0, 12));
        seePovray4.setText("help");
        seePovray4.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seePovray4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                seePovray4MousePressed(evt);
            }
        });

        jButtonPovray.setFont(new java.awt.Font("Dialog", 0, 12));
        jButtonPovray.setText("reload");
        jButtonPovray.setEnabled(false);
        jButtonPovray.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPovray.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonPovrayMousePressed(evt);
            }
        });

        jButtonPovray1.setFont(new java.awt.Font("Dialog", 0, 12));
        jButtonPovray1.setText("files");
        jButtonPovray1.setEnabled(false);
        jButtonPovray1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPovray1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonPovray1MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel42Layout = new org.jdesktop.layout.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel42Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel42Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, seePovray4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, seePovray1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel42Layout.createSequentialGroup()
                        .add(jButtonPovray, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButtonPovray1)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel42Layout.createSequentialGroup()
                .addContainerGap()
                .add(seePovray1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel42Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButtonPovray, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButtonPovray1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(seePovray4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel9Layout = new org.jdesktop.layout.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel9Layout.createSequentialGroup()
                .add(jPanel9Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .add(jPanel9Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel42, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel22))
                        .add(12, 12, 12)
                        .add(jPanel40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jPanel41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel9Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel9Layout.createSequentialGroup()
                        .add(jLabel22)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 19, Short.MAX_VALUE)
                        .add(jPanel42, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout jFrame_POVRAYLayout = new org.jdesktop.layout.GroupLayout(jFrame_POVRAY.getContentPane());
        jFrame_POVRAY.getContentPane().setLayout(jFrame_POVRAYLayout);
        jFrame_POVRAYLayout.setHorizontalGroup(
            jFrame_POVRAYLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame_POVRAYLayout.setVerticalGroup(
            jFrame_POVRAYLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Frame_FIREBALL.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        Frame_FIREBALL.setTitle("FIREBALL");
        Frame_FIREBALL.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                Frame_FIREBALLComponentResized(evt);
            }
        });

        jPanel47.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel44.setText("*.bas:");

        jLabel43.setText("*.lvs:");

        jButton52.setText("...");
        jButton52.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton52MousePressed(evt);
            }
        });

        jButton51.setText("...");
        jButton51.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton51MousePressed(evt);
            }
        });

        loadBasLvs.setText("Load");
        loadBasLvs.setEnabled(false);
        loadBasLvs.setMargin(new java.awt.Insets(0, 0, 0, 0));
        loadBasLvs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                loadBasLvsMousePressed(evt);
            }
        });

        jLabel47.setText("LOAD FILES");

        seeCharges.setFont(new java.awt.Font("Dialog", 0, 12));
        seeCharges.setText("see charges");
        seeCharges.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeCharges.setEnabled(false);
        seeCharges.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seeCharges.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seeChargesMouseClicked(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel21.setText("\"load from CHARGES file\"");

        org.jdesktop.layout.GroupLayout jPanel47Layout = new org.jdesktop.layout.GroupLayout(jPanel47);
        jPanel47.setLayout(jPanel47Layout);
        jPanel47Layout.setHorizontalGroup(
            jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel47Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel47)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel47Layout.createSequentialGroup()
                        .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel44)
                            .add(jLabel43))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(mol_lvs, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
                            .add(mol_bas, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jButton51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jButton52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel47Layout.createSequentialGroup()
                        .add(seeCharges)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel21)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 56, Short.MAX_VALUE)
                        .add(loadBasLvs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel47Layout.setVerticalGroup(
            jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel47Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel47)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel44)
                    .add(mol_bas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel43)
                    .add(mol_lvs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel47Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(loadBasLvs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(seeCharges)
                    .add(jLabel21))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel20.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xyz_load1.setFont(new java.awt.Font("Dialog", 0, 12));
        xyz_load1.setText("bas (format)");
        xyz_load1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xyz_load1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xyz_load1MousePressed(evt);
            }
        });

        jLabel48.setText("INPUT FILES");

        xyz_load2.setFont(new java.awt.Font("Dialog", 0, 12));
        xyz_load2.setText("FRAGMENTS");
        xyz_load2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xyz_load2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xyz_load2MousePressed(evt);
            }
        });

        xyz_load3.setFont(new java.awt.Font("Dialog", 0, 12));
        xyz_load3.setText("lvs (format)");
        xyz_load3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xyz_load3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xyz_load3MousePressed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel31.setText("rescalate:");

        rescalateFIREBALL.setText("1");

        org.jdesktop.layout.GroupLayout jPanel20Layout = new org.jdesktop.layout.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel20Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel48)
                    .add(jPanel20Layout.createSequentialGroup()
                        .add(xyz_load1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 96, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_load2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 108, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_load3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 96, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel20Layout.createSequentialGroup()
                        .add(jLabel31)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rescalateFIREBALL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 148, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel48)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel20Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(xyz_load1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(xyz_load2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(xyz_load3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel20Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel31)
                    .add(rescalateFIREBALL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout Frame_FIREBALLLayout = new org.jdesktop.layout.GroupLayout(Frame_FIREBALL.getContentPane());
        Frame_FIREBALL.getContentPane().setLayout(Frame_FIREBALLLayout);
        Frame_FIREBALLLayout.setHorizontalGroup(
            Frame_FIREBALLLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, Frame_FIREBALLLayout.createSequentialGroup()
                .addContainerGap()
                .add(Frame_FIREBALLLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel47, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel20, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        Frame_FIREBALLLayout.setVerticalGroup(
            Frame_FIREBALLLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(Frame_FIREBALLLayout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jFrame_VASP.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jFrame_VASP.setTitle("VASP");
        jPanel23.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Btn_vasp.setFont(new java.awt.Font("Dialog", 0, 12));
        Btn_vasp.setText("Positions of the atoms");
        Btn_vasp.setEnabled(false);
        Btn_vasp.setMargin(new java.awt.Insets(0, 0, 0, 0));
        Btn_vasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Btn_vaspMousePressed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel27.setText("rescalate:");

        rescalateVASP.setText("1");

        jLabel28.setText("VASP");

        jLabel29.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel29.setText("See the position of the atoms and fix atoms");

        jLabel30.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel30.setText("with VASP format:");

        org.jdesktop.layout.GroupLayout jPanel23Layout = new org.jdesktop.layout.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jLabel28)
                    .add(jLabel29)
                    .add(jPanel23Layout.createSequentialGroup()
                        .add(jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jLabel27)
                            .add(jLabel30))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(rescalateVASP, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
                            .add(Btn_vasp, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel28)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel29)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel30)
                    .add(Btn_vasp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel23Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(rescalateVASP, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel27))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jFrame_VASPLayout = new org.jdesktop.layout.GroupLayout(jFrame_VASP.getContentPane());
        jFrame_VASP.getContentPane().setLayout(jFrame_VASPLayout);
        jFrame_VASPLayout.setHorizontalGroup(
            jFrame_VASPLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jFrame_VASPLayout.setVerticalGroup(
            jFrame_VASPLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jMenuSave1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuSave1.setText("save");
        jMenuSave1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuSave1MousePressed(evt);
            }
        });

        jPopupMenuScript.add(jMenuSave1);

        jMenSee1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenSee1.setIcon(new javax.swing.ImageIcon("..."));
        jMenSee1.setText("preview");
        jMenSee1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenSee1MousePressed(evt);
            }
        });

        jPopupMenuScript.add(jMenSee1);

        jMenuReload1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuReload1.setText("reload");
        jMenuReload1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuReload1MousePressed(evt);
            }
        });

        jPopupMenuScript.add(jMenuReload1);

        jMenuOption1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuOption1.setText("options");
        jMenuOption1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuOption1MousePressed(evt);
            }
        });

        jPopupMenuScript.add(jMenuOption1);

        jMenuItem2.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem2.setText("labels.conf");
        jMenuItem2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem2MousePressed1(evt);
            }
        });

        jPopupMenuScript.add(jMenuItem2);

        jMenuHelp1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuHelp1.setText("help");
        jMenuHelp1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuHelp1MousePressed(evt);
            }
        });

        jPopupMenuScript.add(jMenuHelp1);

        script.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        script.setTitle("script");
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton1.setText("jButton1");
        jButton1.setAlignmentY(0.0F);
        jButton1.setEnabled(false);
        jButton1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });

        jButton2.setText("jButton2");
        jButton2.setEnabled(false);
        jButton2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton2MousePressed(evt);
            }
        });

        jButton3.setText("jButton3");
        jButton3.setEnabled(false);
        jButton3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton3MousePressed(evt);
            }
        });

        jButton4.setText("jButton4");
        jButton4.setEnabled(false);
        jButton4.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton4MousePressed(evt);
            }
        });

        jButton5.setText("jButton5");
        jButton5.setEnabled(false);
        jButton5.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton5MousePressed(evt);
            }
        });

        jButton6.setText("jButton6");
        jButton6.setEnabled(false);
        jButton6.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton6MousePressed(evt);
            }
        });

        jButton7.setText("jButton7");
        jButton7.setEnabled(false);
        jButton7.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton7MousePressed(evt);
            }
        });

        jButton8.setText("jButton8");
        jButton8.setEnabled(false);
        jButton8.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton8MousePressed(evt);
            }
        });

        jButton10.setText("...");
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton10MousePressed(evt);
            }
        });

        jButton11.setText("...");
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton11MousePressed(evt);
            }
        });

        jButton12.setText("...");
        jButton12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton12MousePressed(evt);
            }
        });

        jButton13.setText("...");
        jButton13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton13MousePressed(evt);
            }
        });

        jButton14.setText("...");
        jButton14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton14MousePressed(evt);
            }
        });

        jButton15.setText("...");
        jButton15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton15MousePressed(evt);
            }
        });

        jButton16.setText("...");
        jButton16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton16MousePressed(evt);
            }
        });

        jButton17.setText("...");
        jButton17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton17MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jButton11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jButton10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jButton1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jButton13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton12, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jButton15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jButton17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton1)
                            .add(jButton10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jButton11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton3)
                            .add(jButton12, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jButton4)))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jButton5))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton6)
                            .add(jButton15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton7)
                            .add(jButton16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton8)
                            .add(jButton17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        screen_out.setIcon(new javax.swing.ImageIcon(""));
        screen_out.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        screen_out.setEnabled(false);
        screen_out.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                screen_outMouseWheelMoved(evt);
            }
        });
        screen_out.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                screen_outMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                screen_outMouseReleased(evt);
            }
        });
        screen_out.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                screen_outMouseDragged(evt);
            }
        });

        jLabel10.setText("path input file: ");

        outText.setText(" inser here the path/name of the intput file --->");

        jButton39.setText("...");
        jButton39.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton39MousePressed(evt);
            }
        });

        jLabel12.setText("more prameters $1 $2 ...., : ");

        parameters.setText("1");

        jButton38.setText("Opt.");
        jButton38.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton38.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton38MousePressed(evt);
            }
        });

        reload_out.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/reload.gif"));
        reload_out.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                reload_outMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout TAB_outLayout = new org.jdesktop.layout.GroupLayout(TAB_out);
        TAB_out.setLayout(TAB_outLayout);
        TAB_outLayout.setHorizontalGroup(
            TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_outLayout.createSequentialGroup()
                .addContainerGap()
                .add(TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(screen_out, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
                    .add(TAB_outLayout.createSequentialGroup()
                        .add(TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(TAB_outLayout.createSequentialGroup()
                                .add(jButton38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(reload_out, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jLabel10))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, TAB_outLayout.createSequentialGroup()
                                .add(outText, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jButton39, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jLabel12)
                            .add(parameters, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED))
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        TAB_outLayout.setVerticalGroup(
            TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_outLayout.createSequentialGroup()
                .addContainerGap()
                .add(TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, TAB_outLayout.createSequentialGroup()
                        .add(jLabel12, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(parameters, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(reload_out, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(TAB_outLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton39, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(outText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(screen_out, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout scriptLayout = new org.jdesktop.layout.GroupLayout(script.getContentPane());
        script.getContentPane().setLayout(scriptLayout);
        scriptLayout.setHorizontalGroup(
            scriptLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_out, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        scriptLayout.setVerticalGroup(
            scriptLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_out, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        JDRename.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        JDRename.setTitle("rename");
        JDRename.setAlwaysOnTop(true);
        renameText.setBackground(java.awt.SystemColor.control);
        renameText.setEditable(false);
        renameText.setText("path");

        OpenProject3.setText("rename the porject");
        OpenProject3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                OpenProject3MousePressed(evt);
            }
        });

        jLabel3.setText("PATH =");

        newName.setText("name");
        newName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                newNameKeyPressed(evt);
            }
        });
        newName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                newNameMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout JDRenameLayout = new org.jdesktop.layout.GroupLayout(JDRename.getContentPane());
        JDRename.getContentPane().setLayout(JDRenameLayout);
        JDRenameLayout.setHorizontalGroup(
            JDRenameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(JDRenameLayout.createSequentialGroup()
                .addContainerGap()
                .add(JDRenameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(JDRenameLayout.createSequentialGroup()
                        .add(jLabel3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(renameText, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE))
                    .add(JDRenameLayout.createSequentialGroup()
                        .add(OpenProject3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(newName, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE)))
                .addContainerGap())
        );
        JDRenameLayout.setVerticalGroup(
            JDRenameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, JDRenameLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(JDRenameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel3)
                    .add(renameText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(JDRenameLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(OpenProject3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(newName, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jDCalc.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDCalc.setTitle("Calculator");
        rescalateCalc.setFont(new java.awt.Font("Dialog", 0, 12));
        rescalateCalc.setText("rescalate");
        rescalateCalc.setMargin(new java.awt.Insets(0, 0, 0, 0));
        rescalateCalc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                rescalateCalcMousePressed(evt);
            }
        });

        resText.setText("4.0/2.0");

        jButton25.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton25.setText("rotate(Z)");
        jButton25.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton25MousePressed(evt);
            }
        });

        rotText.setText("60");

        jLabel7.setText("X =");

        jLabel13.setText("Y =");

        jLabel16.setText("Z =");

        CalcZ.setFont(new java.awt.Font("Monospaced", 0, 12));
        CalcZ.setText("z");

        CalcY.setFont(new java.awt.Font("Monospaced", 0, 12));
        CalcY.setText("y");

        CalcX.setFont(new java.awt.Font("Monospaced", 0, 12));
        CalcX.setText("x");

        jLabel17.setFont(new java.awt.Font("Dialog", 2, 12));
        jLabel17.setText("\"this is an example of rescalate\"");

        jLabel18.setFont(new java.awt.Font("Dialog", 2, 12));
        jLabel18.setText("\"this is an example of rotation\"");

        jButton26.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton26.setText("Accept");
        jButton26.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton26MousePressed(evt);
            }
        });

        dos_help2.setFont(new java.awt.Font("Dialog", 0, 12));
        dos_help2.setText("help");
        dos_help2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        dos_help2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dos_help2MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jDCalcLayout = new org.jdesktop.layout.GroupLayout(jDCalc.getContentPane());
        jDCalc.getContentPane().setLayout(jDCalcLayout);
        jDCalcLayout.setHorizontalGroup(
            jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jDCalcLayout.createSequentialGroup()
                .addContainerGap()
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jDCalcLayout.createSequentialGroup()
                        .add(jLabel16)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(CalcZ, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE))
                    .add(jDCalcLayout.createSequentialGroup()
                        .add(jLabel13)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(CalcY, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE))
                    .add(jDCalcLayout.createSequentialGroup()
                        .add(jLabel7)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(CalcX, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE))
                    .add(jDCalcLayout.createSequentialGroup()
                        .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jDCalcLayout.createSequentialGroup()
                                .add(jButton25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(rotText))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jDCalcLayout.createSequentialGroup()
                                .add(rescalateCalc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(resText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 79, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel17)
                            .add(jLabel18)))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jDCalcLayout.createSequentialGroup()
                        .add(dos_help2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 243, Short.MAX_VALUE)
                        .add(jButton26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jDCalcLayout.setVerticalGroup(
            jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jDCalcLayout.createSequentialGroup()
                .addContainerGap()
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(rescalateCalc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(resText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel17))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(rotText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel18))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel7)
                    .add(CalcX, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel13)
                    .add(CalcY, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel16)
                    .add(CalcZ, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jDCalcLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(dos_help2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("xeo  (project management for nanostructures)");
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jSplitForm.setDividerLocation(180);
        jSplitForm.setDividerSize(7);
        jSplitFix.setBorder(null);
        jSplitFix.setDividerLocation(300);
        jSplitFix.setDividerSize(5);
        jSplitFix.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        jSplitFix.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jSplitFixComponentResized(evt);
            }
        });

        TreeA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TreeAKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TreeAKeyReleased(evt);
            }
        });
        TreeA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TreeAMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TreeAMousePressed(evt);
            }
        });
        TreeA.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                TreeATreeWillExpand(evt);
            }
        });

        jScrollPaneTreeA.setViewportView(TreeA);

        jSplitFix.setTopComponent(jScrollPaneTreeA);

        jSplitPaneFix.setDividerLocation(16);
        jSplitPaneFix.setDividerSize(5);
        jSplitPaneFix.setForeground(java.awt.Color.white);
        jSplitPaneFix.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        TreeB.setAlignmentX(0.0F);
        TreeB.setAlignmentY(0.0F);
        TreeB.setDoubleBuffered(true);
        TreeB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TreeBKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TreeBKeyReleased(evt);
            }
        });
        TreeB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TreeBMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TreeBMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TreeBMousePressed(evt);
            }
        });

        jScrollPaneTreeB.setViewportView(TreeB);

        jSplitPaneFix.setRightComponent(jScrollPaneTreeB);

        jPanel13.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jPanel13.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jPanel13ComponentResized(evt);
            }
        });
        jPanel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel13MousePressed(evt);
            }
        });
        jPanel13.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                jPanel13MouseWheelMoved(evt);
            }
        });

        jButton19.setText("<");
        jButton19.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton19MouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton19MousePressed(evt);
            }
        });

        jButton22.setText(">");
        jButton22.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton22MouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton22MousePressed(evt);
            }
        });

        InspLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        InspLabel.setText("1/2");
        InspLabel.setEnabled(false);
        InspLabel.setFocusable(false);
        InspLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                InspLabelMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                InspLabelMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel13Layout = new org.jdesktop.layout.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel13Layout.createSequentialGroup()
                .add(jButton19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(InspLabel, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jButton22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.BASELINE, jButton19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, Short.MAX_VALUE)
            .add(org.jdesktop.layout.GroupLayout.BASELINE, InspLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, Short.MAX_VALUE)
            .add(jButton22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, Short.MAX_VALUE)
        );
        jSplitPaneFix.setLeftComponent(jPanel13);

        jSplitFix.setRightComponent(jSplitPaneFix);

        jSplitForm.setLeftComponent(jSplitFix);

        jTabbedPane5.setFont(new java.awt.Font("Monospaced", 0, 12));
        jTabbedPane5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTabbedPane5KeyPressed(evt);
            }
        });

        Tdespl.setText("0.1*3");

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        MiniEjes.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/xeo/iconos/xeo.jpg"));
        MiniEjes.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                MiniEjesMouseDragged(evt);
            }
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                MiniEjesMouseMoved(evt);
            }
        });
        MiniEjes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                MiniEjesKeyPressed(evt);
            }
        });
        MiniEjes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MiniEjesMousePressed(evt);
            }
        });
        MiniEjes.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                MiniEjesMouseWheelMoved(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(MiniEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 142, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(MiniEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 144, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        mv_axis.add(axis_1);
        axis_1.setFont(new java.awt.Font("Dialog", 0, 10));
        axis_1.setSelected(true);
        axis_1.setText("1 Axis");
        axis_1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        axis_1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        axis_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                axis_1MouseClicked(evt);
            }
        });

        mv_axis.add(axis_2);
        axis_2.setFont(new java.awt.Font("Dialog", 0, 10));
        axis_2.setText("2 Axis");
        axis_2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        axis_2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        axis_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                axis_2MouseClicked(evt);
            }
        });

        mv_axis.add(axis_3);
        axis_3.setFont(new java.awt.Font("Dialog", 0, 10));
        axis_3.setText("3 Axis     ");
        axis_3.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        axis_3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        axis_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                axis_3MouseClicked(evt);
            }
        });

        mv_axis.add(axis_4);
        axis_4.setFont(new java.awt.Font("Dialog", 0, 10));
        axis_4.setText("neighbour");
        axis_4.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        axis_4.setMargin(new java.awt.Insets(0, 0, 0, 0));
        axis_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                axis_4MouseClicked(evt);
            }
        });

        jPanel33.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        previewPos.setFont(new java.awt.Font("Dialog", 0, 12));
        previewPos.setText("preview");
        previewPos.setEnabled(false);
        previewPos.setMargin(new java.awt.Insets(0, 0, 0, 0));
        previewPos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                previewPosMousePressed(evt);
            }
        });

        savePos.setFont(new java.awt.Font("Dialog", 0, 12));
        savePos.setText("save ");
        savePos.setEnabled(false);
        savePos.setMargin(new java.awt.Insets(0, 0, 0, 0));
        savePos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                savePosMousePressed(evt);
            }
        });

        jButton35.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton35.setText("change Z");
        jButton35.setEnabled(false);
        jButton35.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton35.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton35MousePressed(evt);
            }
        });

        Z_all.setText("1");

        jButton36.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton36.setText("duplicate");
        jButton36.setEnabled(false);
        jButton36.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton36MousePressed(evt);
            }
        });

        copy.setFont(new java.awt.Font("Dialog", 0, 12));
        copy.setText("copy");
        copy.setEnabled(false);
        copy.setMargin(new java.awt.Insets(0, 0, 0, 0));
        copy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                copyMousePressed(evt);
            }
        });

        jButton37.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton37.setText("Supr");
        jButton37.setEnabled(false);
        jButton37.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton37.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton37MousePressed(evt);
            }
        });

        paste.setFont(new java.awt.Font("Dialog", 0, 12));
        paste.setText("paste");
        paste.setEnabled(false);
        paste.setMargin(new java.awt.Insets(0, 0, 0, 0));
        paste.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pasteMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel33Layout = new org.jdesktop.layout.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(copy, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jButton36, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel33Layout.createSequentialGroup()
                        .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, previewPos, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jButton35, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton37, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                    .add(paste, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                    .add(Z_all, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                    .add(savePos, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(previewPos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(savePos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(Z_all, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton36, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel33Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(copy, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(paste, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel14Layout = new org.jdesktop.layout.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(Tdespl, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel14Layout.createSequentialGroup()
                        .add(jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(axis_1)
                            .add(axis_2))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 24, Short.MAX_VALUE)
                        .add(jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(axis_4)
                            .add(axis_3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel33, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel33, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Tdespl, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(axis_1)
                    .add(axis_3))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel14Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(axis_2)
                    .add(axis_4))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jTabbedPane5.addTab("mv atom", jPanel14);

        jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        CheckFragments.setFont(new java.awt.Font("Dialog", 0, 12));
        CheckFragments.setText("see fix atoms");
        CheckFragments.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        CheckFragments.setEnabled(false);
        CheckFragments.setMargin(new java.awt.Insets(0, 0, 0, 0));
        CheckFragments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CheckFragmentsMouseClicked(evt);
            }
        });

        selectFixAtoms.setFont(new java.awt.Font("Dialog", 0, 12));
        selectFixAtoms.setText("select fix atoms ");
        selectFixAtoms.setEnabled(false);
        selectFixAtoms.setMargin(new java.awt.Insets(0, 0, 0, 0));
        selectFixAtoms.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                selectFixAtomsMousePressed(evt);
            }
        });

        previewFix.setFont(new java.awt.Font("Dialog", 0, 12));
        previewFix.setText("preview");
        previewFix.setEnabled(false);
        previewFix.setMargin(new java.awt.Insets(0, 0, 0, 0));
        previewFix.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                previewFixMousePressed(evt);
            }
        });

        jLabel49.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel49.setText("  Edit the fix atoms");

        saveFix.setFont(new java.awt.Font("Dialog", 0, 12));
        saveFix.setText("save");
        saveFix.setEnabled(false);
        saveFix.setMargin(new java.awt.Insets(0, 0, 0, 0));
        saveFix.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                saveFixMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel15Layout = new org.jdesktop.layout.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel15Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(CheckFragments)
                    .add(selectFixAtoms, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                    .add(jPanel15Layout.createSequentialGroup()
                        .add(previewFix, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(saveFix, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE))
                    .add(jLabel49, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel49)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel15Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(previewFix, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(saveFix, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(CheckFragments)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(selectFixAtoms, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel32.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        seeBond.setFont(new java.awt.Font("Dialog", 0, 12));
        seeBond.setSelected(true);
        seeBond.setText("see Bonds");
        seeBond.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeBond.setEnabled(false);
        seeBond.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seeBond.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seeBondMouseClicked(evt);
            }
        });

        grosor.setFont(new java.awt.Font("Dialog", 0, 10));
        grosor.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        grosor.setText("2");

        TOL.setMaximum(8);
        TOL.setMinimum(1);
        TOL.setValue(4);
        TOL.setEnabled(false);
        TOL.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                TOLMouseDragged(evt);
            }
        });

        diffRadio.setFont(new java.awt.Font("Dialog", 0, 12));
        diffRadio.setText("radio");
        diffRadio.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        diffRadio.setEnabled(false);
        diffRadio.setMargin(new java.awt.Insets(0, 0, 0, 0));
        diffRadio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diffRadioMouseClicked(evt);
            }
        });

        rad.setFont(new java.awt.Font("Dialog", 0, 10));
        rad.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        rad.setText("1");

        org.jdesktop.layout.GroupLayout jPanel32Layout = new org.jdesktop.layout.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel32Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(TOL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 118, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel32Layout.createSequentialGroup()
                        .add(seeBond)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(grosor, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))
                    .add(jPanel32Layout.createSequentialGroup()
                        .add(diffRadio)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 33, Short.MAX_VALUE)
                        .add(rad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel32Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(seeBond)
                    .add(grosor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(TOL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel32Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(diffRadio)
                    .add(rad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        seePos.setFont(new java.awt.Font("Dialog", 0, 12));
        seePos.setText("see positions");
        seePos.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seePos.setEnabled(false);
        seePos.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seePos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seePosMouseClicked(evt);
            }
        });

        jButton43.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton43.setText("order Z");
        jButton43.setEnabled(false);
        jButton43.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton43.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton43MousePressed(evt);
            }
        });

        jButton44.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton44.setText("X");
        jButton44.setEnabled(false);
        jButton44.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton44.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton44MousePressed(evt);
            }
        });

        jButton50.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton50.setText("Y");
        jButton50.setEnabled(false);
        jButton50.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton50.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton50MousePressed(evt);
            }
        });

        jButton31.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton31.setText("...");
        jButton31.setEnabled(false);
        jButton31.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton31MousePressed(evt);
            }
        });

        jLabel50.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel50.setText("  Positions of atoms");

        savePos1.setFont(new java.awt.Font("Dialog", 0, 12));
        savePos1.setText("save ");
        savePos1.setEnabled(false);
        savePos1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        savePos1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                savePos1MousePressed(evt);
            }
        });

        previewPos1.setFont(new java.awt.Font("Dialog", 0, 12));
        previewPos1.setText("preview");
        previewPos1.setEnabled(false);
        previewPos1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        previewPos1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                previewPos1MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel8Layout = new org.jdesktop.layout.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(jButton43)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(seePos)
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(previewPos1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(savePos1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE))
                    .add(jLabel50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 118, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel50)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 10, Short.MAX_VALUE)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(previewPos1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(savePos1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(seePos)
                .add(9, 9, 9)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton43, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout jPanel7Layout = new org.jdesktop.layout.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel32, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel15, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel32, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jTabbedPane5.addTab("edit", jPanel7);

        jPanel39.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        mol_Yini.setText("0.0");

        mol_Yfin.setText("10.0");

        mol_Zini.setText("0.0");

        mol_Zfin.setText("10.0");

        mol_Xini.setText("0.0");

        mol_Xfin.setText("10.0");

        jLabel41.setFont(new java.awt.Font("Dialog", 1, 10));
        jLabel41.setText("  X ");

        jLabel45.setFont(new java.awt.Font("Dialog", 1, 10));
        jLabel45.setText("  Y ");

        jLabel46.setFont(new java.awt.Font("Dialog", 1, 10));
        jLabel46.setText("  Z ");

        mol_seeVol.setFont(new java.awt.Font("Dialog", 0, 12));
        mol_seeVol.setText("atoms inside box");
        mol_seeVol.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        mol_seeVol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        mol_seeVol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mol_seeVolMouseClicked(evt);
            }
        });

        jButton62.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton62.setText("Load ");
        jButton62.setEnabled(false);
        jButton62.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton62.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton62MousePressed(evt);
            }
        });

        mol_seeIndex.setFont(new java.awt.Font("Dialog", 0, 12));
        mol_seeIndex.setText("repit the unit cell");
        mol_seeIndex.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        mol_seeIndex.setMargin(new java.awt.Insets(0, 0, 0, 0));
        mol_seeIndex.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mol_seeIndexMouseClicked(evt);
            }
        });

        jLabel42.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel42.setText(" lvs    1\u00ba    2\u00ba    3\u00ba");

        mol_lvs_1.setText("1");

        mol_lvs_3.setText("1");

        mol_lvs_2.setText("1");

        org.jdesktop.layout.GroupLayout jPanel39Layout = new org.jdesktop.layout.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel39Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jButton62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, mol_seeVol, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel39Layout.createSequentialGroup()
                        .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(mol_Yini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(mol_Xini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(mol_Zini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(0, 0, 0)
                        .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel46, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 17, Short.MAX_VALUE)
                            .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jLabel45)
                                .add(jLabel41)))
                        .add(1, 1, 1)
                        .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(mol_Zfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, mol_Yfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, mol_Xfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, mol_seeIndex, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 114, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jPanel39Layout.createSequentialGroup()
                            .add(25, 25, 25)
                            .add(mol_lvs_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(mol_lvs_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(mol_lvs_3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel42))
                .addContainerGap())
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel39Layout.createSequentialGroup()
                .addContainerGap()
                .add(mol_seeVol)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel39Layout.createSequentialGroup()
                        .add(mol_Xfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(mol_Yfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(mol_Zfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel39Layout.createSequentialGroup()
                        .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(mol_Xini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel41))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(mol_Yini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel45))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(mol_Zini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jLabel46))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(mol_seeIndex)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel42)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel39Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(mol_lvs_3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(mol_lvs_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(mol_lvs_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 8, Short.MAX_VALUE)
                .add(jButton62)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        atomo_1.setText("1");

        loadRot.setFont(new java.awt.Font("Dialog", 0, 12));
        loadRot.setText("Load ");
        loadRot.setEnabled(false);
        loadRot.setMargin(new java.awt.Insets(0, 0, 0, 0));
        loadRot.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                loadRotMousePressed(evt);
            }
        });

        jButton67.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton67.setText("rotate");
        jButton67.setEnabled(false);
        jButton67.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton67.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton67MousePressed(evt);
            }
        });

        Giro_centro.setText("center 0 0 0");

        Giro_X.setText("Axis-X 1 0 0 ");

        atomo_3.setText("3");

        atomo_2.setText("2");

        Giro_Z.setText("Axis-Z 0 0 1");

        org.jdesktop.layout.GroupLayout jPanel6Layout = new org.jdesktop.layout.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel6Layout.createSequentialGroup()
                        .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(atomo_3)
                            .add(atomo_2)
                            .add(atomo_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 27, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, Giro_centro, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, Giro_Z, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, Giro_X, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)))
                    .add(jPanel6Layout.createSequentialGroup()
                        .add(loadRot)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton67, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(loadRot, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel6Layout.createSequentialGroup()
                        .add(atomo_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(atomo_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(atomo_3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel6Layout.createSequentialGroup()
                        .add(Giro_centro, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Giro_Z, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Giro_X, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(38, 38, 38))
        );

        org.jdesktop.layout.GroupLayout jPanel38Layout = new org.jdesktop.layout.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel38Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel39, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel39, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 118, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jTabbedPane5.addTab("lvs", jPanel38);

        screen5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        screen5.setRequestFocusEnabled(false);
        screen5.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                screen5MouseDragged(evt);
            }
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                screen5MouseMoved(evt);
            }
        });
        screen5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                screen5KeyPressed(evt);
            }
        });
        screen5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                screen5MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                screen5MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                screen5MouseReleased(evt);
            }
        });
        screen5.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                screen5MouseWheelMoved(evt);
            }
        });

        jPanel24.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel36.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel36.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jPanel36KeyPressed(evt);
            }
        });

        xyz_mas.setText("+");
        xyz_mas.setEnabled(false);
        xyz_mas.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xyz_mas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xyz_masMousePressed(evt);
            }
        });

        xyz_menos.setText("-");
        xyz_menos.setEnabled(false);
        xyz_menos.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xyz_menos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xyz_menosMousePressed(evt);
            }
        });

        xyz_step.setText("0");
        xyz_step.setEnabled(false);

        xyz_load_step.setFont(new java.awt.Font("Dialog", 0, 12));
        xyz_load_step.setText("load/refresh");
        xyz_load_step.setEnabled(false);
        xyz_load_step.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xyz_load_step.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xyz_load_stepMousePressed(evt);
            }
        });

        xyz_end.setFont(new java.awt.Font("Dialog", 0, 12));
        xyz_end.setText("final");
        xyz_end.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        xyz_jSlider.setEnabled(false);
        xyz_jSlider.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                xyz_jSliderMouseDragged(evt);
            }
        });
        xyz_jSlider.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                xyz_jSliderMouseReleased(evt);
            }
        });

        jButton56.setText("...");
        jButton56.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton56MousePressed(evt);
            }
        });

        CenterXYZ.setFont(new java.awt.Font("Dialog", 0, 10));
        CenterXYZ.setText("center");
        CenterXYZ.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        CenterXYZ.setMargin(new java.awt.Insets(0, 0, 0, 0));

        org.jdesktop.layout.GroupLayout jPanel36Layout = new org.jdesktop.layout.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel36Layout.createSequentialGroup()
                        .add(jButton56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_load_step)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_step, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_end, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(CenterXYZ))
                    .add(jPanel36Layout.createSequentialGroup()
                        .add(xyz_menos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_jSlider, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 377, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xyz_mas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel36Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(xyz_load_step, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(xyz_step, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jButton56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(xyz_end, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(CenterXYZ, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel36Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(xyz_menos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(xyz_mas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(xyz_jSlider, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        menos_mol.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/menos.gif"));
        menos_mol.setEnabled(false);
        menos_mol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        menos_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                menos_molMousePressed(evt);
            }
        });

        yx_mol.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/yx.gif"));
        yx_mol.setEnabled(false);
        yx_mol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        yx_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                yx_molMousePressed(evt);
            }
        });

        xz_mol.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/xz.gif"));
        xz_mol.setEnabled(false);
        xz_mol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xz_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xz_molMousePressed(evt);
            }
        });

        xy_mol.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/xy.gif"));
        xy_mol.setEnabled(false);
        xy_mol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        xy_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                xy_molMousePressed(evt);
            }
        });

        zy_mol.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/zy.gif"));
        zy_mol.setEnabled(false);
        zy_mol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        zy_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                zy_molMousePressed(evt);
            }
        });

        mas_mol.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/mas.gif"));
        mas_mol.setEnabled(false);
        mas_mol.setMargin(new java.awt.Insets(0, 0, 0, 0));
        mas_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                mas_molMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel24Layout = new org.jdesktop.layout.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel36, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel24Layout.createSequentialGroup()
                        .add(mas_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xy_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(zy_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel24Layout.createSequentialGroup()
                        .add(menos_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(yx_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(xz_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel24Layout.createSequentialGroup()
                        .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(xy_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(zy_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(mas_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(yx_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(menos_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(xz_mol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel36, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout TABXEOLayout = new org.jdesktop.layout.GroupLayout(TABXEO);
        TABXEO.setLayout(TABXEOLayout);
        TABXEOLayout.setHorizontalGroup(
            TABXEOLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TABXEOLayout.createSequentialGroup()
                .addContainerGap()
                .add(TABXEOLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, TABXEOLayout.createSequentialGroup()
                        .add(screen5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jTabbedPane5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 175, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel24, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        TABXEOLayout.setVerticalGroup(
            TABXEOLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TABXEOLayout.createSequentialGroup()
                .addContainerGap()
                .add(TABXEOLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(screen5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
                    .add(jTabbedPane5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jScrollPane2.setViewportView(TABXEO);

        jSplitForm.setRightComponent(jScrollPane2);

        org.jdesktop.layout.GroupLayout jPanel12Layout = new org.jdesktop.layout.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jSplitForm, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 823, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jSplitForm, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
        );

        menuPpal.setFont(new java.awt.Font("Dialog", 0, 12));
        Menu_project.setBorder(null);
        Menu_project.setText("File   ");
        Menu_project.setFont(new java.awt.Font("Dialog", 0, 12));
        Menu_open.setFont(new java.awt.Font("Dialog", 0, 12));
        Menu_open.setText("open project    F4");
        Menu_open.setActionCommand("open project  (here)  F4");
        Menu_open.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Menu_openMousePressed(evt);
            }
        });

        Menu_project.add(Menu_open);

        load.setFont(new java.awt.Font("Dialog", 0, 12));
        load.setText("load project     F5");
        load.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                loadMousePressed(evt);
            }
        });

        Menu_project.add(load);

        open_mol.setFont(new java.awt.Font("Dialog", 0, 12));
        open_mol.setText("open file          F3");
        open_mol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                open_molMousePressed(evt);
            }
        });

        Menu_project.add(open_mol);

        Menu_project.add(jSeparator1);

        hideJtree.setFont(new java.awt.Font("Dialog", 0, 12));
        hideJtree.setText("hide Inspector  F7");
        hideJtree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hideJtreeMousePressed(evt);
            }
        });

        Menu_project.add(hideJtree);

        save_mol_gif.setFont(new java.awt.Font("Dialog", 0, 12));
        save_mol_gif.setText("save *.jpg");
        save_mol_gif.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                save_mol_gifMousePressed(evt);
            }
        });

        Menu_project.add(save_mol_gif);

        open_mol1.setFont(new java.awt.Font("Dialog", 0, 12));
        open_mol1.setText("show picture");
        open_mol1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                open_mol1MousePressed(evt);
            }
        });

        Menu_project.add(open_mol1);

        open_mol3.setFont(new java.awt.Font("Dialog", 0, 12));
        open_mol3.setText("edit (*.xyz)");
        open_mol3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                open_mol3MousePressed(evt);
            }
        });

        Menu_project.add(open_mol3);

        menuPpal.add(Menu_project);

        utilities.setBorder(null);
        utilities.setText("Utilities   ");
        utilities.setFont(new java.awt.Font("Dialog", 0, 12));
        utilities.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                utilitiesMousePressed(evt);
            }
        });

        jMenuDinamic.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuDinamic.setText("dinamic");
        jMenuDinamic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuDinamicMousePressed(evt);
            }
        });

        utilities.add(jMenuDinamic);

        Calc.setFont(new java.awt.Font("Dialog", 0, 12));
        Calc.setText("calculator (structure)");
        Calc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                CalcMousePressed(evt);
            }
        });

        utilities.add(Calc);

        utilities.add(jSeparator4);

        jMenuIPovray.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuIPovray.setText("POV-Ray");
        jMenuIPovray.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem1MousePressed(evt);
            }
        });

        utilities.add(jMenuIPovray);

        jMenu_stm.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_stm.setText("STM");
        jMenu_stm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_stmMousePressed(evt);
            }
        });

        utilities.add(jMenu_stm);

        jMenuItemBulk.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItemBulk.setText("Bulk modulus");
        jMenuItemBulk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItemBulkMousePressed(evt);
            }
        });

        utilities.add(jMenuItemBulk);

        utilities.add(jSeparator3);

        jMenuItem6.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem6.setText("editor");
        jMenuItem6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem6MousePressed(evt);
            }
        });

        utilities.add(jMenuItem6);

        jMenuItem4.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem4.setText("calculator");
        jMenuItem4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem4MousePressed(evt);
            }
        });

        utilities.add(jMenuItem4);

        jMenuItem3.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem3.setText("script");
        jMenuItem3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem2MousePressed(evt);
            }
        });

        utilities.add(jMenuItem3);

        utilities.add(jSeparator5);

        jhelp.setFont(new java.awt.Font("Dialog", 0, 12));
        jhelp.setText("help");
        jhelp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jhelpMousePressed(evt);
            }
        });

        utilities.add(jhelp);

        menuPpal.add(utilities);

        jMenu_Format.setBorder(null);
        jMenu_Format.setText("Project Types   ");
        jMenu_Format.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuFireball.setText("FIREBALL");
        jMenuFireball.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem_export.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem_export.setText("export FIREBALL");
        jMenuItem_export.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem_exportMousePressed(evt);
            }
        });

        jMenuFireball.add(jMenuItem_export);

        jMenuFireball.add(jSeparator6);

        jMenu_out.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_out.setText("DOS and bands");
        jMenu_out.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_outMousePressed(evt);
            }
        });

        jMenuFireball.add(jMenu_out);

        jMenuItem5.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem5.setText("BAS calculator");
        jMenuItem5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem5MousePressed(evt);
            }
        });

        jMenuFireball.add(jMenuItem5);

        jMenu_begin.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_begin.setText("begin");
        jMenu_begin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_beginMousePressed(evt);
            }
        });

        jMenuFireball.add(jMenu_begin);

        jMenuIhopping.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuIhopping.setText("hopping");
        jMenuIhopping.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuIhoppingMousePressed(evt);
            }
        });

        jMenuFireball.add(jMenuIhopping);

        jMenuFireball.add(jSeparator7);

        jhelpFire.setFont(new java.awt.Font("Dialog", 0, 12));
        jhelpFire.setText("help");
        jhelpFire.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jhelpFireMousePressed(evt);
            }
        });

        jMenuFireball.add(jhelpFire);

        jMenu_Format.add(jMenuFireball);

        jMenuCastep.setText("CASTEP");
        jMenuCastep.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_castep.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_castep.setText("export CASTEP");
        jMenu_castep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_castepMousePressed(evt);
            }
        });

        jMenuCastep.add(jMenu_castep);

        jMenuCastep.add(jSeparator8);

        jMenuItem1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem1.setText("help");
        jMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem1MousePressed1(evt);
            }
        });

        jMenuCastep.add(jMenuItem1);

        jMenu_Format.add(jMenuCastep);

        jMenuVasp.setText("VASP");
        jMenuVasp.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_vasp.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_vasp.setText("export VASP ");
        jMenu_vasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_vaspMousePressed(evt);
            }
        });

        jMenuVasp.add(jMenu_vasp);

        jMenuVasp.add(jSeparator9);

        jMenuItem7.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuItem7.setText("help");
        jMenuItem7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuItem7MousePressed(evt);
            }
        });

        jMenuVasp.add(jMenuItem7);

        jMenu_Format.add(jMenuVasp);

        jMenu1.setText("ABINIT");
        jMenu1.setEnabled(false);
        jMenu1.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_Format.add(jMenu1);

        jMenu_Format.add(jSeparator2);

        helpTypes.setFont(new java.awt.Font("Dialog", 0, 12));
        helpTypes.setText("help");
        helpTypes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                helpTypesMousePressed(evt);
            }
        });

        jMenu_Format.add(helpTypes);

        menuPpal.add(jMenu_Format);

        jMenuOptions.setBorder(null);
        jMenuOptions.setText("Options   ");
        jMenuOptions.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenuOptions.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenuOptionsMousePressed(evt);
            }
        });

        menuPpal.add(jMenuOptions);

        jMenu4.setText("help");
        jMenu4.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_about.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_about.setText("about");
        jMenu_about.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_aboutMousePressed(evt);
            }
        });

        jMenu4.add(jMenu_about);

        jMenu_ayuda.setFont(new java.awt.Font("Dialog", 0, 12));
        jMenu_ayuda.setText("help F1");
        jMenu_ayuda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu_ayudaMousePressed(evt);
            }
        });

        jMenu4.add(jMenu_ayuda);

        menuPpal.add(jMenu4);

        setJMenuBar(menuPpal);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel12, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel12, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void jButton19MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseEntered
        InspLabel.setEnabled(false);
    }//GEN-LAST:event_jButton19MouseEntered
    
    private void jButton22MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseEntered
        InspLabel.setEnabled(false);
    }//GEN-LAST:event_jButton22MouseEntered
    
    private void TreeBMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TreeBMouseEntered
        InspLabel.setEnabled(false);
    }//GEN-LAST:event_TreeBMouseEntered
    
    private void InspLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InspLabelMouseEntered
        InspLabel.setEnabled(true);
    }//GEN-LAST:event_InspLabelMouseEntered
    
    private void InspLabelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InspLabelMousePressed
        modeTreeB=!modeTreeB;
        loadTreeB();
    }//GEN-LAST:event_InspLabelMousePressed
    
    private void TreeBKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TreeBKeyReleased
        if(evt.getKeyCode()==evt.VK_UP ){
            if(!modeTreeB){
                nInsp=TreeB.getMaxSelectionRow()-1;
                if(nInsp>=ins.size())nInsp=0;
                if(nInsp<0)nInsp=ins.size()-1;
                Limpiar_Inspector();
                Inspector();
            }
        }
        if(evt.getKeyCode()==evt.VK_DOWN ){
            if(!modeTreeB){
                nInsp=TreeB.getMaxSelectionRow()-1;
                if(nInsp>=ins.size())nInsp=0;
                if(nInsp<0)nInsp=ins.size()-1;
                Limpiar_Inspector();
                Inspector();
            }
        }
    }//GEN-LAST:event_TreeBKeyReleased
    
    private void Up1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Up1MousePressed
        TreeBup();
    }//GEN-LAST:event_Up1MousePressed
    
    private void Down1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Down1MousePressed
        TreeBdown();
    }//GEN-LAST:event_Down1MousePressed
    
    private void TreeBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TreeBKeyPressed
        if(evt.getKeyCode() == evt.VK_F2)
            if(!modeTreeB)
                if(!TreeB.isSelectionEmpty()) {
            TreeA.setSelectionRow(0);
            renameOpen();
                }
        if(evt.getKeyCode()==evt.VK_ENTER ){
            if(!modeTreeB){
                nInsp=TreeB.getMaxSelectionRow()-1;
                if(nInsp>=ins.size())nInsp=0;
                if(nInsp<0)nInsp=ins.size()-1;
                Limpiar_Inspector();
                Inspector();
            }
        }
        if(evt.getKeyCode()==evt.VK_DELETE )
            if(!modeTreeB)
                deleteInsp();
        if(evt.getKeyCode() == 104) TreeBup();
        if(evt.getKeyCode() == 98) TreeBdown();
    }//GEN-LAST:event_TreeBKeyPressed
    
    private void rename1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rename1MousePressed
        if(!TreeB.isSelectionEmpty()) {
            TreeA.setSelectionRow(0);
            renameOpen();
        }
    }//GEN-LAST:event_rename1MousePressed
    
    private void newNameMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newNameMousePressed
        newName.requestFocus();
    }//GEN-LAST:event_newNameMousePressed
    
    private void jMedeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMedeleteMousePressed
        deleteInsp();
    }//GEN-LAST:event_jMedeleteMousePressed
    
    private void jMenuIaddMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuIaddMousePressed
        ins.add("project "+(ins.size()+1));
        cadena.writer(ins,new File(HOME+".xeo/inspector"));
        nInsp=ins.size()-1;
        Limpiar_Inspector();
        Inspector();
    }//GEN-LAST:event_jMenuIaddMousePressed
    
    private void TreeBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TreeBMouseClicked
        if(!modeTreeB){
            nInsp=TreeB.getMaxSelectionRow()-1;
            if(nInsp>=ins.size())nInsp=0;
            if(nInsp<0)nInsp=ins.size()-1;
            Limpiar_Inspector();
            Inspector();
        }
    }//GEN-LAST:event_TreeBMouseClicked
    
    private void jMenuItem9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem9MousePressed
        modeTreeB=!modeTreeB;
        loadTreeB();
    }//GEN-LAST:event_jMenuItem9MousePressed
    
    private void jMenuItem8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem8MousePressed
        modeTreeB=!modeTreeB;
        loadTreeB();
    }//GEN-LAST:event_jMenuItem8MousePressed
    
    private void screen5MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen5MouseMoved
        if(dobleClick)
            if(System.currentTimeMillis()>tiempo+MS_PER_FRAME)
                if(pintarMol.MOL_enable)
                    if(pintarMol.imageBuffered!=null){
            pintarMol.X_mouse_fin=evt.getX();
            pintarMol.Y_mouse_fin=evt.getY();
            ver3D_MOL();
            tiempo=System.currentTimeMillis();
                    }
    }//GEN-LAST:event_screen5MouseMoved
    
    private void MiniEjesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_MiniEjesKeyPressed
        if(evt.VK_F1== evt.getKeyCode()) new help(homexeo+"help/key/key.html").setVisible(true);
    }//GEN-LAST:event_MiniEjesKeyPressed
    
    private void jPanel13ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel13ComponentResized
        jSplitPaneFix.setDividerLocation(16);
    }//GEN-LAST:event_jPanel13ComponentResized
    
    private void OpenProjectMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenProjectMousePressed
        insertInTreeA();
    }//GEN-LAST:event_OpenProjectMousePressed
    
    private void TreeATreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_TreeATreeWillExpand
        loadMOL();
    }//GEN-LAST:event_TreeATreeWillExpand
    
    private void ProjectTreeTreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_ProjectTreeTreeWillExpand
        if(ProjectTree.getSelectionPath() != null)
            if(ProjectTree.getSelectionPath().getPathCount() > 1){
            newFile=new File(path_project.getText()+SEP+ProjectTree.getSelectionPath().getPathComponent(1).toString());
            if(newFile.exists())path_project.setText(newFile.toString());
            pintarMol.babel.path=path_project.getText();
            pintarMol.babel.SORT();
            tipo.setText(pintarMol.babel.nameSort[pintarMol.babel.sort]);
            }
        projectOpen();
    }//GEN-LAST:event_ProjectTreeTreeWillExpand
    
    private void jPanel13MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_jPanel13MouseWheelMoved
        nInsp+=evt.getWheelRotation();
        if(nInsp>=ins.size())nInsp=0;
        if(nInsp<0)nInsp=ins.size()-1;
        Limpiar_Inspector();
        Inspector();
    }//GEN-LAST:event_jPanel13MouseWheelMoved
    
    private void jPanel13MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel13MousePressed
        if(evt.getButton()==evt.BUTTON3) menuInspctor.show( evt.getComponent(), evt.getX(), evt.getY() ) ;
    }//GEN-LAST:event_jPanel13MousePressed
    
    private void InspDelete1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InspDelete1MousePressed
        deleteInsp();
    }//GEN-LAST:event_InspDelete1MousePressed
    
    private void InspAdd1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InspAdd1MousePressed
        ins.add("project "+(ins.size()+1));
        cadena.writer(ins,new File(HOME+".xeo/inspector"));
        nInsp=ins.size()-1;
        Limpiar_Inspector();
        Inspector();
    }//GEN-LAST:event_InspAdd1MousePressed
    
    
    void deleteInsp(){
        if(ins.size()>1){
            new File(HOME+".xeo/aux").delete();
            new File(HOME+".xeo/profile-xeo_"+nInsp).renameTo(new File(HOME+".xeo/aux"));
            for(int i =nInsp; i<ins.size();i++)
                new File(HOME+".xeo/profile-xeo_"+(i+1)).renameTo(new File(HOME+".xeo/profile-xeo_"+i));
            new File(HOME+".xeo/profile-xeo_"+(ins.size()-1)).delete();
            new File(HOME+".xeo/aux").renameTo(new File(HOME+".xeo/profile-xeo_"+(ins.size()-1)));
            ins.remove(nInsp);
            cadena.writer(ins,new File(HOME+".xeo/inspector"));
            nInsp--;
            if(nInsp<0)nInsp=ins.size()-1;
            Limpiar_Inspector();
            Inspector();
        }else  System.out.println("this is the only inpector opens");
    }
    
    
    private void InspDeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InspDeleteMousePressed
        deleteInsp();
    }//GEN-LAST:event_InspDeleteMousePressed
    
    private void InspAddMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InspAddMousePressed
        ins.add("project "+(ins.size()+1));
        cadena.writer(ins,new File(HOME+".xeo/inspector"));
        nInsp=ins.size()-1;
        Limpiar_Inspector();
        Inspector();
    }//GEN-LAST:event_InspAddMousePressed
    
    private void jButton19MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MousePressed
        nInsp--;
        if(nInsp<0)nInsp=ins.size()-1;
        Limpiar_Inspector();
        Inspector();
    }//GEN-LAST:event_jButton19MousePressed
    
    private void jButton22MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MousePressed
        nInsp++;
        if(nInsp>=ins.size())nInsp=0;
        Limpiar_Inspector();
        Inspector();
    }//GEN-LAST:event_jButton22MousePressed
    
    private void jInspectorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jInspectorMousePressed
        if(jSplitForm.getDividerLocation()==1)jSplitForm.setDividerLocation(180);
        else jSplitForm.setDividerLocation(1);
    }//GEN-LAST:event_jInspectorMousePressed
    
    private void hideJtreeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hideJtreeMousePressed
        if(jSplitForm.getDividerLocation()==1)jSplitForm.setDividerLocation(180);
        else jSplitForm.setDividerLocation(1);
    }//GEN-LAST:event_hideJtreeMousePressed
    
    private void seePovray16MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seePovray16MousePressed
        verFrames_xyz();
    }//GEN-LAST:event_seePovray16MousePressed
    
    private void jButtonPovrayMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonPovrayMousePressed
        screen5.setIcon(new ImageIcon(homexeo+"iconos/reload.gif"));
        if(pov.picture.exists()) screen5.setIcon(new ImageIcon(pov.picture.getAbsolutePath()));
        else System.out.println(pov.picture.getAbsolutePath()+" don't exist");
    }//GEN-LAST:event_jButtonPovrayMousePressed
    
    private void jButtonPovray1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonPovray1MousePressed
        if(jButtonPovray.isEnabled()) povray(true);
    }//GEN-LAST:event_jButtonPovray1MousePressed
    
    private void seePovray1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seePovray1MousePressed
        if(jButtonPovray.isEnabled()) povray(false);
    }//GEN-LAST:event_seePovray1MousePressed
    
    private void seePovray2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seePovray2MousePressed
        verPovray_xyz();
    }//GEN-LAST:event_seePovray2MousePressed
    
    private void seePovray3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seePovray3MousePressed
        try{
            proc = run.exec(obtainGif.getText());
            proc.waitFor();
        } catch(Exception e){}
    }//GEN-LAST:event_seePovray3MousePressed
    
    private void seePovray4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seePovray4MousePressed
        new help(homexeo+"help/utilities/povray.html").setVisible(true);
    }//GEN-LAST:event_seePovray4MousePressed
    
    private void jMenuItem2MousePressed1(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem2MousePressed1
        new editor(homexeo,HOME+".xeo/script/Label.conf").openFile(new File(HOME+".xeo/script/Label.conf"));
    }//GEN-LAST:event_jMenuItem2MousePressed1
    
    private void jMenuHelp1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuHelp1MousePressed
        new help(homexeo+"help/utilities/script.html").setVisible(true);
    }//GEN-LAST:event_jMenuHelp1MousePressed
    
    private void jMenuOption1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuOption1MousePressed
        pintar2D_out.opt.setVisible(true);
        pintar2D_out.opt.ini();
    }//GEN-LAST:event_jMenuOption1MousePressed
    
    private void jMenuReload1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuReload1MousePressed
        if(reload_out.isEnabled()){
            runProcess(0,false);
        }
    }//GEN-LAST:event_jMenuReload1MousePressed
    
    private void jMenSee1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenSee1MousePressed
        new show_picture(homexeo,pintar2D_out.inputfile2D.getAbsolutePath()).plotBuffered(pintar2D_out.imageBuffered);
    }//GEN-LAST:event_jMenSee1MousePressed
    
    private void jMenuSave1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuSave1MousePressed
        new chooser().savePicture("Save file *.jpg","save",pintar2D_out.inputfile2D.getAbsolutePath(),pintar2D_out.imageBuffered);
    }//GEN-LAST:event_jMenuSave1MousePressed
    
    private void jMenuHelpMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuHelpMousePressed
        new help(homexeo+"help/utilities/dinamic.html").setVisible(true);
    }//GEN-LAST:event_jMenuHelpMousePressed
    
    private void jMenuFileMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuFileMousePressed
        editor edit = new editor(homexeo,HOME+".xeo/temp/dinamic.temp");
        edit.openFile(new File(HOME+".xeo/temp/dinamic.temp"));
        edit.setTitle(pintarMol.babel.path+SEP+"dinamic.dat");
    }//GEN-LAST:event_jMenuFileMousePressed
    
    private void jMenuOptionMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuOptionMousePressed
        pintar2D_dinamic.opt.setVisible(true);
        pintar2D_dinamic.opt.ini();
    }//GEN-LAST:event_jMenuOptionMousePressed
    
    private void jMenureloadAdjustMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenureloadAdjustMousePressed
        if(reload_dinamic.isEnabled()){
            pintar2D_dinamic.opt.ajustarMaximos=true;
            dinamic dinamic=new dinamic();
            dinamic.start();
        }
    }//GEN-LAST:event_jMenureloadAdjustMousePressed
    
    private void jMenuReloadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuReloadMousePressed
        if(reload_dinamic.isEnabled()){
            pintar2D_dinamic.opt.ajustarMaximos=false;
            dinamic dinamic=new dinamic();
            dinamic.start();
        }
    }//GEN-LAST:event_jMenuReloadMousePressed
    
    private void jMenSeeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenSeeMousePressed
        if(jButton33.isEnabled())
            new show_picture(homexeo,pintar2D_dinamic.inputfile2D.getAbsolutePath()).plotBuffered(pintar2D_dinamic.imageBuffered);
        
    }//GEN-LAST:event_jMenSeeMousePressed
    
    private void jMenuSaveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuSaveMousePressed
        if(save_dinamic.isEnabled())
            new chooser().savePicture("Save file *.jpg","save",pintar2D_dinamic.inputfile2D.getAbsolutePath(),pintar2D_dinamic.imageBuffered);
        
    }//GEN-LAST:event_jMenuSaveMousePressed
    
    private void fileDinamicMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fileDinamicMousePressed
        if(fileDinamic.isEnabled()){
            editor edit = new editor(homexeo,HOME+".xeo/temp/dinamic.temp");
            edit.openFile(new File(HOME+".xeo/temp/dinamic.temp"));
            edit.setTitle(pintarMol.babel.path+SEP+"dinamic.dat");
        }
    }//GEN-LAST:event_fileDinamicMousePressed
    
    private void screen_outMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_screen_outMouseWheelMoved
        if(evt.getWheelRotation()<0){
            pintar2D_out.mouseIni((int) (evt.getX()-screen_out.getWidth()/4),(int) (evt.getY()-screen_out.getHeight()/4),true);
            pintar2D_out.mouseFin((int) (evt.getX()+screen_out.getWidth()/4),(int) (evt.getY()+screen_out.getHeight()/4),false);
        }else{
            pintar2D_out.mouseIni((int) (evt.getX()-screen_out.getWidth()),(int) (evt.getY()-screen_out.getHeight()),true);
            pintar2D_out.mouseFin((int) (evt.getX()+screen_out.getWidth()),(int) (evt.getY()+screen_out.getHeight()),false);
        }
        if(screen_out.isEnabled()){
            pintar2D_out.lupa2D();
            pintar2D_out.opt.ajustarMaximos=false;
            if(pintar2D_out.opt.isVisible()) pintar2D_out.opt.ini();
            runProcess(0,false);
        }
    }//GEN-LAST:event_screen_outMouseWheelMoved
    
    private void reload_outMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reload_outMousePressed
        if(reload_out.isEnabled()){
            runProcess(0,false);
        }
    }//GEN-LAST:event_reload_outMousePressed
    
    private void jButton38MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton38MousePressed
        pintar2D_out.opt.setVisible(true);
        pintar2D_out.opt.ini();
    }//GEN-LAST:event_jButton38MousePressed
    
    private void jMenuopenMousePressed1(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuopenMousePressed1
        newFile =  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path+SEP+".") ;
        if(newFile!=null){
            pintar2D_dinamic.inputfile2D=newFile;
            pintar2D_dinamic.opt.ajustarMaximos=true;
            dinamic dinamic=new dinamic();
            dinamic.start();
        }
    }//GEN-LAST:event_jMenuopenMousePressed1
    
    private void OptionDinamicMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OptionDinamicMousePressed
        if( OptionDinamic.isEnabled())  {
            pintar2D_dinamic.opt.setVisible(true);
            pintar2D_dinamic.opt.ini();
        }
    }//GEN-LAST:event_OptionDinamicMousePressed
    
    private void newNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_newNameKeyPressed
        if(evt.VK_ENTER == evt.getKeyCode())
            renameProject();
    }//GEN-LAST:event_newNameKeyPressed
    
    private void previewPos1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previewPos1MousePressed
        if(pintarMol.MOL_enable)
            if(previewPos.isEnabled()){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            pintarMol.babel.infBas.orderBas();
            edit.texto=pintarMol.babel.save_positions();
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz"))edit.Load(new File(pintarMol.babel.path+SEP+"step_"+xyz_step.getText()+".xyz"));
            else edit.Load(pintarMol.babel.inputFile);
            }
    }//GEN-LAST:event_previewPos1MousePressed
    
    private void savePos1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_savePos1MousePressed
        if(pintarMol.MOL_enable)
            if(savePos.isEnabled()){
            out.clear();
            pintarMol.babel.infBas.orderBas();
            out=pintarMol.babel.save_positions();
            cadena.writer(out,pintarMol.babel.inputFile);
            loadMOL();
            }
    }//GEN-LAST:event_savePos1MousePressed
    
    private void MiniEjesMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_MiniEjesMouseWheelMoved
        if(pintarMol.MOL_enable){
            if(pintarMol.imageBuffered!=null){
                if(pintarMol.nejes!=4){
                    if(pintarMol.BoolEje[0]) pintarMol.move(evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())),0,0);
                    if(pintarMol.BoolEje[1]) pintarMol.move(-evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())),0,0);
                    if(pintarMol.BoolEje[2]) pintarMol.move(0,evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())),0);
                    if(pintarMol.BoolEje[3]) pintarMol.move(0,-evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())),0);
                    if(pintarMol.BoolEje[4]) pintarMol.move(0,0,evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())));
                    if(pintarMol.BoolEje[5]) pintarMol.move(0,0,-evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())));
                } else{
                    if(pintarMol.BoolEje[0]||pintarMol.BoolEje[2]||pintarMol.BoolEje[4]) pintarMol.moveAtom(evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())));
                    else pintarMol.moveAtom(evt.getWheelRotation()*(new Calc().calcular(Tdespl.getText())));
                }
                if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
                ver3D_MOL();
            }
        }
    }//GEN-LAST:event_MiniEjesMouseWheelMoved
    
    private void MiniEjesMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiniEjesMouseDragged
        if(System.currentTimeMillis()>tiempo+MS_PER_FRAME)
            if(pintarMol.MOL_enable){
            if(pintarMol.imageBuffered!=null){
                if(!pintarMol.verdir && !pintarMol.selec){
                    double sensibilidadRaton=0.01;
                    double dx=(pintarMol.X_mouse_ini-evt.getX())*sensibilidadRaton;
                    double dy=-(pintarMol.Y_mouse_ini-evt.getY())*sensibilidadRaton;
                    pintarMol.C3D.girar(dx,dy);
                    pintarMol.X_mouse_ini=evt.getX();
                    pintarMol.Y_mouse_ini=evt.getY();
                } else{
                    pintarMol.X_mouse_fin=evt.getX();
                    pintarMol.Y_mouse_fin=evt.getY();
                }
                ver3D_MOL();
                tiempo=System.currentTimeMillis();
            }
            }
    }//GEN-LAST:event_MiniEjesMouseDragged
    
    private void axis_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_axis_4MouseClicked
        MiniEjes();
    }//GEN-LAST:event_axis_4MouseClicked
    
    private void axis_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_axis_3MouseClicked
        MiniEjes();
    }//GEN-LAST:event_axis_3MouseClicked
    
    private void axis_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_axis_1MouseClicked
        MiniEjes();
    }//GEN-LAST:event_axis_1MouseClicked
    
    private void axis_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_axis_2MouseClicked
        MiniEjes();
    }//GEN-LAST:event_axis_2MouseClicked
    
    private void MiniEjesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiniEjesMousePressed
        pintarMol.X_mouse_ini=evt.getX();
        pintarMol.Y_mouse_ini=evt.getY();
        if(pintarMol.MOL_enable) {
            if(evt.getButton()==evt.BUTTON3 ){
                if(pintarMol.nejes!=4){
                    if(pintarMol.BoolEje[0]) pintarMol.move((new Calc().calcular(Tdespl.getText())),0,0);
                    if(pintarMol.BoolEje[1]) pintarMol.move(-(new Calc().calcular(Tdespl.getText())),0,0);
                    if(pintarMol.BoolEje[2]) pintarMol.move(0,(new Calc().calcular(Tdespl.getText())),0);
                    if(pintarMol.BoolEje[3]) pintarMol.move(0,-(new Calc().calcular(Tdespl.getText())),0);
                    if(pintarMol.BoolEje[4]) pintarMol.move(0,0,(new Calc().calcular(Tdespl.getText())));
                    if(pintarMol.BoolEje[5]) pintarMol.move(0,0,-(new Calc().calcular(Tdespl.getText())));
                } else{
                    if(pintarMol.BoolEje[0]||pintarMol.BoolEje[2]||pintarMol.BoolEje[4]) pintarMol.moveAtom((new Calc().calcular(Tdespl.getText())));
                    else pintarMol.moveAtom(-(new Calc().calcular(Tdespl.getText())));
                }
                if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
                ver3D_MOL();
            }
            if(evt.getButton()==evt.BUTTON1){
                tiempo=System.currentTimeMillis();
            }
        }
    }//GEN-LAST:event_MiniEjesMousePressed
    
    private void MiniEjesMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiniEjesMouseMoved
        if(System.currentTimeMillis()>tiempo+MS_PER_FRAME)
            if(pintarMol.MOL_enable)
                if(pintarMol.miniEjesBuffered!=null){
            pintarMol.getN(evt.getX(),evt.getY());
            screenMiniejes = new BufferedImage(MiniEjes.getWidth()-dIc,MiniEjes.getHeight()-dIc, BufferedImage.TYPE_INT_RGB);
            screenMiniejes = pintarMol.pintarMiniEjes(screenMiniejes);
            MiniEjes.setIcon(new ImageIcon(screenMiniejes));
            tiempo=System.currentTimeMillis();
                }
    }//GEN-LAST:event_MiniEjesMouseMoved
    
    private void jMenuItem7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem7MousePressed
        new help(homexeo+"help/type/vasp.html").setVisible(true);
    }//GEN-LAST:event_jMenuItem7MousePressed
    
    private void jMenuItem1MousePressed1(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem1MousePressed1
        new help(homexeo+"help/type/castep.html").setVisible(true);
    }//GEN-LAST:event_jMenuItem1MousePressed1
    
    private void jhelpFireMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jhelpFireMousePressed
        new help(homexeo+"help/type/fireball.html").setVisible(true);
    }//GEN-LAST:event_jhelpFireMousePressed
    
    private void dos_help2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dos_help2MousePressed
        new help(homexeo+"help/utilities/calculator.html").setVisible(true);
    }//GEN-LAST:event_dos_help2MousePressed
    
    private void jhelpMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jhelpMousePressed
        new help(homexeo+"help/utilities/utilities.html").setVisible(true);
    }//GEN-LAST:event_jhelpMousePressed
    
    private void helpTypesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_helpTypesMousePressed
        new help(homexeo+"help/type/type.html").setVisible(true);
    }//GEN-LAST:event_helpTypesMousePressed
    
    private void jPanel36KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPanel36KeyPressed
        if(evt.VK_F1== evt.getKeyCode()) new help(homexeo+"help/type/xyz.html").setVisible(true);
    }//GEN-LAST:event_jPanel36KeyPressed
    
    private void jTabbedPane5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTabbedPane5KeyPressed
        if(evt.VK_F1== evt.getKeyCode()) new help(homexeo+"help/options/options.html").setVisible(true);
    }//GEN-LAST:event_jTabbedPane5KeyPressed
    
    private void pasteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pasteMousePressed
        if(pintarMol.MOL_enable && paste.isEnabled()){
            pintarMol.babel.infBas.pasteAtoms();
            pintarMol.babel.infBas.load_enlaces();
            ver3D_MOL();
        }
    }//GEN-LAST:event_pasteMousePressed
    
    private void copyMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_copyMousePressed
        if(pintarMol.MOL_enable && copy.isEnabled()){
            pintarMol.babel.infBas.copyAtoms();
            ver3D_MOL();
        }
    }//GEN-LAST:event_copyMousePressed
    
    private void jMenulOPENMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenulOPENMousePressed
        projectChooser.pack();
        projectChooser.setVisible(true);
        projectChooser.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        path_project.setText(new File(pintarMol.babel.path).getParent());
        projectOpen();
    }//GEN-LAST:event_jMenulOPENMousePressed
    
    private void CalcMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CalcMousePressed
        if(pintarMol.MOL_enable){
            jDCalc.pack();
            jDCalc.setVisible(true);
            jDCalc.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
            rescalateCalc.requestFocus();
        }
    }//GEN-LAST:event_CalcMousePressed
    
    private void jButton26MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton26MousePressed
        calcular();
        ver3D_MOL();
    }//GEN-LAST:event_jButton26MousePressed
    
    void calcular(){
        pintarMol.babel.infBas.bas=cal.calcularBAS(CalcX.getText(),CalcY.getText(),CalcZ.getText(),pintarMol.babel.infBas.bas);
    }
    
    private void jButton25MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton25MousePressed
        double a=Double.valueOf(rotText.getText()).doubleValue();
        a=a*Math.PI/180;
        CalcX.setText("x*cos("+a+")+y*sin("+a+")" );
        CalcY.setText("-x*sin("+a+")+y*cos("+a+")" );
        CalcZ.setText("z");
    }//GEN-LAST:event_jButton25MousePressed
    
    private void rescalateCalcMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rescalateCalcMousePressed
        CalcX.setText("x*"+resText.getText());
        CalcY.setText("y*"+resText.getText());
        CalcZ.setText("z*"+resText.getText());
    }//GEN-LAST:event_rescalateCalcMousePressed
    
    private void OpenProject3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenProject3MousePressed
        renameProject();
    }//GEN-LAST:event_OpenProject3MousePressed
    
    private void renameMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_renameMousePressed
        if(!TreeA.isSelectionEmpty()) renameOpen();
    }//GEN-LAST:event_renameMousePressed
    
    private void jButton23MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton23MousePressed
        colorArrows.setBackground( JColorChooser.showDialog( this , "arrow color", colorArrows.getBackground()));
        if(pintarMol.MOL_enable) ver3D_MOL();
    }//GEN-LAST:event_jButton23MousePressed
    
    private void jMenuItem2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem2MousePressed
        script.pack();
        script.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        script.setVisible(true);
        newFile=pintarMol.babel.getOutput();
        if(newFile!=null)outText.setText(newFile.getAbsolutePath());
        allow();
    }//GEN-LAST:event_jMenuItem2MousePressed
    
    private void jMenuItem_exportMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem_exportMousePressed
        Frame_FIREBALL.pack();
        Frame_FIREBALL.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        Frame_FIREBALL.setVisible(true);
    }//GEN-LAST:event_jMenuItem_exportMousePressed
    
    private void jMenu_ayudaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_ayudaMousePressed
        new help(homexeo+"help/index.html").setVisible(true);
    }//GEN-LAST:event_jMenu_ayudaMousePressed
    
    private void savePosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_savePosMousePressed
        if(pintarMol.MOL_enable)
            if(savePos.isEnabled()){
            out.clear();
            pintarMol.babel.infBas.orderBas();
            out=pintarMol.babel.save_positions();
            cadena.writer(out,pintarMol.babel.inputFile);
            loadMOL();
            }
    }//GEN-LAST:event_savePosMousePressed
    
    private void previewPosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previewPosMousePressed
        if(pintarMol.MOL_enable)
            if(previewPos.isEnabled()){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            pintarMol.babel.infBas.orderBas();
            edit.texto=pintarMol.babel.save_positions();
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz"))edit.Load(new File(pintarMol.babel.path+SEP+"step_"+xyz_step.getText()+".xyz"));
            else edit.Load(pintarMol.babel.inputFile);
            }
    }//GEN-LAST:event_previewPosMousePressed
    
    private void saveFixMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveFixMousePressed
        if(pintarMol.MOL_enable)
            if(saveFix.isEnabled()){
            out=pintarMol.babel.save_fix();
            cadena.writer(out,pintarMol.babel.inputFile);
            loadMOL();
            }
    }//GEN-LAST:event_saveFixMousePressed
    
    private void jMenu_vaspMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_vaspMousePressed
        jFrame_VASP.pack();
        jFrame_VASP.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        jFrame_VASP.setVisible(true);
    }//GEN-LAST:event_jMenu_vaspMousePressed
    
    private void Btn_vaspMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Btn_vaspMousePressed
        if(pintarMol.MOL_enable){
            pintarMol.babel.infBas.order_Castep();
            pintarMol.babel.read_vasp.res=Double.valueOf(rescalateVASP.getText()).doubleValue();
            pintarMol.babel.read_vasp.bas = pintarMol.babel.infBas.bas;
            pintarMol.babel.read_vasp.lvs = pintarMol.babel.infBas.lvs;
            new editor(homexeo,pintarMol.babel.path+SEP+"POSCAR.temp").Load(pintarMol.babel.read_vasp.writeOut());
        }
    }//GEN-LAST:event_Btn_vaspMousePressed
    
    private void xyz_load3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_load3MousePressed
        if(pintarMol.MOL_enable)
            if(previewPos.isEnabled()){
            pintarMol.babel.read_fireball.res=Double.valueOf(rescalateFIREBALL.getText()).doubleValue();
            pintarMol.babel.infBas.orderBas();
            pintarMol.babel.read_fireball.lvs=pintarMol.babel.infBas.lvs;
            pintarMol.babel.read_fireball.bas=pintarMol.babel.infBas.bas;
            new editor(homexeo,pintarMol.babel.path+SEP+"ini.bas").Load(pintarMol.babel.read_fireball.outlvs());
            }
    }//GEN-LAST:event_xyz_load3MousePressed
    
    private void xyz_load2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_load2MousePressed
        if(pintarMol.MOL_enable)
            if(previewPos.isEnabled()){
            pintarMol.babel.infBas.orderBas();
            pintarMol.babel.read_fireball.bas=pintarMol.babel.infBas.bas;
            new editor(homexeo,pintarMol.babel.path+SEP+"ini.bas").Load(pintarMol.babel.read_fireball.fix(true));
            }
    }//GEN-LAST:event_xyz_load2MousePressed
    
    private void xyz_load1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_load1MousePressed
        if(pintarMol.MOL_enable)
            if(previewPos.isEnabled()){
            pintarMol.babel.read_fireball.res=Double.valueOf(rescalateFIREBALL.getText()).doubleValue();
            pintarMol.babel.infBas.orderBas();
            pintarMol.babel.read_fireball.bas=pintarMol.babel.infBas.bas;
            new editor(homexeo,pintarMol.babel.path+SEP+"ini.bas").Load(pintarMol.babel.read_fireball.outbas());
            }
    }//GEN-LAST:event_xyz_load1MousePressed
    
    private void jMenuItem1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem1MousePressed
        jFrame_POVRAY.pack();
        jFrame_POVRAY.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        jFrame_POVRAY.setVisible(true);
    }//GEN-LAST:event_jMenuItem1MousePressed
    
    private void jMenu_castepMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_castepMousePressed
        jFrame_castep.pack();
        jFrame_castep.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        jFrame_castep.setVisible(true);
    }//GEN-LAST:event_jMenu_castepMousePressed
    
    private void jMenuIhoppingMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuIhoppingMousePressed
        javaSTM stm = new javaSTM(pintarMol.babel.path);
        stm.Iniciar(homexeo);
        stm.hopping();
    }//GEN-LAST:event_jMenuIhoppingMousePressed
    
    private void jMenuDinamicMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuDinamicMousePressed
        JFrame_dinamic.pack();
        JFrame_dinamic.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        JFrame_dinamic.setVisible(true);
        loadMOL();
        allow();
    }//GEN-LAST:event_jMenuDinamicMousePressed
    
    private void jButton49MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton49MousePressed
        if(pintarMol.MOL_enable){
            dialogo_color();
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton49MousePressed
    
    private void color_finMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_finMousePressed
        color_fin.setBackground(JColorChooser.showDialog( this , "color final", color_fin.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_finMousePressed
    
    private void color_inter_2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_inter_2MousePressed
        color_inter_2.setBackground(JColorChooser.showDialog( this , "color final", color_inter_2.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_inter_2MousePressed
    
    private void color_iniMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_iniMousePressed
        color_ini.setBackground(JColorChooser.showDialog( this , "color final", color_ini.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_iniMousePressed
    
    private void color_inter_1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_inter_1MousePressed
        color_inter_1.setBackground(JColorChooser.showDialog( this , "color final", color_inter_1.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_inter_1MousePressed
    
    private void Sinter1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Sinter1MouseDragged
        dialogo_color();
    }//GEN-LAST:event_Sinter1MouseDragged
    
    private void Sinter2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Sinter2MouseDragged
        dialogo_color();
    }//GEN-LAST:event_Sinter2MouseDragged
    
    private void jButton58MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton58MousePressed
        newFile =  new chooser().fileChoose("Open file x,y,z,y","open",mol_bas.getText()) ;
        if(newFile!=null) {
            pintarMol.xyztFile=newFile;
            pintarMol.xyzt=xyzt.isSelected();
            xyztFile.setText(newFile.getAbsolutePath());
            pintarMol.Load_xyzt();
        }
    }//GEN-LAST:event_jButton58MousePressed
    
    private void xyz_jSliderMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_jSliderMouseReleased
        if(xyz_jSlider.isEnabled()){
            int step=xyz_jSlider.getValue();
            xyz_step.setText(step+"");
            ver3D_MOL_xyz();
        }
    }//GEN-LAST:event_xyz_jSliderMouseReleased
    
    private void Btn_cellMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Btn_cellMousePressed
        if(pintarMol.MOL_enable){
            pintarMol.babel.infBas.order_Castep();
            pintarMol.babel.read_castep.res=Double.valueOf(rescalateCastep.getText()).doubleValue();
            pintarMol.babel.read_castep.bas = pintarMol.babel.infBas.bas;
            pintarMol.babel.read_castep.lvs = pintarMol.babel.infBas.lvs;
            new editor(homexeo,pintarMol.babel.path+SEP+"cst.cell").Load(pintarMol.babel.read_castep.CastepCell());
        }
    }//GEN-LAST:event_Btn_cellMousePressed
    
    private void loadBasLvsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadBasLvsMousePressed
        pintarMol.babel.read_fireball.basfile=new File(mol_bas.getText());
        pintarMol.babel.read_fireball.lvsfile=new File(mol_lvs.getText());
        pintarMol.babel.read_fireball.load_bas();
        pintarMol.babel.read_fireball.load_lvs();
        pintarMol.babel.infBas.bas=pintarMol.babel.read_fireball.bas;
        for(int i=0;i<3;i++)
            for(int j=0;j<3;j++)
                pintarMol.babel.infBas.lvs[i][j] = pintarMol.babel.read_fireball.lvs[i][j];
        ini_mol();
        mol_3d_enable(true);
        pintarMol.babel.infBas.seeCell_Vol=mol_seeVol.isSelected();
        pintarMol.babel.infBas.seeCell_ijk=mol_seeIndex.isSelected();
        pintarMol.firstTime=true;
        if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
        ver3D_MOL();
    }//GEN-LAST:event_loadBasLvsMousePressed
    
    private void jMenu_outMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_outMousePressed
        fireballOut.pack();
        fireballOut.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        fireballOut.setVisible(true);
        fireballOut.path=pintarMol.babel.path;
        fireballOut.homexeo=homexeo;
        fireballOut.HOME=HOME;
        fireballOut.outFile=pintarMol.babel.getOutput();
        fireballOut.infBas=pintarMol.babel.infBas;
        fireballOut.iniciar();
        fireballOut.allow();
    }//GEN-LAST:event_jMenu_outMousePressed
    
    private void jMenuOptionsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuOptionsMousePressed
        Options.pack();
        Options.setVisible(true);
        Options.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        Sinter1.setValue(pintarMol.posicion_1);
        Sinter2.setValue(pintarMol.posicion_2);
        color_ini.setBackground(pintarMol.colorIni);
        color_inter_1.setBackground(pintarMol.colorInter1);
        color_inter_2.setBackground(pintarMol.colorInter2);
        color_fin.setBackground(pintarMol.colorFin);
        dialogo_color();
    }//GEN-LAST:event_jMenuOptionsMousePressed
    
    private void loadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadMousePressed
        loadMOL();
    }//GEN-LAST:event_loadMousePressed
    
    private void open_mol3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_open_mol3MousePressed
        if(pintarMol.MOL_enable)
            new editor(homexeo,new File(pintarMol.babel.path+SEP+".").toString()).Load(pintarMol.babel.infBas.outXYZ());
    }//GEN-LAST:event_open_mol3MousePressed
    
    private void open_mol1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_open_mol1MousePressed
        if(pintarMol.MOL_enable)
            new show_picture(homexeo,new File(pintarMol.babel.path+SEP+"picture.jpg").toString()).plotBuffered(screen5Buffered);
    }//GEN-LAST:event_open_mol1MousePressed
    
    private void save_mol_gifMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_save_mol_gifMousePressed
        if(save_mol_gif.isEnabled())  new chooser().savePicture("Save file *.jpg","save",
                new File(pintarMol.babel.path+SEP+"picture.jpg").toString(),pintarMol.imageBuffered);
    }//GEN-LAST:event_save_mol_gifMousePressed
    
    private void open_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_open_molMousePressed
        load_file();
    }//GEN-LAST:event_open_molMousePressed
    
    private void Menu_openMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Menu_openMousePressed
        TreeA.clearSelection();
        projectChooser.pack();
        projectChooser.setVisible(true);
        projectChooser.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        path_project.setText(new File(pintarMol.babel.path).getParent());
        projectOpen();
    }//GEN-LAST:event_Menu_openMousePressed
    
    private void jMenu_beginMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_beginMousePressed
        Jbegin begin = new Jbegin();
        begin.iniciar(homexeo,HOME);
        begin.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        begin.setVisible(true);
    }//GEN-LAST:event_jMenu_beginMousePressed
    
    private void jMenu_stmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_stmMousePressed
        javaSTM stm = new javaSTM(pintarMol.babel.path);
        stm.Iniciar(homexeo);
        stm.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        stm.setVisible(true);
    }//GEN-LAST:event_jMenu_stmMousePressed
    
    private void jMenu_aboutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu_aboutMousePressed
        JDialog about = new JDialog() ;
        about.setSize(300,100);
        about.setTitle("about") ; // showMessageDialog("Eggs aren't supposed to be green.");
        JTextArea aboutArea = new JTextArea();
        aboutArea.setEditable(false);
        aboutArea.setText( " program : xeo \n Copyright 2008 by Daniel González Trabada \n GNU GENERAL PUBLIC LICENCE (GPL) \n dgtrabada@yahoo.com");
        about.add(aboutArea);
        about.setVisible(true);
    }//GEN-LAST:event_jMenu_aboutMousePressed
    
    private void openMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_openMousePressed
        loadMOL();
    }//GEN-LAST:event_openMousePressed
    
    private void verEjesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verEjesMouseClicked
        if(pintarMol.MOL_enable)     ver3D_MOL();
    }//GEN-LAST:event_verEjesMouseClicked
    
    private void mas_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mas_molMousePressed
        if(pintarMol.MOL_enable)  {
            pintarMol.C3D.mas();
            ver3D_MOL();
        }
    }//GEN-LAST:event_mas_molMousePressed
    
    private void zy_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_zy_molMousePressed
        if(pintarMol.MOL_enable){
            if(evt.getButton()==evt.BUTTON1)  pintarMol.C3D.Ozy();
            if(evt.getButton()==evt.BUTTON3)  pintarMol.C3D.Ozx();
            ver3D_MOL();
        }
    }//GEN-LAST:event_zy_molMousePressed
    
    private void xy_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xy_molMousePressed
        if(pintarMol.MOL_enable){
            if(evt.getButton()==evt.BUTTON1) pintarMol.C3D.Oxy();
            if(evt.getButton()==evt.BUTTON3) pintarMol.C3D.Omyx();
            ver3D_MOL();
        }
    }//GEN-LAST:event_xy_molMousePressed
    
    private void yx_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_yx_molMousePressed
        if(pintarMol.MOL_enable){
            if(evt.getButton()==evt.BUTTON1)  pintarMol.C3D.Oyx();
            if(evt.getButton()==evt.BUTTON3)  pintarMol.C3D.Oxmy();
            ver3D_MOL();
        }
    }//GEN-LAST:event_yx_molMousePressed
    
    private void xz_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xz_molMousePressed
        if(pintarMol.MOL_enable){
            if(evt.getButton()==evt.BUTTON1) pintarMol.C3D.Oxz();
            if(evt.getButton()==evt.BUTTON3) pintarMol.C3D.Oyz();
            ver3D_MOL();
        }
    }//GEN-LAST:event_xz_molMousePressed
    
    private void menos_molMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menos_molMousePressed
        if(pintarMol.MOL_enable)  {
            pintarMol.C3D.menos();
            ver3D_MOL();
        }
    }//GEN-LAST:event_menos_molMousePressed
    
    private void diffRadioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diffRadioMouseClicked
        if(pintarMol.MOL_enable)     ver3D_MOL();
    }//GEN-LAST:event_diffRadioMouseClicked
    
    private void PERSMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PERSMouseDragged
        if(pintarMol.MOL_enable)     ver3D_MOL();
    }//GEN-LAST:event_PERSMouseDragged
    
    private void screen_xyzMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_screen_xyzMouseWheelMoved
        if(evt.getWheelRotation()<0){
            pintar2D_dinamic.mouseIni((int) (evt.getX()-screen_xyz.getWidth()/4),(int) (evt.getY()-screen_xyz.getHeight()/4),true);
            pintar2D_dinamic.mouseFin((int) (evt.getX()+screen_xyz.getWidth()/4),(int) (evt.getY()+screen_xyz.getHeight()/4),false);
        }else{
            pintar2D_dinamic.mouseIni((int) (evt.getX()-screen_xyz.getWidth()),(int) (evt.getY()-screen_xyz.getHeight()),true);
            pintar2D_dinamic.mouseFin((int) (evt.getX()+screen_xyz.getWidth()),(int) (evt.getY()+screen_xyz.getHeight()),false);
        }
        if(screen_xyz.isEnabled()){
            pintar2D_dinamic.lupa2D();
            pintar2D_dinamic.opt.ajustarMaximos=false;
            if(pintar2D_dinamic.opt.isVisible()) pintar2D_dinamic.opt.ini();
            dinamic dinamic=new dinamic();
            dinamic.start();
            pintar2D_dinamic.mouse=false;
        }
    }//GEN-LAST:event_screen_xyzMouseWheelMoved
    
    private void jScrollPane6ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jScrollPane6ComponentResized
        screen_xyz.setIcon(null);
    }//GEN-LAST:event_jScrollPane6ComponentResized
    
    private void screen5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_screen5KeyPressed
        if(evt.VK_F1== evt.getKeyCode()) new help(homexeo+"help/key/key.html").setVisible(true);
        if(pintarMol.MOL_enable) {
            if(evt.VK_DELETE == evt.getKeyCode() ) pintarMol.babel.infBas.eliminate();
            if(evt.VK_ADD == evt.getKeyCode() ) pintarMol.C3D.mas();
            if(evt.VK_MINUS == evt.getKeyCode() ) pintarMol.C3D.menos();
            if(evt.VK_DOWN == evt.getKeyCode() ) {
                for(int i=0;i<6;i++)
                    if(pintarMol.BoolEje[i]) {
                    pintarMol.BoolEje[i]=false;
                    if(i==5) pintarMol.BoolEje[0]=true;
                    else pintarMol.BoolEje[i+1]=true;
                    i=6;
                    }
                if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
            }
            if(evt.VK_UP == evt.getKeyCode() ){
                for(int i=0;i<6;i++)
                    if(pintarMol.BoolEje[i]) {
                    pintarMol.BoolEje[i]=false;
                    if(i==0) pintarMol.BoolEje[5]=true;
                    else pintarMol.BoolEje[i-1]=true;
                    i=6;
                    }
                if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
            }
            if(evt.VK_LEFT == evt.getKeyCode() ){
                if(pintarMol.BoolEje[0]) pintarMol.move((new Calc().calcular(Tdespl.getText())),0,0);
                if(pintarMol.BoolEje[1]) pintarMol.move(-(new Calc().calcular(Tdespl.getText())),0,0);
                if(pintarMol.BoolEje[2]) pintarMol.move(0,(new Calc().calcular(Tdespl.getText())),0);
                if(pintarMol.BoolEje[3]) pintarMol.move(0,-(new Calc().calcular(Tdespl.getText())),0);
                if(pintarMol.BoolEje[4]) pintarMol.move(0,0,(new Calc().calcular(Tdespl.getText())));
                if(pintarMol.BoolEje[5]) pintarMol.move(0,0,-(new Calc().calcular(Tdespl.getText())));
                if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
            }
            if(evt.VK_RIGHT == evt.getKeyCode() ){
                if(pintarMol.BoolEje[0]) pintarMol.move(-(new Calc().calcular(Tdespl.getText())),0,0);
                if(pintarMol.BoolEje[1]) pintarMol.move((new Calc().calcular(Tdespl.getText())),0,0);
                if(pintarMol.BoolEje[2]) pintarMol.move(0,-(new Calc().calcular(Tdespl.getText())),0);
                if(pintarMol.BoolEje[3]) pintarMol.move(0,(new Calc().calcular(Tdespl.getText())),0);
                if(pintarMol.BoolEje[4]) pintarMol.move(0,0,-(new Calc().calcular(Tdespl.getText())));
                if(pintarMol.BoolEje[5]) pintarMol.move(0,0,(new Calc().calcular(Tdespl.getText())));
                if(seeBond.isSelected()) pintarMol.babel.infBas.load_enlaces();
            }
            
            
            ver3D_MOL();
            
            KEY_comun(evt);
        }
    }//GEN-LAST:event_screen5KeyPressed
    
    private void TreeAKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TreeAKeyReleased
        if(evt.VK_UP == evt.getKeyCode() ) {  selectProject(); loadMOL(); }
        if(evt.VK_DOWN == evt.getKeyCode() ){  selectProject(); loadMOL(); }
    }//GEN-LAST:event_TreeAKeyReleased
    
    private void timeStep_TextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_timeStep_TextKeyPressed
        if(evt.VK_ENTER   == evt.getKeyCode() )
            if(reload_dinamic.isEnabled()){
            pintar2D_dinamic.opt.ajustarMaximos=true;
            dinamic dinamic=new dinamic();
            dinamic.start();
            }
    }//GEN-LAST:event_timeStep_TextKeyPressed
    
    private void jButton57MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton57MousePressed
        new help(homexeo+"help/utilities/bulk.html").setVisible(true);
    }//GEN-LAST:event_jButton57MousePressed
    
    private void TreeAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TreeAKeyPressed
        KEY_comun(evt);
        if(evt.VK_F7==evt.getKeyCode()) {
            if(jSplitForm.getDividerLocation()==1)jSplitForm.setDividerLocation(180);
            else jSplitForm.setDividerLocation(1);
        }
        if(evt.VK_F1== evt.getKeyCode()) new help(homexeo+"help/key/key.html").setVisible(true);
        if(evt.VK_ENTER   == evt.getKeyCode() ){ selectProject(); loadMOL(); }
        if(evt.VK_DELETE  == evt.getKeyCode() ) TreeA_delete();
        if(evt.getKeyCode() == 104) TreeA_up();
        if(evt.getKeyCode() == 98) TreeA_down();
        if(evt.VK_F2 == evt.getKeyCode())renameOpen();
        if(evt.VK_RIGHT == evt.getKeyCode()){
            nInsp++;
            if(nInsp>=ins.size())nInsp=0;
            Limpiar_Inspector();
            Inspector();
        }
        if(evt.VK_LEFT == evt.getKeyCode()){
            nInsp--;
            if(nInsp<0)nInsp=ins.size()-1;
            Limpiar_Inspector();
            Inspector();
        }
    }//GEN-LAST:event_TreeAKeyPressed
    
    private void note_textKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_note_textKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            selections=TreeA.getSelectionRows();
            if(!TreeA.isSelectionEmpty()) dir.add(selections[0]-1,"note "+note_text.getText());
            else dir.add(0,"note "+note_text.getText());
            Inspector();
            projectOpen();
        }
    }//GEN-LAST:event_note_textKeyPressed
    
    private void OpenProject2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenProject2MousePressed
        selections=TreeA.getSelectionRows();
        if(!TreeA.isSelectionEmpty()) dir.add(selections[0],"note "+note_text.getText());
        else dir.add(0,"note "+note_text.getText());
        Inspector();
        projectOpen();
        if(selections!=null) TreeA.setSelectionRow(selections[0]+1);
    }//GEN-LAST:event_OpenProject2MousePressed
    
    private void seeChargesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seeChargesMouseClicked
        if(pintarMol.MOL_enable)  ver3D_MOL();
    }//GEN-LAST:event_seeChargesMouseClicked
    
    private void TreeAMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TreeAMouseEntered
        boolean clean=false;
        InspLabel.setEnabled(false);
        for (int i = 0; i< dir.size(); i++)
            if(!new File(dir.elementAt(i).toString()).exists() && !cadena.readCol(1,dir.elementAt(i).toString()).equals("note"))
                clean = true;
        if(clean){
            Limpiar_Inspector();
            Inspector();
        }
    }//GEN-LAST:event_TreeAMouseEntered
    
    private void Frame_FIREBALLComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_Frame_FIREBALLComponentResized
        screen_out.setIcon(null);
        screen_xyz.setIcon(null);
    }//GEN-LAST:event_Frame_FIREBALLComponentResized
    
    private void jButton55MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton55MousePressed
        bulk.nameFile=file_Bulk.getText();
        bulk.bcc=bcc.isSelected();
        bulk.fcc=fcc.isSelected();
        bulk.Zincblende=zincblende.isSelected();
        bulk.usefile=fileBulk.isSelected();
        bulk.lvsFile=file_Bulk_lvs.getText();
        bulk.opt=OptBulk.isSelected();
        bulk.makeBulk();
        edit_Bulk.setText(bulk.out);
    }//GEN-LAST:event_jButton55MousePressed
    
    private void jMenuItemBulkMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItemBulkMousePressed
        Frame_Bulk.pack();
        Frame_Bulk.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        Frame_Bulk.setVisible(true);
    }//GEN-LAST:event_jMenuItemBulkMousePressed
    
    private void jButton54MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton54MousePressed
        newFile =  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path) ;
        if(newFile!=null) file_Bulk_lvs.setText(newFile.getAbsolutePath());
    }//GEN-LAST:event_jButton54MousePressed
    
    private void jButton53MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton53MousePressed
        newFile =  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path) ;
        if(newFile!=null) {
            bulk.nameFile=newFile.getAbsolutePath();
            file_Bulk.setText(newFile.getAbsolutePath());
        }
    }//GEN-LAST:event_jButton53MousePressed
    
    private void jSplitFixComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jSplitFixComponentResized
        screen5.setIcon(null);
        jSplitPaneFix.setDividerLocation(16);
    }//GEN-LAST:event_jSplitFixComponentResized
    
    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        screen5.setIcon(null);
    }//GEN-LAST:event_formComponentResized
    
    private void jButton39MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton39MousePressed
        newFile =  new chooser().ProjectChoose("open the out file i.e.  fireball > out file","open file output",new File(getTitle()),pintarMol.babel.path) ;
        if(newFile != null) outText.setText(newFile.getAbsolutePath());
        allow();
    }//GEN-LAST:event_jButton39MousePressed
    
    private void path_projectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_path_projectKeyPressed
        if(evt.VK_ENTER == evt.getKeyCode())projectOpen();
    }//GEN-LAST:event_path_projectKeyPressed
    
    
    private void ProjectTreeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProjectTreeMouseClicked
        if(ProjectTree.getSelectionPath() != null)
            if(ProjectTree.getSelectionPath().getPathCount() > 1)
                if(ProjectTree.getSelectionPath().getPathComponent(1).toString().equals("..")){
            newFile=(new File(path_project.getText()).getParentFile());
            if(newFile.exists())path_project.setText(newFile.toString());
            projectOpen();
                }else{
            newFile=new File(path_project.getText()+SEP+""+ProjectTree.getPathForLocation(evt.getX(),evt.getY()).getPathComponent(1).toString());
            pintarMol.babel.path=newFile.getAbsolutePath();
            pintarMol.babel.SORT();
            tipo.setText(pintarMol.babel.nameSort[pintarMol.babel.sort]);
                }
        if(evt.getButton()==evt.BUTTON3) insertInTreeA();
    }//GEN-LAST:event_ProjectTreeMouseClicked
    
    private void jMenuItem6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem6MousePressed
        new editor(homexeo,pintarMol.babel.path+SEP+".").setVisible(true);
    }//GEN-LAST:event_jMenuItem6MousePressed
    
    private void mol_seeIndexMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mol_seeIndexMouseClicked
        mol_seeVol.setSelected(false);
    }//GEN-LAST:event_mol_seeIndexMouseClicked
    
    private void mol_seeVolMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mol_seeVolMouseClicked
        mol_seeIndex.setSelected(false);
    }//GEN-LAST:event_mol_seeVolMouseClicked
    
    private void DownMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DownMousePressed
        TreeA_down();
    }//GEN-LAST:event_DownMousePressed
    
    private void UpMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpMousePressed
        TreeA_up();
    }//GEN-LAST:event_UpMousePressed
    
    private void jButton67MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton67MousePressed
        if(pintarMol.MOL_enable){
            if(cadena.nCol(Giro_centro.getText())==3 &&
                    cadena.nCol(Giro_Z.getText())==3 &&
                    cadena.nCol(Giro_X.getText())==3 ){
                pintarMol.babel.infBas.rotate(Giro_centro.getText(),Giro_Z.getText(),Giro_X.getText());
                pintarMol.firstTime=true;
                ver3D_MOL();
            }
        }
    }//GEN-LAST:event_jButton67MousePressed
    
    private void loadRotMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadRotMousePressed
        if(pintarMol.MOL_enable){
            int atomo = pintarMol.babel.infBas.givePos_fromBas((int) Double.valueOf(atomo_1.getText()).doubleValue()-1);
            Giro_centro.setText(pintarMol.babel.infBas.bas.get(atomo).R[0]+" "+pintarMol.babel.infBas.bas.get(atomo).R[1]+" "+pintarMol.babel.infBas.bas.get(atomo).R[2]);
            atomo = pintarMol.babel.infBas.givePos_fromBas((int) Double.valueOf(atomo_2.getText()).doubleValue()-1);
            Giro_Z.setText(pintarMol.babel.infBas.bas.get(atomo).R[0]+" "+pintarMol.babel.infBas.bas.get(atomo).R[1]+" "+pintarMol.babel.infBas.bas.get(atomo).R[2]);
            atomo = pintarMol.babel.infBas.givePos_fromBas((int) Double.valueOf(atomo_3.getText()).doubleValue()-1);
            Giro_X.setText(pintarMol.babel.infBas.bas.get(atomo).R[0]+" "+pintarMol.babel.infBas.bas.get(atomo).R[1]+" "+pintarMol.babel.infBas.bas.get(atomo).R[2]);
        }
    }//GEN-LAST:event_loadRotMousePressed
    
    private void jMenuItem5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem5MousePressed
        new calculadora_bas(mol_bas.getText(),homexeo);
    }//GEN-LAST:event_jMenuItem5MousePressed
    
    private void jMenuItem4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem4MousePressed
        new calculadora(homexeo,true);
    }//GEN-LAST:event_jMenuItem4MousePressed
    
    private void jButton62MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton62MousePressed
        if(pintarMol.MOL_enable){
            ini_mol();
            pintarMol.load();
            pintarMol.firstTime=true;
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton62MousePressed
    
    private void utilitiesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_utilitiesMousePressed
        
    }//GEN-LAST:event_utilitiesMousePressed
    
    private void xyz_jSliderMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_jSliderMouseDragged
        if(System.currentTimeMillis()>tiempo+MS_PER_FRAME)
            if(xyz_jSlider.isEnabled()){
            int step=xyz_jSlider.getValue();
            xyz_step.setText(step+"");
            xyz_end.setText("of "+pintarMol.babel.infBas.xyz.size());
            ver3D_MOL_xyz();
            tiempo=System.currentTimeMillis();
            }
    }//GEN-LAST:event_xyz_jSliderMouseDragged
    
    private void xyz_load_stepMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_load_stepMousePressed
        if(xyz_load_step.isEnabled()){
            int step=(int) Double.valueOf(xyz_step.getText()).doubleValue();
            if(step>=(pintarMol.babel.infBas.xyz.size()-1))step=0;
            xyz_step.setText(step+"");
            xyz_end.setText("of "+pintarMol.babel.infBas.xyz.size());
            ver3D_MOL_xyz();
        }
    }//GEN-LAST:event_xyz_load_stepMousePressed
    
    private void xyz_menosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_menosMousePressed
        if(xyz_menos.isEnabled()){
            int step=(int) Double.valueOf(xyz_step.getText()).doubleValue();
            if(step<=0) step=(pintarMol.babel.infBas.xyz.size()-1);
            else step--;
            xyz_step.setText(step+"");
            ver3D_MOL_xyz();
        }
    }//GEN-LAST:event_xyz_menosMousePressed
    
    private void xyz_masMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xyz_masMousePressed
        if(xyz_mas.isEnabled()){
            int step=(int) Double.valueOf(xyz_step.getText()).doubleValue();
            if(step>=(pintarMol.babel.infBas.xyz.size()-1))step=0;
            else step++;
            xyz_step.setText(step+"");
            ver3D_MOL_xyz();
        }
    }//GEN-LAST:event_xyz_masMousePressed
    
    private void jButton56MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton56MousePressed
        newFile=pintarMol.babel.getXYZ();
        if(evt.getButton()==evt.BUTTON1) {
            if(newFile==null) newFile=  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path) ;
            else{
                if(newFile.exists()) newFile=  new chooser().fileChoose("Open file *.xyz","open",newFile.getAbsolutePath()) ;
                else newFile=  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path) ;
            }
        }
        if(newFile!=null) {
            pintarMol.babel.sort=1;
            obtainGif.setText("convert -delay 100  "+newFile.getParent()+SEP+"frames/*.jpg "+newFile.getParent()+SEP+"out.gif");
            open_xyz open_xyz=new open_xyz();
            open_xyz.fileXYZ=newFile;
            //--------- cargamos el primer paso -----
            pintarMol.babel.firstStepXYZ(newFile);
            xyz_load_step.setEnabled(true);
            xyz_jSlider.setEnabled(true);
            pintarMol.firstTime=true;
            ver3D_MOL();
            //---------------------------------------
            open_xyz.reload();
            open_xyz.start();
        }
    }//GEN-LAST:event_jButton56MousePressed
    
    private void jButton52MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton52MousePressed
        newFile =  new chooser().fileChoose("Open file *.xyz","open",mol_bas.getText()) ;
        if(newFile!=null) {
            ini_mol();
            pintarMol.firstTime=true;
            mol_bas.setText(newFile.getAbsolutePath());
            mol_3d_enable(true);
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton52MousePressed
    
    private void jButton51MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton51MousePressed
        newFile =  new chooser().fileChoose("Open file *.xyz","open",mol_bas.getText()) ;
        if(newFile!=null) {
            mol_lvs.setText(newFile.getAbsolutePath());
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton51MousePressed
    
    private void seePosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seePosMouseClicked
        if(pintarMol.MOL_enable)  ver3D_MOL();
    }//GEN-LAST:event_seePosMouseClicked
    
    private void screen5MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen5MouseReleased
        if(pintarMol.MOL_enable){
            pintarMol.X_mouse_fin=evt.getX();
            pintarMol.Y_mouse_fin=evt.getY();
            //  if(evt.getButton()==evt.BUTTON1) ver3D_MOL();
            if(evt.getButton()==evt.BUTTON2){
                natom = pintarMol.babel.infBas.giveAtom(evt.getX(),evt.getY());
                //corregimos la posicion del mouse poniendola encima del atomo mas cercano
                pintarMol.X_mouse_fin = pintarMol.babel.infBas.bas.get(natom).X;
                pintarMol.Y_mouse_fin = pintarMol.babel.infBas.bas.get(natom).Y;
                atom4=pintarMol.babel.infBas.bas.get(natom).posBas;
                if((atom2!=atom3)||(atom4==atom1)) pintarMol.babel.infBas.load_distancia(atom3,atom4);
                else{
                    pintarMol.babel.infBas.load_distancia(atom1,atom2);
                    pintarMol.babel.infBas.load_angulo(atom1,atom2,atom4);
                }
                pintarMol.verdir=false;
                atom2=atom4;
                atom1=atom3;
                ver3D_MOL();
            }
            if(evt.getButton()==evt.BUTTON3){
                pintarMol.selec=false;
                pintarMol.selecAtoms();
                ver3D_MOL();
            }
        }
    }//GEN-LAST:event_screen5MouseReleased
    
    private void jButton31MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton31MousePressed
        if(pintarMol.MOL_enable){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            pintarMol.babel.infBas.order_Castep();
            edit.texto=pintarMol.babel.save_positions();
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz"))edit.Load(new File(pintarMol.babel.path+SEP+"step_"+xyz_step.getText()+".xyz"));
            else edit.Load(pintarMol.babel.inputFile);
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton31MousePressed
    
    private void previewFixMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previewFixMousePressed
        if(pintarMol.MOL_enable)
            if(previewFix.isEnabled()){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            edit.texto=pintarMol.babel.save_fix();
            edit.Load(pintarMol.babel.inputFile);
            }
        
    }//GEN-LAST:event_previewFixMousePressed
    
    private void TOLMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TOLMouseDragged
        if(pintarMol.MOL_enable){
            pintarMol.babel.infBas.load_enlaces();
            ver3D_MOL();
        }
    }//GEN-LAST:event_TOLMouseDragged
    
    private void CheckFragmentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CheckFragmentsMouseClicked
        if(pintarMol.MOL_enable)     ver3D_MOL();
    }//GEN-LAST:event_CheckFragmentsMouseClicked
    
    private void seeBondMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seeBondMouseClicked
        if(pintarMol.MOL_enable){
            pintarMol.babel.infBas.load_enlaces();
            ver3D_MOL();
        }
    }//GEN-LAST:event_seeBondMouseClicked
    
    private void selectFixAtomsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selectFixAtomsMousePressed
        if(pintarMol.MOL_enable){
            pintarMol.babel.infBas.SelectFrag();
            ver3D_MOL();
        }
    }//GEN-LAST:event_selectFixAtomsMousePressed
    
    private void jButton44MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton44MousePressed
        if(pintarMol.MOL_enable){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            pintarMol.babel.infBas.orderX();
            edit.texto=pintarMol.babel.save_positions();
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz"))edit.Load(new File(pintarMol.babel.path+SEP+"step_"+xyz_step.getText()+".xyz"));
            else edit.Load(pintarMol.babel.inputFile);
            ver3D_MOL();
            //   new editor(homexeo,pintarMol.babel.path+SEP+".").Load(pintarMol.babel.infBas.outXYZ());
        }
    }//GEN-LAST:event_jButton44MousePressed
    
    private void jButton50MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton50MousePressed
        if(pintarMol.MOL_enable){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            pintarMol.babel.infBas.orderY();
            edit.texto=pintarMol.babel.save_positions();
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz"))edit.Load(new File(pintarMol.babel.path+SEP+"step_"+xyz_step.getText()+".xyz"));
            else edit.Load(pintarMol.babel.inputFile);
            ver3D_MOL();
            //   new editor(homexeo,pintarMol.babel.path+SEP+".").Load(pintarMol.babel.infBas.outXYZ());
        }
    }//GEN-LAST:event_jButton50MousePressed
    
    private void jButton43MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton43MousePressed
        if(pintarMol.MOL_enable){
            editor edit=new editor(homexeo,pintarMol.babel.path);
            pintarMol.babel.infBas.orderZ();
            edit.texto=pintarMol.babel.save_positions();
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz"))edit.Load(new File(pintarMol.babel.path+SEP+"step_"+xyz_step.getText()+".xyz"));
            else edit.Load(pintarMol.babel.inputFile);
            ver3D_MOL();
            //   new editor(homexeo,pintarMol.babel.path+SEP+".").Load(pintarMol.babel.infBas.outXYZ());
        }
    }//GEN-LAST:event_jButton43MousePressed
    
    private void jButton37MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton37MousePressed
        if(pintarMol.MOL_enable) {
            pintarMol.babel.infBas.eliminate();
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton37MousePressed
    
    private void jButton36MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton36MousePressed
        if(pintarMol.MOL_enable) {
            pintarMol.babel.infBas.duplicar();
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton36MousePressed
    
    private void jButton35MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton35MousePressed
        if(pintarMol.MOL_enable) {
            pintarMol.babel.infBas.changeCharge((int) Double.valueOf(Z_all.getText()).doubleValue());
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton35MousePressed
    
    
    boolean dobleClick=false;
    private void screen5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen5MouseClicked
        if(pintarMol.imageBuffered!=null){
            if(evt.BUTTON1==evt.getButton() && pintarMol.MOL_enable)
                if(evt.getClickCount()==2) {
                if(!dobleClick){
                    dobleClick=true;
                    pintarMol.verdir=true;
                    natom = pintarMol.babel.infBas.giveAtom(evt.getX(),evt.getY()); //es carga con el bas
                    //corregimos la posicion del mouse poniendola encima del atomo mas cercano
                    pintarMol.X_mouse_ini =  pintarMol.babel.infBas.bas.get(natom).X;
                    pintarMol.Y_mouse_ini =  pintarMol.babel.infBas.bas.get(natom).Y;
                    atom3=pintarMol.babel.infBas.bas.get(natom).posBas;
                } else {
                    dobleClick=false;
                    pintarMol.verdir=false;
                    natom = pintarMol.babel.infBas.giveAtom(evt.getX(),evt.getY());
                    //corregimos la posicion del mouse poniendola encima del atomo mas cercano
                    pintarMol.X_mouse_fin = pintarMol.babel.infBas.bas.get(natom).X;
                    pintarMol.Y_mouse_fin = pintarMol.babel.infBas.bas.get(natom).Y;
                    atom4=pintarMol.babel.infBas.bas.get(natom).posBas;
                    if((atom2!=atom3)||(atom4==atom1)) {
                        if(pintarMol.babel.sort==1) pintarMol.babel.infBas.load_distancia_xyz(atom3,atom4);
                        else pintarMol.babel.infBas.load_distancia(atom3,atom4);
                    } else{
                        if(pintarMol.babel.sort==1){
                            pintarMol.babel.infBas.load_distancia_xyz(atom1,atom2);
                            pintarMol.babel.infBas.load_angulo_xyz(atom1,atom2,atom4);
                        }else{
                            pintarMol.babel.infBas.load_distancia(atom1,atom2);
                            pintarMol.babel.infBas.load_angulo(atom1,atom2,atom4);
                        }
                    }
                    atom2=atom4;
                    atom1=atom3;
                }
                }
            natom = pintarMol.babel.infBas.giveAtom(evt.getX(),evt.getY());
            pintarMol.babel.infBas.bas.get(natom).selec=(!pintarMol.babel.infBas.bas.get(natom).selec);
            ver3D_MOL();
        }
    }//GEN-LAST:event_screen5MouseClicked
    
    private void screen5MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_screen5MouseWheelMoved
        if(pintarMol.MOL_enable){
            if(pintarMol.imageBuffered!=null){
                pintarMol.C3D.a= pintarMol.C3D.a*Math.pow(1.5,evt.getWheelRotation());
                ver3D_MOL();
            }
        }
    }//GEN-LAST:event_screen5MouseWheelMoved
    
    long MS_PER_FRAME=50;
    private void screen5MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen5MouseDragged
        if(System.currentTimeMillis()>tiempo+MS_PER_FRAME)
            if(pintarMol.MOL_enable){
            if(pintarMol.imageBuffered!=null){
                if(!pintarMol.verdir && !pintarMol.selec){
                    double sensibilidadRaton=0.01;
                    double dx=(pintarMol.X_mouse_ini-evt.getX())*sensibilidadRaton;
                    double dy=-(pintarMol.Y_mouse_ini-evt.getY())*sensibilidadRaton;
                    pintarMol.C3D.girar(dx,dy);
                    pintarMol.X_mouse_ini=evt.getX();
                    pintarMol.Y_mouse_ini=evt.getY();
                } else{
                    pintarMol.X_mouse_fin=evt.getX();
                    pintarMol.Y_mouse_fin=evt.getY();
                }
                ver3D_MOL();
                tiempo=System.currentTimeMillis();
            }
            }
    }//GEN-LAST:event_screen5MouseDragged
    
    int natom;
    private void screen5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen5MousePressed
        if(pintarMol.MOL_enable){
            if(!dobleClick){
                pintarMol.X_mouse_ini=evt.getX();
                pintarMol.Y_mouse_ini=evt.getY();
            }
            if(evt.getButton()==evt.BUTTON2){
                pintarMol.verdir=true;
                natom = pintarMol.babel.infBas.giveAtom(evt.getX(),evt.getY()); //es carga con el bas
                //corregimos la posicion del mouse poniendola encima del atomo mas cercano
                pintarMol.X_mouse_ini =  pintarMol.babel.infBas.bas.get(natom).X;
                pintarMol.Y_mouse_ini =  pintarMol.babel.infBas.bas.get(natom).Y;
                atom3=pintarMol.babel.infBas.bas.get(natom).posBas;
            }
            if(evt.getButton()==evt.BUTTON3){
                pintarMol.selec=true;
            }
            if(evt.getButton()==evt.BUTTON1 && pintarMol.babel.infBas.LoadingXYZ){
                tiempo=System.currentTimeMillis();
                int step=(int) Double.valueOf(xyz_step.getText()).doubleValue();
                if(step>=(pintarMol.babel.infBas.xyz.size()-1))step=0;
                xyz_step.setText(step+"");
                xyz_end.setText("of "+pintarMol.babel.infBas.xyz.size());
                ver3D_MOL_xyz();
            }
        }
        //give the focus
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                screen5.requestFocus();
            }
        });
    }//GEN-LAST:event_screen5MousePressed
    
    private void jButton21MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MousePressed
        if(pintarMol.MOL_enable) {
            pintarMol.ajustar_centro();
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton21MousePressed
    
    private void jButton20MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MousePressed
        colorEjes.setBackground( JColorChooser.showDialog( this , "axis color", colorEjes.getBackground()));
        if(pintarMol.MOL_enable) ver3D_MOL();
    }//GEN-LAST:event_jButton20MousePressed
    
    private void jButton18MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MousePressed
        colorFondo.setBackground( JColorChooser.showDialog( this , "background color", colorFondo.getBackground()));
        if(pintarMol.MOL_enable) ver3D_MOL();
    }//GEN-LAST:event_jButton18MousePressed
    
    private void jButton9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MousePressed
        if(pintarMol.MOL_enable){
            pintarMol.firstTime=true;
            ver3D_MOL();
        }
    }//GEN-LAST:event_jButton9MousePressed
    
    private void reload_dinamicMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reload_dinamicMousePressed
        if(reload_dinamic.isEnabled()){
            pintar2D_dinamic.opt.ajustarMaximos=false;
            dinamic dinamic=new dinamic();
            dinamic.start();
        }
    }//GEN-LAST:event_reload_dinamicMousePressed
    
    private void jButton33MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton33MousePressed
        if(jButton33.isEnabled())
            new show_picture(homexeo,pintar2D_dinamic.inputfile2D.getAbsolutePath()).plotBuffered(pintar2D_dinamic.imageBuffered);
    }//GEN-LAST:event_jButton33MousePressed
    
    private void save_dinamicMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_save_dinamicMousePressed
        if(save_dinamic.isEnabled())
            new chooser().savePicture("Save file *.jpg","save",pintar2D_dinamic.inputfile2D.getAbsolutePath(),pintar2D_dinamic.imageBuffered);
    }//GEN-LAST:event_save_dinamicMousePressed
    
    private void open_dinamicMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_open_dinamicMousePressed
        newFile =  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path+SEP+".") ;
        if(newFile!=null){
            pintar2D_dinamic.inputfile2D=newFile;
            pintar2D_dinamic.opt.ajustarMaximos=true;
            dinamic dinamic=new dinamic();
            dinamic.start();
        }
    }//GEN-LAST:event_open_dinamicMousePressed
    
    private void jButton32MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton32MousePressed
        if(jButton32.isEnabled()){
            newFile = new File(pintarMol.babel.path+"/answer.xyz") ;
            if(newFile.exists()){
                pintar2D_dinamic.inputfile2D=newFile;
                pintar2D_dinamic.opt.ajustarMaximos=true;
                dinamic dinamic=new dinamic();
                dinamic.start();
            }
        }
    }//GEN-LAST:event_jButton32MousePressed
    
    private void screen_xyzMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_xyzMouseDragged
        if(screen_xyz.isEnabled()&& pintar2D_dinamic.mouse){
            pintar2D_dinamic.mouseFin(evt.getX(),evt.getY(),true);
            screen_xyz.setIcon(new ImageIcon(pintar2D_dinamic.Selec()));
        }
    }//GEN-LAST:event_screen_xyzMouseDragged
    
    private void screen_xyzMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_xyzMouseReleased
        if(evt.getButton()==evt.BUTTON1 && screen_xyz.isEnabled()&& pintar2D_dinamic.mouse){
            pintar2D_dinamic.lupa2D();
            pintar2D_dinamic.opt.ajustarMaximos=false;
            if(pintar2D_dinamic.opt.isVisible()) pintar2D_dinamic.opt.ini();
            dinamic dinamic=new dinamic();
            dinamic.start();
            pintar2D_dinamic.mouse=false;
        }
    }//GEN-LAST:event_screen_xyzMouseReleased
    
    private void screen_xyzMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_xyzMousePressed
        if(evt.getButton()==evt.BUTTON1 && screen_xyz.isEnabled())   pintar2D_dinamic.mouseIni(evt.getX(),evt.getY(),true);
        if(evt.getButton()==evt.BUTTON3) jPopupMenuDinamic.show( evt.getComponent(), evt.getX(), evt.getY() ) ;
    }//GEN-LAST:event_screen_xyzMousePressed
    
    private void dos_help1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dos_help1MousePressed
        new help(homexeo+"help/utilities/dinamic.html").setVisible(true);
    }//GEN-LAST:event_dos_help1MousePressed
    
    private void jMenuIshowPictureMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuIshowPictureMousePressed
        if(!TreeB.isSelectionEmpty())
            if(TreeB.getSelectionPath().getPathCount() > 1 )
                new show_picture(homexeo,pintarMol.babel.path+SEP+""+TreeB.getSelectionPath().getPathComponent(1)).plotJPG(pintarMol.babel.path+SEP+""+TreeB.getSelectionPath().getPathComponent(1));
    }//GEN-LAST:event_jMenuIshowPictureMousePressed
    
    private void jMenuIPlotXNYMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuIPlotXNYMousePressed
        if(!TreeB.isSelectionEmpty())
            if(TreeB.getSelectionPath().getPathCount() > 1 )
                new pintar2D().plotXNY(new File(pintarMol.babel.path.toString()+SEP+TreeB.getSelectionPath().getPathComponent(1).toString()),homexeo);
    }//GEN-LAST:event_jMenuIPlotXNYMousePressed
    
    private void TreeBMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TreeBMousePressed
        if(evt.getButton()==evt.BUTTON3)
            if(modeTreeB)menuB.show( evt.getComponent(), evt.getX(), evt.getY() ) ;
            else menuProject.show( evt.getComponent(), evt.getX(), evt.getY() ) ;
        if(modeTreeB){
            if((evt.getButton()==evt.BUTTON2||evt.getClickCount()==2)&&!TreeB.isSelectionEmpty()){
                String file_name=TreeB.getSelectionPath().getPathComponent(1).toString();
                if(file_name.substring(file_name.length()-3,file_name.length()).equals("xyz")){
                    newFile=new File(pintarMol.babel.path+SEP+file_name);
                    pintarMol.babel.sort=1;
                    obtainGif.setText("convert -delay 100  "+newFile.getParent()+SEP+"frames/*.jpg "+newFile.getParent()+SEP+"out.gif");
                    open_xyz open_xyz=new open_xyz();
                    open_xyz.fileXYZ=newFile;
                    //--------- cargamos el primer paso -----
                    pintarMol.babel.firstStepXYZ(newFile);
                    xyz_load_step.setEnabled(true);
                    xyz_jSlider.setEnabled(true);
                    pintarMol.firstTime=true;
                    ver3D_MOL();
                    //---------------------------------------
                    open_xyz.reload();
                    open_xyz.start();
                }else{
                    if(file_name.substring(file_name.length()-3,file_name.length()).equals("jpg"))
                        new show_picture(homexeo,pintarMol.babel.path+SEP+file_name).plotJPG(pintarMol.babel.path+SEP+file_name);
                    else new editor(homexeo,pintarMol.babel.path+SEP+file_name).openFile(new File(pintarMol.babel.path+SEP+file_name));
                }
            }
        }
    }//GEN-LAST:event_TreeBMousePressed
    
    private void edit_entry1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_edit_entry1MousePressed
        if(!TreeB.isSelectionEmpty())
            if(TreeB.getSelectionPath().getPathCount() > 1 )
                new editor(homexeo,pintarMol.babel.path+SEP+TreeB.getSelectionPath().getPathComponent(1).toString()).openFile(new File(pintarMol.babel.path+SEP+TreeB.getSelectionPath().getPathComponent(1).toString()));
    }//GEN-LAST:event_edit_entry1MousePressed
    
    private void jMenuPlotNYMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuPlotNYMousePressed
        TreePath[] selections = TreeB.getSelectionPaths();
        File [] auxfile = new File[TreeB.getSelectionPaths().length] ;
        for(int T=0;T<TreeB.getSelectionPaths().length;T++)
            auxfile[T]= new File(pintarMol.babel.path.toString()+SEP+selections[T].getPathComponent(1).toString());
        if(!TreeB.isSelectionEmpty())
            if(TreeB.getSelectionPath().getPathCount() > 1 )
                new pintar2D().plotNY(auxfile,homexeo);
    }//GEN-LAST:event_jMenuPlotNYMousePressed
    
    private void screen_outMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_outMouseReleased
        if(evt.getButton()==evt.BUTTON1 && screen_out.isEnabled()&&pintar2D_out.mouse){
            pintar2D_out.lupa2D();
            if(pintar2D_out.opt.isVisible()) pintar2D_out.opt.ini();
            runProcess(8,false);
            pintar2D_out.mouse=false;
        }
    }//GEN-LAST:event_screen_outMouseReleased
    
    private void screen_outMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_outMouseDragged
        if(screen_out.isEnabled()&&pintar2D_out.mouse) {
            pintar2D_out.mouseFin(evt.getX(),evt.getY(),true);
            screen_out.setIcon(new ImageIcon(pintar2D_out.Selec()));
        }
    }//GEN-LAST:event_screen_outMouseDragged
    
    private void screen_outMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_outMousePressed
        if(evt.getButton()==evt.BUTTON1 && screen_out.isEnabled()) pintar2D_out.mouseIni(evt.getX(),evt.getY(),true);
        if(evt.getButton()==evt.BUTTON3) jPopupMenuScript.show( evt.getComponent(), evt.getX(), evt.getY() ) ;
    }//GEN-LAST:event_screen_outMousePressed
    
    private void jButton17MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(7).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(7).toString()));
    }//GEN-LAST:event_jButton17MousePressed
    
    private void jButton16MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton16MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(6).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(6).toString()));
    }//GEN-LAST:event_jButton16MousePressed
    
    private void jButton15MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(5).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(5).toString()));
    }//GEN-LAST:event_jButton15MousePressed
    
    private void jButton14MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(4).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(4).toString()));
    }//GEN-LAST:event_jButton14MousePressed
    
    private void jButton13MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton13MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(3).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(3).toString()));
    }//GEN-LAST:event_jButton13MousePressed
    
    private void jButton12MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(2).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(2).toString()));
    }//GEN-LAST:event_jButton12MousePressed
    
    private void jButton11MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(1).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(1).toString()));
    }//GEN-LAST:event_jButton11MousePressed
    
    private void jButton3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MousePressed
        if(jButton3.isEnabled())   runProcess(2,true);
    }//GEN-LAST:event_jButton3MousePressed
    
    private void jButton10MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MousePressed
        new editor(homexeo,HOME+".xeo/script/"+botones.elementAt(0).toString()).openFile(new File(HOME+".xeo/script/"+botones.elementAt(0).toString()));
    }//GEN-LAST:event_jButton10MousePressed
    
    private void jButton8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MousePressed
        if(jButton8.isEnabled())  runProcess(7,true);
    }//GEN-LAST:event_jButton8MousePressed
    
    private void jButton7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MousePressed
        if(jButton7.isEnabled())  runProcess(6,true);
    }//GEN-LAST:event_jButton7MousePressed
    
    private void jButton6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MousePressed
        if(jButton6.isEnabled())   runProcess(5,true);
    }//GEN-LAST:event_jButton6MousePressed
    
    private void jButton5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MousePressed
        if(jButton5.isEnabled())   runProcess(4,true);
    }//GEN-LAST:event_jButton5MousePressed
    
    private void jButton4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MousePressed
        if(jButton2.isEnabled())  runProcess(3,true);
    }//GEN-LAST:event_jButton4MousePressed
    
    private void jButton2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MousePressed
        if(jButton2.isEnabled())   runProcess(1,true);
    }//GEN-LAST:event_jButton2MousePressed
    
    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MousePressed
        if(jButton1.isEnabled())  runProcess(0,true);
    }//GEN-LAST:event_jButton1MousePressed
    
    private void delete_entryMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_delete_entryMousePressed
        if(!TreeA.isSelectionEmpty()) TreeA_delete();
    }//GEN-LAST:event_delete_entryMousePressed
    
    private void TreeAMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TreeAMousePressed
        Limpiar_Inspector();
        if(evt.getButton()==evt.BUTTON2) loadMOL();
        if(evt.getButton()==evt.BUTTON3) menuA.show( evt.getComponent(), evt.getX(), evt.getY() ) ;
        if(evt.getButton()==evt.BUTTON1) selectProject();
        if(ProjectTree.isVisible()) {
            path_project.setText(new File(pintarMol.babel.path).getParent());
            projectOpen();
        }
        if(JDRename.isVisible())  renameOpen();
        
        allow();
    }//GEN-LAST:event_TreeAMousePressed
    
    
    // Declaración de variables - no modificar//GEN-BEGIN:variables
    private javax.swing.JButton Btn_cell;
    private javax.swing.JButton Btn_vasp;
    private javax.swing.JMenuItem Calc;
    private javax.swing.JTextField CalcX;
    private javax.swing.JTextField CalcY;
    private javax.swing.JTextField CalcZ;
    private javax.swing.JCheckBox CenterXYZ;
    private javax.swing.JCheckBox CheckFragments;
    private javax.swing.JLabel Clabel;
    private javax.swing.JMenuItem Down;
    private javax.swing.JMenuItem Down1;
    private javax.swing.JFrame Frame_Bulk;
    private javax.swing.JFrame Frame_FIREBALL;
    private javax.swing.JTextField Giro_X;
    private javax.swing.JTextField Giro_Z;
    private javax.swing.JTextField Giro_centro;
    private javax.swing.ButtonGroup GroupExchange;
    private javax.swing.ButtonGroup GroupExcited;
    private javax.swing.JMenuItem InspAdd;
    private javax.swing.JMenuItem InspAdd1;
    private javax.swing.JMenuItem InspDelete;
    private javax.swing.JMenuItem InspDelete1;
    private javax.swing.JLabel InspLabel;
    private javax.swing.JDialog JDRename;
    private javax.swing.JFrame JFrame_dinamic;
    private javax.swing.JMenuItem Menu_open;
    private javax.swing.JMenu Menu_project;
    private javax.swing.JLabel MiniEjes;
    private javax.swing.JButton OpenProject;
    private javax.swing.JButton OpenProject2;
    private javax.swing.JButton OpenProject3;
    private javax.swing.JCheckBox OptBulk;
    private javax.swing.JButton OptionDinamic;
    private javax.swing.JDialog Options;
    private javax.swing.JSlider PERS;
    private javax.swing.JTree ProjectTree;
    private javax.swing.JSlider Sinter1;
    private javax.swing.JSlider Sinter2;
    private javax.swing.JPanel TABXEO;
    private javax.swing.JPanel TAB_dinamic;
    private javax.swing.JPanel TAB_out;
    private javax.swing.JSlider TOL;
    private javax.swing.JTextField Tdespl;
    private javax.swing.JTree TreeA;
    private javax.swing.JTree TreeB;
    private javax.swing.JMenuItem Up;
    private javax.swing.JMenuItem Up1;
    private javax.swing.JTextField Z_all;
    private javax.swing.JTextField angle;
    private javax.swing.JTextField antialias;
    private javax.swing.JTextField atomo_1;
    private javax.swing.JTextField atomo_2;
    private javax.swing.JTextField atomo_3;
    private javax.swing.JRadioButton axis_1;
    private javax.swing.JRadioButton axis_2;
    private javax.swing.JRadioButton axis_3;
    private javax.swing.JRadioButton axis_4;
    private javax.swing.JRadioButton bcc;
    private javax.swing.JTextField bonds;
    private javax.swing.ButtonGroup bulkRadiobutton;
    private javax.swing.JTextArea codeText;
    private javax.swing.JPanel colorArrows;
    private javax.swing.JPanel colorEjes;
    private javax.swing.JPanel colorFondo;
    private javax.swing.JButton color_fin;
    private javax.swing.JButton color_ini;
    private javax.swing.JButton color_inter_1;
    private javax.swing.JButton color_inter_2;
    private javax.swing.JButton copy;
    private javax.swing.JMenuItem delete_entry;
    private javax.swing.JCheckBox diffRadio;
    private javax.swing.JButton dos_help1;
    private javax.swing.JButton dos_help2;
    private javax.swing.JTextArea edit_Bulk;
    private javax.swing.JMenuItem edit_entry1;
    private javax.swing.JRadioButton fcc;
    private javax.swing.JRadioButton fileBulk;
    private javax.swing.JButton fileDinamic;
    private javax.swing.JTextField file_Bulk;
    private javax.swing.JTextField file_Bulk_lvs;
    private javax.swing.JTextField grosor;
    private javax.swing.JMenuItem helpTypes;
    private javax.swing.JMenuItem hideJtree;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton62;
    private javax.swing.JButton jButton67;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButtonPovray;
    private javax.swing.JButton jButtonPovray1;
    private javax.swing.JColorChooser jColorChooser1;
    private javax.swing.JDialog jDCalc;
    private javax.swing.JFrame jFrame_POVRAY;
    private javax.swing.JFrame jFrame_VASP;
    private javax.swing.JFrame jFrame_castep;
    private javax.swing.JMenuItem jInspector;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuItem jMedelete;
    private javax.swing.JMenuItem jMenSee;
    private javax.swing.JMenuItem jMenSee1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenuCastep;
    private javax.swing.JMenuItem jMenuDinamic;
    private javax.swing.JMenuItem jMenuFile;
    private javax.swing.JMenu jMenuFireball;
    private javax.swing.JMenuItem jMenuHelp;
    private javax.swing.JMenuItem jMenuHelp1;
    private javax.swing.JMenuItem jMenuIPlotXNY;
    private javax.swing.JMenuItem jMenuIPovray;
    private javax.swing.JMenuItem jMenuIadd;
    private javax.swing.JMenuItem jMenuIhopping;
    private javax.swing.JMenuItem jMenuIshowPicture;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JMenuItem jMenuItemBulk;
    private javax.swing.JMenuItem jMenuItem_export;
    private javax.swing.JMenuItem jMenuOption;
    private javax.swing.JMenuItem jMenuOption1;
    private javax.swing.JMenu jMenuOptions;
    private javax.swing.JMenuItem jMenuPlotNY;
    private javax.swing.JMenuItem jMenuReload;
    private javax.swing.JMenuItem jMenuReload1;
    private javax.swing.JMenuItem jMenuSave;
    private javax.swing.JMenuItem jMenuSave1;
    private javax.swing.JMenu jMenuVasp;
    private javax.swing.JMenu jMenu_Format;
    private javax.swing.JMenuItem jMenu_about;
    private javax.swing.JMenuItem jMenu_ayuda;
    private javax.swing.JMenuItem jMenu_begin;
    private javax.swing.JMenuItem jMenu_castep;
    private javax.swing.JMenuItem jMenu_out;
    private javax.swing.JMenuItem jMenu_stm;
    private javax.swing.JMenuItem jMenu_vasp;
    private javax.swing.JMenuItem jMenulOPEN;
    private javax.swing.JMenuItem jMenuopen;
    private javax.swing.JMenuItem jMenureloadAdjust;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPopupMenu jPopupMenuDinamic;
    private javax.swing.JPopupMenu jPopupMenuScript;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPaneTreeA;
    private javax.swing.JScrollPane jScrollPaneTreeB;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JSplitPane jSplitFix;
    private javax.swing.JSplitPane jSplitForm;
    private javax.swing.JSplitPane jSplitPane3;
    private javax.swing.JSplitPane jSplitPaneFix;
    private javax.swing.JTextField jT_cx;
    private javax.swing.JTextField jT_cy;
    private javax.swing.JTextField jT_cz;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JMenuItem jhelp;
    private javax.swing.JMenuItem jhelpFire;
    private javax.swing.JLabel labelPers;
    private javax.swing.JMenuItem load;
    private javax.swing.JButton loadBasLvs;
    private javax.swing.JButton loadRot;
    private javax.swing.JButton mas_mol;
    private javax.swing.JButton menos_mol;
    private javax.swing.JPopupMenu menuA;
    private javax.swing.JPopupMenu menuB;
    private javax.swing.JPopupMenu menuInspctor;
    private javax.swing.JMenuBar menuPpal;
    private javax.swing.JPopupMenu menuProject;
    private javax.swing.JTextField mol_Xfin;
    private javax.swing.JTextField mol_Xini;
    private javax.swing.JTextField mol_Yfin;
    private javax.swing.JTextField mol_Yini;
    private javax.swing.JTextField mol_Zfin;
    private javax.swing.JTextField mol_Zini;
    private javax.swing.JTextField mol_bas;
    private javax.swing.JTextField mol_lvs;
    private javax.swing.JTextField mol_lvs_1;
    private javax.swing.JTextField mol_lvs_2;
    private javax.swing.JTextField mol_lvs_3;
    private javax.swing.JCheckBox mol_seeIndex;
    private javax.swing.JCheckBox mol_seeVol;
    private javax.swing.ButtonGroup mv_axis;
    private javax.swing.JTextField newName;
    private javax.swing.JTextField note_text;
    private javax.swing.JTextField obtainGif;
    private javax.swing.JMenuItem open;
    private javax.swing.JButton open_dinamic;
    private javax.swing.JMenuItem open_mol;
    private javax.swing.JMenuItem open_mol1;
    private javax.swing.JMenuItem open_mol3;
    private javax.swing.JTextField outText;
    private javax.swing.JTextField parameters;
    private javax.swing.JButton paste;
    private javax.swing.JTextField path_project;
    private javax.swing.JTextField pixel;
    private javax.swing.JButton previewFix;
    private javax.swing.JButton previewPos;
    private javax.swing.JButton previewPos1;
    private javax.swing.JDialog projectChooser;
    private javax.swing.JTextField rad;
    private javax.swing.JTextField radio;
    private javax.swing.JButton reload_dinamic;
    private javax.swing.JButton reload_out;
    private javax.swing.JMenuItem rename;
    private javax.swing.JMenuItem rename1;
    private javax.swing.JTextField renameText;
    private javax.swing.JTextField resText;
    private javax.swing.JTextField rescalateArrow;
    private javax.swing.JButton rescalateCalc;
    private javax.swing.JTextField rescalateCastep;
    private javax.swing.JTextField rescalateFIREBALL;
    private javax.swing.JTextField rescalateVASP;
    private javax.swing.JTextField rotText;
    private javax.swing.JButton saveFix;
    private javax.swing.JButton savePos;
    private javax.swing.JButton savePos1;
    private javax.swing.JButton save_dinamic;
    private javax.swing.JMenuItem save_mol_gif;
    private javax.swing.JLabel screen5;
    private javax.swing.JLabel screen_out;
    private javax.swing.JLabel screen_xyz;
    private javax.swing.JFrame script;
    private javax.swing.JCheckBox seeArrows;
    private javax.swing.JCheckBox seeArrowsColor;
    private javax.swing.JCheckBox seeBond;
    private javax.swing.JCheckBox seeBordes;
    private javax.swing.JCheckBox seeCharges;
    private javax.swing.JCheckBox seePos;
    private javax.swing.JButton seePovray1;
    private javax.swing.JButton seePovray16;
    private javax.swing.JButton seePovray2;
    private javax.swing.JButton seePovray3;
    private javax.swing.JButton seePovray4;
    private javax.swing.JButton selectFixAtoms;
    private javax.swing.JTextField timeStep_Text;
    private javax.swing.JLabel tipo;
    private javax.swing.JCheckBox use_radio;
    private javax.swing.JMenu utilities;
    private javax.swing.JCheckBox verEjes;
    private javax.swing.JButton xy_mol;
    private javax.swing.JLabel xyz_end;
    private javax.swing.JSlider xyz_jSlider;
    private javax.swing.JButton xyz_load1;
    private javax.swing.JButton xyz_load2;
    private javax.swing.JButton xyz_load3;
    private javax.swing.JButton xyz_load_step;
    private javax.swing.JButton xyz_mas;
    private javax.swing.JButton xyz_menos;
    private javax.swing.JTextField xyz_step;
    private javax.swing.JCheckBox xyzt;
    private javax.swing.JTextField xyztFile;
    private javax.swing.JButton xz_mol;
    private javax.swing.JButton yx_mol;
    private javax.swing.JRadioButton zincblende;
    private javax.swing.JButton zy_mol;
    // Fin de declaración de variables//GEN-END:variables
    
    //----------------------------------------------------------------------
    //----------------------------------------------------------------------
    //----------------------------------------------------------------------
    //----------------------------------------------------------------------
    
    void Iniciar(){
        if((new File(homexeo+"iconos/open.gif")).exists()) {
            open_dinamic.setIcon(new ImageIcon(homexeo+"iconos/open.gif"));
        } else {
            open_dinamic.setText("open") ;
        }
        if((new File(homexeo+"iconos/save.gif")).exists())
            save_dinamic.setIcon(new ImageIcon(homexeo+"iconos/save.gif"));
        
        if((new File(homexeo+"iconos/reload.gif")).exists()){
            reload_dinamic.setIcon(new ImageIcon(homexeo+"iconos/reload.gif"));
            reload_out.setIcon(new ImageIcon(homexeo+"iconos/reload.gif"));
        } else {
            reload_dinamic.setText("reload") ;
            reload_out.setText("reload") ;
        }
        
        //------ MOL ---
        if((new File(homexeo+"iconos/menos.gif")).exists()) menos_mol.setIcon(new ImageIcon(homexeo+"iconos/menos.gif"));
        else {menos_mol.setText("-") ;}
        if((new File(homexeo+"iconos/mas.gif")).exists()) mas_mol.setIcon(new ImageIcon(homexeo+"iconos/mas.gif"));
        else {mas_mol.setText("+") ;}
        if((new File(homexeo+"iconos/xy.gif")).exists()) xy_mol.setIcon(new ImageIcon(homexeo+"iconos/xy.gif"));
        else {xy_mol.setText("xy") ;}
        if((new File(homexeo+"iconos/yx.gif")).exists()) yx_mol.setIcon(new ImageIcon(homexeo+"iconos/yx.gif"));
        else {yx_mol.setText("yx") ;}
        if((new File(homexeo+"iconos/xz.gif")).exists()) xz_mol.setIcon(new ImageIcon(homexeo+"iconos/xz.gif"));
        else {xz_mol.setText("xz") ;}
        if((new File(homexeo+"iconos/zy.gif")).exists()) zy_mol.setIcon(new ImageIcon(homexeo+"iconos/zy.gif"));
        else {zy_mol.setText("zy") ;}
        
        MiniEjes.setIcon(new ImageIcon(homexeo+"iconos/xeo.jpg"));
        
        if(new File(SEP+"etc").exists()){
            if(!(new File(HOME+".xeo/profile-xeo_"+nInsp).exists())){
                try{
                    Runtime run = Runtime.getRuntime();
                    Process proc = run.exec("cp -r "+homexeo+".xeo "+HOME);
                    System.out.println("creado: "+"cp -r "+homexeo+".xeo "+HOME);
                    proc.waitFor();
                } catch(Exception e){System.out.println("error al profile");}
            }
        }
        
        Limpiar_Inspector();
        
        //leemos las dos columnas del script/* para los botones
        if(new File(HOME+".xeo/script/Label.conf").exists()) botones = cadena.readFile( new File(HOME+".xeo/script/Label.conf"));
        else for(int i=0;i<8;i++)botones.add("error");
        jButton1.setText(botones.elementAt(0).toString());
        jButton2.setText(botones.elementAt(1).toString());
        jButton3.setText(botones.elementAt(2).toString());
        jButton4.setText(botones.elementAt(3).toString());
        jButton5.setText(botones.elementAt(4).toString());
        jButton6.setText(botones.elementAt(5).toString());
        jButton7.setText(botones.elementAt(6).toString());
        jButton8.setText(botones.elementAt(7).toString());
        
        Inspector();
    }
    
    
    File carpeta;
    int nCarpetas;
    void projectOpen(){
        carpeta = new File(path_project.getText());
        newFile=carpeta.getAbsoluteFile();
        if(newFile.exists())path_project.setText(newFile.toString());
        String[] subcarpeta = carpeta.list();
        root =  new DefaultMutableTreeNode(carpeta.getName());
        root.add(new DefaultMutableTreeNode(".."));
        nCarpetas=0;
        if (subcarpeta != null) {
            for (int i=0; i<subcarpeta.length; i++) {
                File file=new File(carpeta.getAbsolutePath()+SEP+subcarpeta[i]);
                if(file.isDirectory()&&!file.getName().substring(0,1).equals(".")){
                    DefaultMutableTreeNode rootd = new DefaultMutableTreeNode(subcarpeta[i]);
                    rootd.add(new DefaultMutableTreeNode( file.getName()));
                    root.add(rootd);
                    nCarpetas++;
                }
            }
            tipo.setText(pintarMol.babel.nameSort[pintarMol.babel.sort]);
        }
        ProjectTree.setModel(new DefaultTreeModel(root));
    }
    
    void Limpiar_Inspector(){
        Vector aux = new Vector();
        ins=cadena.readFile( new File(HOME+".xeo/inspector"));
        aux=cadena.readFile( new File(HOME+".xeo/profile-xeo_"+nInsp));
        InspLabel.setText( (nInsp+1)+SEP+ins.size());
        int g=0;
        dir.clear();
        for (int i = 0; i< aux.size(); i++){
            if(new File(aux.elementAt(i).toString()).exists() || cadena.readCol(1,aux.elementAt(i).toString()).equals("note")){
                dir.add(g,aux.elementAt(i).toString());
                g++;
            }
        }
        for(int i=TreeA.getRowCount()-1;i>0;i--)
            if(TreeA.isExpanded(i))
                TreeA.collapseRow(i);
    }
    
    void renameOpen(){
        selections=TreeA.getSelectionRows();
        JDRename.pack();
        JDRename.setVisible(true);
        JDRename.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
        if(selections[0]==0){
            renameText.setText("rename inspector");
            newName.setText(ins.get(nInsp).toString());
        } else{
            if(dir.get(selections[0]-1).toString().substring(0,5).equals("note "))newName.setText(dir.get(selections[0]-1).toString().substring(5,dir.get(selections[0]-1).toString().length()));
            else {
                renameText.setText(dir.get(selections[0]-1).toString());
                newName.setText(new File(dir.get(selections[0]-1).toString()).getName());
            }
        }
        newName.requestFocus();
    }
    
    void renameProject(){
        if(!TreeA.isSelectionEmpty()){
            selections = TreeA.getSelectionRows();
            if(selections[0]==0){
                ins.remove(nInsp);
                ins.add(nInsp,newName.getText());
                cadena.writer(ins,new File(HOME+".xeo/inspector"));
            }else{
                if(dir.get(selections[0]-1).toString().substring(0,5).equals("note ")) dir.add(selections[0]-1,"note "+newName.getText());
                else{
                    newFile=new File(new File(renameText.getText()).getParent()+SEP+newName.getText());
                    new File(dir.elementAt(selections[0]-1).toString()).renameTo(newFile);
                    if(newFile.exists()) dir.add(selections[0]-1,newFile.getAbsolutePath());
                    else dir.add(selections[0]-1,dir.elementAt(selections[0]-1).toString());
                }
                dir.remove(selections[0]);
            }
            Inspector();
            JDRename.setVisible(false);
            if(selections!=null)TreeA.setSelectionRows(selections);
        }
    }
    
    DefaultMutableTreeNode root,child;
    void Inspector(){
        //---------- TreeA -----------------------------------------------------
        root = new DefaultMutableTreeNode(ins.get(nInsp).toString());
        for (int i=0;i<dir.size();i++){
            if(!cadena.readCol(1,dir.elementAt(i).toString()).equals("note")){
                // pintarMol.babel.makeSort(dir.elementAt(i).toString());
                child=new DefaultMutableTreeNode((new File(dir.elementAt(i).toString())).getName());
                child.add(new DefaultMutableTreeNode(""));
                root.add(child);
            } else{
                if(cadena.nCol(dir.elementAt(i).toString())>1)root.add(new DefaultMutableTreeNode(dir.elementAt(i).toString().substring(5))); //quitamos note
                else root.add(new DefaultMutableTreeNode(" ... "));
            }
        }
        TreeA.setModel(new DefaultTreeModel(root));
        //-------------------- TreeB -------------------------------------------
        if(modeTreeB)TreeB.setModel(new DefaultTreeModel(new DefaultMutableTreeNode("folder")));
        else  loadTreeB();
        cadena.writer(dir,new File(HOME+".xeo/profile-xeo_"+nInsp));
        allow();
    }
    
    void allow(){
        if(new File(outText.getText()).exists()){
            jButton1.setEnabled(true);
            jButton2.setEnabled(true);
            jButton3.setEnabled(true);
            jButton4.setEnabled(true);
            jButton5.setEnabled(true);
            jButton6.setEnabled(true);
            jButton7.setEnabled(true);
            jButton8.setEnabled(true);
        }else{
            jButton1.setEnabled(false);
            jButton2.setEnabled(false);
            jButton3.setEnabled(false);
            jButton4.setEnabled(false);
            jButton5.setEnabled(false);
            jButton6.setEnabled(false);
            jButton7.setEnabled(false);
            jButton8.setEnabled(false);
        }
        if(new File(pintarMol.babel.path+SEP+"answer.xyz").exists()){
            jButton32.setEnabled(true);
            load.setEnabled(true);
        }else{
            jButton32.setEnabled(false);
            load.setEnabled(false);
        }
        if(new File(pintarMol.babel.path+SEP+"CHARGES").exists()) seeCharges.setEnabled(true);
        else {
            seeCharges.setEnabled(false);
            seeCharges.setSelected(false);
        }
        load.setEnabled(true);
    }
//----------------------------------------------------------------------
//----------------------------------------------------------------------
    
    String aux="";
    int[] selections;
    
    void TreeBup(){
        nInsp=TreeB.getMaxSelectionRow()-1;
        if(nInsp>0){
            aux=ins.get(nInsp-1).toString();
            ins.remove(nInsp-1);
            ins.add(nInsp,aux);
            cadena.writer(ins,new File(HOME+".xeo/inspector"));
            new File(HOME+".xeo/profile-xeo_"+(nInsp-1)).renameTo(new File(HOME+".xeo/profile-xeo_aux"));
            new File(HOME+".xeo/profile-xeo_"+(nInsp)).renameTo(new File(HOME+".xeo/profile-xeo_"+(nInsp-1)));
            new File(HOME+".xeo/profile-xeo_aux").renameTo(new File(HOME+".xeo/profile-xeo_"+nInsp));
            nInsp--;
        }
        Limpiar_Inspector();
        Inspector();
    }
    
    void TreeBdown(){
        nInsp=TreeB.getMaxSelectionRow()-1;
        if(nInsp<ins.size()-1){
            aux=ins.get(nInsp).toString();
            ins.remove(nInsp);
            ins.add(nInsp+1,aux);
            cadena.writer(ins,new File(HOME+".xeo/inspector"));
            new File(HOME+".xeo/profile-xeo_"+(nInsp+1)).renameTo(new File(HOME+".xeo/profile-xeo_aux"));
            new File(HOME+".xeo/profile-xeo_"+(nInsp)).renameTo(new File(HOME+".xeo/profile-xeo_"+(nInsp+1)));
            new File(HOME+".xeo/profile-xeo_aux").renameTo(new File(HOME+".xeo/profile-xeo_"+nInsp));
            nInsp++;
        }
        Limpiar_Inspector();
        Inspector();
    }
    
    void TreeA_down(){
        selections = TreeA.getSelectionRows();
        if(!TreeA.isSelectionEmpty())
            if(TreeA.getSelectionPath().getPathCount() > 0 ){
            for(int T=selections.length-1;T>=0;T--)
                if(selections[T]<dir.size()){
                aux=dir.elementAt(selections[T]-1).toString();
                dir.add(selections[T]-1+2,aux);
                dir.remove(selections[T]-1);
                }
            Inspector();
            for(int i=0;i<selections.length;i++) if(selections[i]<(TreeA.getRowCount()-1)) selections[i]++;
            TreeA.setSelectionRows(selections);
            }
    }
    
    void TreeA_up(){
        selections = TreeA.getSelectionRows();
        if(!TreeA.isSelectionEmpty())
            if(TreeA.getSelectionPath().getPathCount() > 1 ){
            for(int T=0 ; T<selections.length;T++)
                if(selections[T]>1){
                aux=dir.elementAt(selections[T]-1).toString();
                dir.remove(selections[T]-1);
                dir.add(selections[T]-2,aux);
                }
            Inspector();
            for(int i=0;i<selections.length;i++) if(selections[i]>1) selections[i]--;
            TreeA.setSelectionRows(selections);
            }
    }
    
    void TreeA_delete(){
        selections = TreeA.getSelectionRows();
        int N=TreeA.getSelectionPaths().length;
        if(!TreeA.isSelectionEmpty())
            if(TreeA.getSelectionPath().getPathCount() > 1 ){
            for(int T=0;T<N;T++){
                dir.remove(selections[T]-1);
                for(int j=T+1;j<TreeA.getSelectionPaths().length;j++ )
                    if(selections[T]<selections[j])selections[j]--;
            }
            Inspector();
            for(int i=0;i<N;i++)
                if(selections[i]<TreeA.getRowCount()&&selections[i]>0)
                    TreeA.setSelectionRow(selections[i]);
            }
    }
    
    void insertInTreeA(){
        TreePath [] select;
        int N,j;
        if(ProjectTree.getRowCount()<3) {
            ProjectTree.clearSelection();
            ProjectTree.setSelectionRow(1);
        }
        if(!ProjectTree.isSelectionEmpty()){
            select = ProjectTree.getSelectionPaths();
            N=ProjectTree.getSelectionPaths().length;
            for(int i=N-1;i>=0;i--)
                if(select[i].getPathCount()==2){
                if(ProjectTree.getRowCount()<3) pintarMol.babel.path=path_project.getText();
                else  pintarMol.babel.path=path_project.getText()+SEP+select[i].getPathComponent(1).toString();
                j=(TreeA.isSelectionEmpty())?0:TreeA.getMaxSelectionRow();
                dir.add(j,pintarMol.babel.path);
                Inspector();
                projectOpen();
                if(j>0)  TreeA.setSelectionRow(j+1);
                }
        }
    }
    
    
    void selectProject(){  //selecionar el projecto, hay que hacerlo antes de abrirlo
        if (TreeA.getSelectionPath() != null){
            //ajustamos, es decir quitmos lo que hay dentro de las carpetas
            if(TreeA.getSelectionPath().getPathCount() > 1 && !cadena.readCol(1,dir.elementAt(TreeA.getLeadSelectionRow()-1).toString()).equals("note") ){
                //--AQUI fijamos el directorio de trabajo y el outputFile-------- :)
                pintarMol.babel.path= dir.elementAt(TreeA.getLeadSelectionRow()-1).toString();
                pintarMol.babel.loadBabel();
                //-------- si esta encedido el ouput------------------------------
                if(Frame_FIREBALL.isVisible()){
                    outText.setText(pintarMol.babel.getOutput().getAbsolutePath());
                    loadMOL();
                }
                if(projectChooser.isVisible()) {
                    newFile=new File(pintarMol.babel.path); //dir.elementAt(i).toString());
                    if(newFile.exists())path_project.setText(newFile.toString());
                }
                //----------------------------------------------------------------
                loadTreeB();
            }
        }
    }
    
    void loadTreeB(){
        if(modeTreeB){
            root  = new DefaultMutableTreeNode("folder");
            root =  new DefaultMutableTreeNode(new File(pintarMol.babel.path).getName());
            File [] fileList = new File(pintarMol.babel.path).listFiles();
            for (int idx = 0; idx < fileList.length; idx++)
                root.add(new DefaultMutableTreeNode(fileList[idx].getName()));
            TreeB.setModel(new DefaultTreeModel(root));
        }else{
            root  = new DefaultMutableTreeNode("project");
            for (int idx = 0; idx < ins.size(); idx++)
                root.add(new DefaultMutableTreeNode(ins.elementAt(idx).toString()));
            TreeB.setModel(new DefaultTreeModel(root));
            TreeB.setSelectionRow(nInsp+1);
        }
    }
    
    void loadMOL() {   //abrimos el projecto seleccionado , si y solo si esta enable el Open project
        if(OpenProject.isEnabled()){
            if(load.isEnabled()){
                ini_mol();
                pintarMol.load();
                if(pintarMol.babel.read_fireball.basfile!=null) mol_bas.setText(pintarMol.babel.read_fireball.basfile.getAbsolutePath());
                if(pintarMol.babel.read_fireball.lvsfile!=null) mol_lvs.setText(pintarMol.babel.read_fireball.lvsfile.getAbsolutePath());
                mol_3d_enable(true);
                if(pintarMol.babel.Error){
                    pintarMol.showMesg=pintarMol.babel.Error;
                    pintarMol.mesg=pintarMol.babel.Error_out;
                }
                ver3D_MOL();
                pintarMol.showMesg=false;
            }
            if(script.isVisible()) outText.setText(pintarMol.babel.getOutput().getAbsolutePath());
            if(fireballOut.isVisible()) {
                fireballOut.path=pintarMol.babel.path;
                fireballOut.outFile=pintarMol.babel.getOutput();
                fireballOut.allow();
            }
            if(pintarMol.babel.nameSort[pintarMol.babel.sort].equals("xyz")){
                previewFix.setEnabled(false);
                saveFix.setEnabled(false);
                savePos.setEnabled(false);
                selectFixAtoms.setEnabled(false);
            }
        }
    }
    
    void load_file(){
        newFile =  new chooser().fileChoose("Open file *.xyz","open",pintarMol.babel.path) ;
        if(newFile!=null) {
            boolean open=false;
            if(newFile.getName().substring(newFile.getName().length()-4,newFile.getName().length()).equals(".xyz")){
                if(newFile!=null) {
                    pintarMol.babel.sort=1;
                    obtainGif.setText("convert -delay 100  "+newFile.getParent()+SEP+"frames/*.jpg "+newFile.getParent()+SEP+"out.gif");
                    open_xyz open_xyz=new open_xyz();
                    open_xyz.fileXYZ=newFile;
                    //--------- cargamos el primer paso -----
                    pintarMol.babel.firstStepXYZ(newFile);
                    xyz_load_step.setEnabled(true);
                    xyz_jSlider.setEnabled(true);
                    pintarMol.firstTime=true;
                    ver3D_MOL();
                    //---------------------------------------
                    open_xyz.reload();
                    open_xyz.start();
                    open=true;
                }
            }
            if(newFile.getName().substring(newFile.getName().length()-4,newFile.getName().length()).equals(".bas")){
                pintarMol.babel.path=newFile.getParent();
                pintarMol.babel.loadBabel();
                pintarMol.babel.load_Values();
                pintarMol.firstTime=true;
                //-- y lo interceptamos luego
                pintarMol.babel.read_fireball.basfile=newFile;
                pintarMol.babel.read_fireball.load_bas();
                //mol_3d_enable(true);
                if(seeBond.isSelected())pintarMol.babel.infBas.load_enlaces();
                ver3D_MOL();
                mol_bas.setText(newFile.getAbsolutePath());
                open=true;
            }
            if(!open){
                pintarMol.babel.path=newFile.getParent();
                pintarMol.babel.loadBabel();
                pintarMol.babel.load_Values();
                pintarMol.firstTime=true;
                ver3D_MOL();
                open=true;
            }
            if(open){
                ini_mol();
                mol_3d_enable(true);
            }
        }
    }
    
    void KEY_comun(java.awt.event.KeyEvent evt){
        if(evt.VK_F5== evt.getKeyCode()) loadMOL();
        if(evt.VK_F3== evt.getKeyCode()) load_file();
        if(evt.VK_F4== evt.getKeyCode()){
            projectChooser.pack();
            projectChooser.setVisible(true);
            projectChooser.setLocation((int) (jSplitForm.getLocationOnScreen().getX() + jSplitForm.getDividerLocation()+jSplitForm.getDividerSize()),(int) jSplitForm.getLocationOnScreen().getY());
            newFile=new File(pintarMol.babel.path).getParentFile();
            if(newFile.exists())path_project.setText(newFile.toString());
            projectOpen();
        }
    }
    
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
    
    void runProcess(int i,boolean ajustar_maximos){
        screen_out.setEnabled(true);
        if(pintar2D_out.firstTime){
            pintar2D_out.firstTime=false;
            pintar2D_out.opt.nfy=9;
        }
        if(pintar2D_out.opt.isVisible())
            if(!pintar2D_out.opt.ajustarMaximos)
                pintar2D_out.opt.load();
        File fileIN = new File(HOME+".xeo/temp/col.temp");
        if(new File(HOME+".xeo/script/"+botones.elementAt(i).toString()).exists()){
            //----clock---------
            long start = System.currentTimeMillis();// (milisegundos)
            long elapsed = System.currentTimeMillis() - start;
            if(ajustar_maximos && new File(SEP+"etc").exists()){
                fileIN.delete();
                try{
                    proc = run.exec("chmod a+x "+HOME+".xeo/script/"+botones.elementAt(i).toString());
                    proc.waitFor(); //esperar hasta empezar el siguiente
                } catch(Exception e){}
                try{
                    proc = run.exec(HOME+".xeo/script/"+botones.elementAt(i).toString()+" "+outText.getText()+" "+parameters.getText());
                    proc.waitFor();
                } catch(Exception e){}
                try{
                    proc = run.exec("mv col.temp "+fileIN.getAbsolutePath());
                    proc.waitFor();
                } catch(Exception e){}
                   /*
                    start = System.currentTimeMillis();// (milisegundos)
                    elapsed = System.currentTimeMillis() - start;
                    while(! fileIN.exists() && elapsed<Long.valueOf(Time.getText())*1000)elapsed = System.currentTimeMillis() - start;
                    */
            }  // ;)
            else{
                if (!(new File(SEP+"etc").exists())){
                    System.out.println("it's posible someone delete your /etc, it's also posible you are working with windows." +
                            "\n"+"the problem: you can't run script on your sistem, please do something like: mkdir /etc or ¿?");
                }
            }
            g2d.clear();
            int NCol=cadena.numeroCol(fileIN);
            pintar2D_out.inputfile2D=fileIN;
            g2d.add("protocolo");
            for(int k=1;k<=NCol;k++) g2d.add(k+" "+(k+1)+" "+botones.elementAt(i).toString());
            pintar2D_out.g2d=g2d;
            if(ajustar_maximos) pintar2D_out.Max_onefile_Y(1.0 /*step*/);
            pintar2D_out.imageBuffered = new BufferedImage(screen_out.getWidth()-dIc,screen_out.getHeight()-dIc, BufferedImage.TYPE_INT_RGB);
            pintar2D_out.show_onefile_Y(1.0);
            screen_out.setIcon(new ImageIcon(pintar2D_out.imageBuffered));
            if(pintar2D_out.opt.isVisible())
                if(pintar2D_out.opt.ajustarMaximos)
                    pintar2D_out.opt.ini();
        }
    }
    
    void setEnable_xyz(boolean ena){
        screen_xyz.setEnabled(ena);
        save_dinamic.setEnabled(ena);
        jButton33.setEnabled(ena);
        OptionDinamic.setEnabled(ena);
        reload_dinamic.setEnabled(ena);
        fileDinamic.setEnabled(ena);
        open_dinamic.setEnabled(ena);
    }
    
    class dinamic extends Thread {
        public void run() {
            if(pintar2D_dinamic.opt.isVisible())
                if(!pintar2D_dinamic.opt.ajustarMaximos)
                    pintar2D_dinamic.opt.load();
            File XYZFile=pintar2D_dinamic.inputfile2D;
            setEnable_xyz(false);
            newFile = new File(HOME+".xeo/temp/dinamic.temp");
            Calc_xyz xyz = new Calc_xyz();
            xyz.loadCodigo(codeText.getText());
            if(pintar2D_dinamic.opt.ajustarMaximos){
                xyz.xyzfile=XYZFile;
                xyz.outfile=newFile;
                xyz.timeStep=Double.valueOf(timeStep_Text.getText()).doubleValue();
                xyz.calculator_xyz();
            }
            g2d.clear();
            int  N=cadena.numeroCol(newFile);
            pintar2D_dinamic.inputfile2D=newFile;
            g2d.add("1 "+1+" "+"X"  );
            for(int i = 2; i<=N; i++)  g2d.add(i+" "+i+" "+xyz.codigo.elementAt(i-2).toString()  );
            pintar2D_dinamic.g2d=g2d;
            if(pintar2D_dinamic.opt.ajustarMaximos) pintar2D_dinamic.Max_onefile_XNY();
            pintar2D_dinamic.imageBuffered = new BufferedImage(screen_xyz.getWidth()-dIc,screen_xyz.getHeight()-dIc, BufferedImage.TYPE_INT_RGB);
            if(pintar2D_dinamic.firstTime) {
                pintar2D_dinamic.opt.indexRight=true;
                pintar2D_dinamic.firstTime=false;
                pintar2D_dinamic.opt.nfy=5;
            }
            pintar2D_dinamic.show_onefile_XNY();
            screen_xyz.setIcon(new ImageIcon(pintar2D_dinamic.imageBuffered));
            pintar2D_dinamic.inputfile2D=XYZFile;
            setEnable_xyz(true);
            if(pintar2D_dinamic.opt.isVisible())
                if(pintar2D_dinamic.opt.ajustarMaximos)
                    pintar2D_dinamic.opt.ini();
            
        }
    }
    
    void ini_mol(){
        //before load the bas file
        pintarMol.babel.infBas.seeCell_Vol=mol_seeVol.isSelected();
        pintarMol.babel.infBas.seeCell_ijk=mol_seeIndex.isSelected();
        pintarMol.babel.infBas.R_min[0]=Double.valueOf(mol_Xini.getText()).doubleValue();
        pintarMol.babel.infBas.R_min[1]=Double.valueOf(mol_Yini.getText()).doubleValue();
        pintarMol.babel.infBas.R_min[2]=Double.valueOf(mol_Zini.getText()).doubleValue();
        pintarMol.babel.infBas.R_max[0]=Double.valueOf(mol_Xfin.getText()).doubleValue();
        pintarMol.babel.infBas.R_max[1]=Double.valueOf(mol_Yfin.getText()).doubleValue();
        pintarMol.babel.infBas.R_max[2]=Double.valueOf(mol_Zfin.getText()).doubleValue();
        pintarMol.babel.infBas.lvs_1=(int) Double.valueOf(mol_lvs_1.getText()).doubleValue();
        pintarMol.babel.infBas.lvs_2=(int) Double.valueOf(mol_lvs_2.getText()).doubleValue();
        pintarMol.babel.infBas.lvs_3=(int) Double.valueOf(mol_lvs_3.getText()).doubleValue();
        //----
    }
    
    void mol_3d_enable(boolean ena ){
        copy.setEnabled(ena);
        paste.setEnabled(ena);
        previewPos.setEnabled(ena);
        previewPos1.setEnabled(ena);
        saveFix.setEnabled(ena);
        previewFix.setEnabled(ena);
        savePos.setEnabled(ena);
        savePos1.setEnabled(ena);
        Btn_cell.setEnabled(ena);
        Btn_vasp.setEnabled(ena);
        loadBasLvs.setEnabled(ena);
        pintarMol.MOL_enable=ena;
        labelPers.setEnabled(ena);
        diffRadio.setEnabled(ena);
        PERS.setEnabled(ena);
        save_mol_gif.setEnabled(ena);
        open_mol.setEnabled(ena);
        open_mol1.setEnabled(ena);
        loadRot.setEnabled(ena);
        seeBond.setEnabled(ena);
        TOL.setEnabled(ena);
        CheckFragments.setEnabled(ena);
        selectFixAtoms.setEnabled(ena);
        jButton43.setEnabled(ena);
        jButton50.setEnabled(ena);
        jButton44.setEnabled(ena);
        jButton31.setEnabled(ena);
        seePos.setEnabled(ena);
        mas_mol.setEnabled(ena);
        xy_mol.setEnabled(ena);
        zy_mol.setEnabled(ena);
        menos_mol.setEnabled(ena);
        yx_mol.setEnabled(ena);
        xz_mol.setEnabled(ena);
        jButton35.setEnabled(ena);
        jButton36.setEnabled(ena);
        jButton37.setEnabled(ena);
        jButton62.setEnabled(ena);
        jButton67.setEnabled(ena);
        jButton9.setEnabled(ena);
        jButton21.setEnabled(ena);
        jButtonPovray.setEnabled(ena);
        jButtonPovray1.setEnabled(ena);
        seePovray1.setEnabled(ena);
    }
    
    void ver3D_MOL(){
        pintarMol.verBordes=!seeBordes.isSelected();
        pintarMol.babel.infBas.seeCell_Vol=mol_seeVol.isSelected();
        pintarMol.babel.infBas.seeCell_ijk=mol_seeIndex.isSelected();
        pintarMol.xyztFile=new File(xyztFile.getText());
        pintarMol.xyzt=xyzt.isSelected();
        pintarMol.pixel=(int)Double.valueOf(pixel.getText()).doubleValue();
        pintarMol.rescalateArrow=Double.valueOf(rescalateArrow.getText()).doubleValue();
        pintarMol.seeArrows=seeArrows.isSelected();
        pintarMol.diffColorArrows=seeArrowsColor.isSelected();
        pintarMol.verRad=diffRadio.isSelected();
        pintarMol.C3D.perspectiva=(PERS.getValue()*1.0)/100;
        pintarMol.rad= Double.valueOf(rad.getText()).doubleValue();
        pintarMol.verPosiciones=seePos.isSelected();
        pintarMol.verCargas=seeCharges.isSelected();
        pintarMol.seeFrag=CheckFragments.isSelected();
        pintarMol.colorEjes=colorEjes.getBackground();
        pintarMol.colorArrows=colorArrows.getBackground();
        pintarMol.colorFondo=colorFondo.getBackground();
        pintarMol.verEjes=verEjes.isSelected();
        pintarMol.babel.infBas.seeBond=seeBond.isSelected();
        pintarMol.babel.infBas.tol=TOL.getValue();
        pintarMol.grosor=(int) Double.valueOf(grosor.getText()).doubleValue();
        pintarMol.c_out[0]=Double.valueOf(jT_cx.getText()).doubleValue();
        pintarMol.c_out[1]=Double.valueOf(jT_cy.getText()).doubleValue();
        pintarMol.c_out[2]=Double.valueOf(jT_cz.getText()).doubleValue();
        screen5Buffered = new BufferedImage(screen5.getWidth()-dIc,screen5.getHeight()-dIc, BufferedImage.TYPE_INT_RGB);
        screen5Buffered = pintarMol.pintar3D(screen5Buffered);
        screen5.setIcon(new ImageIcon(screen5Buffered));
        if(!mol_seeVol.isSelected()){
            mol_Xini.setText(cadena.pasarString(pintarMol.babel.infBas.r_min[0]-0.1));
            mol_Yini.setText(cadena.pasarString(pintarMol.babel.infBas.r_min[1]-0.1));
            mol_Zini.setText(cadena.pasarString(pintarMol.babel.infBas.r_min[2]-0.1));
            mol_Xfin.setText(cadena.pasarString(pintarMol.babel.infBas.r_max[0]+0.1));
            mol_Yfin.setText(cadena.pasarString(pintarMol.babel.infBas.r_max[1]+0.1));
            mol_Zfin.setText(cadena.pasarString(pintarMol.babel.infBas.r_max[2]+0.1));
        }
        MiniEjes();
    }
    void MiniEjes(){
        if(axis_1.isSelected()) pintarMol.nejes=1;
        if(axis_2.isSelected()) pintarMol.nejes=2;
        if(axis_3.isSelected()) pintarMol.nejes=3;
        if(axis_4.isSelected()) pintarMol.nejes=4;
        //---------- MiniEjes()
        screenMiniejes = new BufferedImage(MiniEjes.getWidth()-dIc,MiniEjes.getHeight()-dIc, BufferedImage.TYPE_INT_RGB);
        screenMiniejes = pintarMol.pintarMiniEjes(screenMiniejes);
        MiniEjes.setIcon(new ImageIcon(screenMiniejes));
        //--------------
    }
    
    class open_xyz extends Thread {
        File fileXYZ=null;
        public void run() {
            xyz_load_step.setEnabled(true);
            mol_3d_enable(true);
            previewFix.setEnabled(false);
            saveFix.setEnabled(false);
            savePos.setEnabled(false);
            selectFixAtoms.setEnabled(false);
            xyz_jSlider.setValue(0);
            xyz_step.setText("0");
            pintarMol.babel.infBas.load_xyz(fileXYZ);
            xyz_end.setText("of "+pintarMol.babel.infBas.xyz.size());
            ver3D_MOL_xyz();
        }
        void reload(){
            if(pintarMol.babel.infBas.LoadingXYZ){
                xyz_jSlider.setValue(0);
                xyz_step.setText("0");
                pintarMol.babel.infBas.stopLoadXYZ=true;
                while(pintarMol.babel.infBas.LoadingXYZ){}
                pintarMol.babel.infBas.xyz.clear();
            }
        }
    }
    
    int step;
    void ver3D_MOL_xyz(){
        loadBasLvs.setEnabled(true);
        xyz_jSlider.setEnabled(true);
        xyz_mas.setEnabled(true);
        xyz_menos.setEnabled(true);
        xyz_step.setEnabled(true);
        xyz_load_step.setEnabled(true);
        pintarMol.babel.infBas.tol=TOL.getValue();
        step=(int) Double.valueOf(xyz_step.getText()).doubleValue();
        pintarMol.babel.infBas.bas=(ArrayList)pintarMol.babel.infBas.xyz.get(step);
        if(!CenterXYZ.isSelected()) pintarMol.ajustar_centro();  //when load bas file
        xyz_jSlider.setValue(step);
        xyz_jSlider.setMaximum(pintarMol.babel.infBas.xyz.size()-1);
        pintarMol.mesg=cadena.readLine(step+1,pintarMol.babel.infBas.secondline_xyz);
        pintarMol.showMesg=true;
        //System.out.println(cadena.readLine(step+1,pintarMol.babel.infBas.secondline_xyz));
        ver3D_MOL();
        pintarMol.showMesg=false;
    }
    
    void run_povray(){
        for(int i=0;i<3;i++)
            for(int j=0;j<3;j++)
                pov.C3D.Rot[i][j]=pintarMol.C3D.Rot[i][j];
        pov.colorArrow=colorArrows.getBackground();
        pov.res=Double.valueOf(rescalateArrow.getText()).doubleValue();
        pov.ver_flecha=seeArrows.isSelected();
        pov.ver_flechaDiffColor=seeArrowsColor.isSelected();
        pov.homexeo=homexeo;
        pov.path=pintarMol.babel.path;
        pov.infBas=pintarMol.babel.infBas;
        pov.Height=pintarMol.C3D.oy;
        pov.Width=pintarMol.C3D.ox;
        pov.a=200/pintarMol.C3D.a;
        pov.angle=Double.valueOf(angle.getText()).doubleValue();
        pov.antialias=Double.valueOf(antialias.getText()).doubleValue();
        pov.use_radio=use_radio.isSelected();
        pov.rad=Double.valueOf(radio.getText()).doubleValue();
        pov.bonds=Double.valueOf(bonds.getText()).doubleValue();
        pov.ver_enlaces=seeBond.isSelected();
        pov.colorfondo=pintarMol.colorFondo;
        pov.write_files();
        pov.ejecutar_povray(true);
        if(pov.picture.exists()) screen5.setIcon(new ImageIcon(pov.picture.getAbsolutePath()));
        else System.out.println("Is povray install?, the out.jpg file don't exist but I don't know Why? ");
    }
    
    void verPovray_xyz(){
        pintarMol.babel.infBas.tol=TOL.getValue();
        new File(pintarMol.babel.path+SEP+"frames").mkdir();
        String cd = (pintarMol.babel.infBas.xyz.size()+"");
        for(step=1;step<pintarMol.babel.infBas.xyz.size();step++){
            pintarMol.babel.infBas.bas=(ArrayList)pintarMol.babel.infBas.xyz.get(step);
            run_povray();
            pov.delete_files();
            new File(pintarMol.babel.path+SEP+"out.jpg").
                    renameTo(new File(pintarMol.babel.path+SEP+"frames/out_"+cadena.ceros(cd.length(),step)+".jpg"));
            System.out.println(pintarMol.babel.path+SEP+"frames/out_"+cadena.ceros(cd.length(),step)+".jpg");
        }
    }
    
    void verFrames_xyz(){
        pintarMol.babel.infBas.tol=TOL.getValue();
        RenderedImage o;
        new File(pintarMol.babel.path+SEP+"frames").mkdir();
        String cd = (pintarMol.babel.infBas.xyz.size()+"");
        for(step=1;step<pintarMol.babel.infBas.xyz.size();step++){
            pintarMol.babel.infBas.bas=(ArrayList)pintarMol.babel.infBas.xyz.get(step);
            ver3D_MOL();
            try{
                o = pintarMol.imageBuffered;
                ImageIO.write(o,"jpg",new File(pintarMol.babel.path+SEP+"frames/out_"+cadena.ceros(cd.length(),step)+".jpg"));
            } catch (IOException e) { }
        }
    }
    
    void povray(boolean showfile){
        run_povray();
        if(showfile) pov.show_file();
        pov.delete_files();
    }
    
    BufferedImage color_buffer;
    Graphics color_graphics ;
    void dialogo_color(){
        color_buffer = new BufferedImage(Clabel.getWidth() ,Clabel.getHeight() , BufferedImage.TYPE_INT_RGB);
        color_graphics = color_buffer.createGraphics();
        pintarMol.colorIni=color_ini.getBackground();
        pintarMol.colorInter1=color_inter_1.getBackground();
        pintarMol.colorInter2=color_inter_2.getBackground();
        pintarMol.colorFin = color_fin.getBackground();
        pintarMol.posicion_1 = Sinter1.getValue(); //(Sinter1.getValue()*Clabel.getWidth())/Sinter1.getMaximum();
        pintarMol.posicion_2 = Sinter2.getValue(); //(Sinter2.getValue()*Clabel.getWidth())/Sinter2.getMaximum();
        if( pintarMol.posicion_1 >=  pintarMol.posicion_2){
            int auxpos= pintarMol.posicion_2;
            pintarMol.posicion_2= pintarMol.posicion_1;
            pintarMol.posicion_1=auxpos;
        }
        for(int C_aux=0;C_aux < Clabel.getWidth(); C_aux+=4){
            color_graphics.setColor(pintarMol.getColorPixel(C_aux*100/Clabel.getWidth()));
            color_graphics.fillRect(C_aux,0,4, Clabel.getHeight());
        }
        ImageIcon Cicon = new ImageIcon(color_buffer);
        Clabel.setIcon(Cicon);
    }
    
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    
}

