/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.ArrayList;
import java.util.Vector;

public class read_vasp {
    ArrayList<atom> bas;
    reader cadena = new reader();
    double [][] lvs = new double[3][3];
    double lvsRes;
    double res;
    periodicTable  periodicTable = new  periodicTable();
    int natoms;
    boolean Error;
    String Error_out;
    /** Creates a new instance of read_vasp */
    public read_vasp() {
        bas = new ArrayList();
        lvsRes=1;
    }
    //--read----
    void Load(File infile){
        if(infile.exists()){
            Vector aux=new Vector();
            try{
                int il=1;
                String str="";
                bas.clear();
                BufferedReader in = new BufferedReader(new FileReader(infile.getAbsolutePath()));
                aux.clear();
                str = in.readLine();
                str = in.readLine();
                try{lvsRes=Double.valueOf(cadena.readCol(1,str)).doubleValue();}catch(NumberFormatException ex){System.out.println("error read POSCAR lvsRes");}
                for(int i=0;i<3;i++){
                    str = in.readLine();
                    try{lvs[i][0] =lvsRes*Double.valueOf(cadena.readCol(1,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs X");}
                    try{lvs[i][1] =lvsRes*Double.valueOf(cadena.readCol(2,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Y");}
                    try{lvs[i][2] =lvsRes*Double.valueOf(cadena.readCol(3,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Z");}
                }
                while ((str = in.readLine()) != null){
                    if(cadena.readCol(1,str).trim().equals("Cartesian")){
                        str = in.readLine();
                        while (cadena.nCol(str)==6){
                            atom atom = new atom();
                            atom.posBas=il;
                            atom.posOut=il;
                            try{atom.R[0]=(Double.valueOf(cadena.readCol(1,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read x bas");}
                            try{atom.R[1]=(Double.valueOf(cadena.readCol(2,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read y bas");}
                            try{atom.R[2]=(Double.valueOf(cadena.readCol(3,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read z bas");}
                            if(cadena.readCol(4,str).equals("F")||cadena.readCol(5,str).equals("F")||cadena.readCol(6,str).equals("F"))
                                atom.fix=true;
                            bas.add(atom);
                            il++;
                            str = in.readLine();
                        }
                        natoms=bas.size();
                    }else aux.add(str);
                }
                in.close();
                Error=false;
                if(il==1) {
                    Error=true; //System.out.println("error read CASTEP ");
                    Error_out="we can't read this vasp file, we are working on";
                }
                if(!Error){
                    int natom=0;
                    int j=0;
                    while(natom<il-1){
                        for(int i=0;i<(int) Double.valueOf(cadena.readCol(1,aux.get(j).toString())).doubleValue();i++){
                            bas.get(natom).Z=(int) Double.valueOf(cadena.readCol(2,aux.get(j).toString())).doubleValue();
                            bas.get(natom).symbol=periodicTable.getSymbol(bas.get(natom).Z);
                            natom++;
                        }
                        j++;
                    }
                }
            }catch (IOException oe) {System.out.println("error read .cell");}
        }
    }
    
    //--write---
    Vector writeOut(){
        Vector auR = new Vector();
        String auxFrag="";
        auR.add("project:");
        auR.add("1.000");
        auR.add("    "+cadena.formatFortran(2,14,6,lvs[0][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[0][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[0][2]*res));
        auR.add("    "+cadena.formatFortran(2,14,6,lvs[1][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[1][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[1][2]*res));
        auR.add("    "+cadena.formatFortran(2,14,6,lvs[2][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[2][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[2][2]*res));
        int j=0,z_ant=0;
        for(int i=0;i<bas.size();i++){
            if(i==0){
                z_ant=bas.get(i).Z;
            }else
                if(bas.get(i).Z!=z_ant) {
                auR.add(j+" "+z_ant);
                z_ant=bas.get(i).Z;
                j=0;
                }
            j++;
        }
        auR.add(j+" "+z_ant);
        auR.add("Cartesian");
        for(int i=0;i<bas.size();i++){
            if(!bas.get(i).fix) auxFrag=" T T T";
            else auxFrag=" F F F";
            auR.add(
                    cadena.formatFortran(2,14,6,bas.get(i).R[0]*res)
                    +cadena.formatFortran(2,14,6,bas.get(i).R[1]*res)
                    +cadena.formatFortran(2,14,6,bas.get(i).R[2]*res)+auxFrag) ;
        }
        return auR;
    }
    
    
    Vector savePosFix(File infile,boolean fragments){
        Vector aux=new Vector();
        if(infile.exists()){
            try{
                int il=1;
                String str="";
                BufferedReader in = new BufferedReader(new FileReader(infile.getAbsolutePath()));
                aux.clear();
                str = in.readLine();
                aux.add(str);
                str = in.readLine();
                aux.add(str);
                for(int i=0;i<3;i++){
                    //lvs
                    str = in.readLine();
                    aux.add(str);
                }
                //despues de lvs ...
                int j=0,z_ant=0;
                for(int i=0;i<bas.size();i++){
                    if(i==0){
                        z_ant=bas.get(i).Z;
                    }else
                        if(bas.get(i).Z!=z_ant) {
                        aux.add(j+" "+z_ant);
                        z_ant=bas.get(i).Z;
                        j=0;
                        }
                    j++;
                }
                aux.add(j+" "+z_ant);
                int n=0;
                while (n<natoms){
                    str = in.readLine();
                    n+=(int) Double.valueOf(cadena.readCol(1,str)).doubleValue();
                }
                while ((str = in.readLine()) != null){
                    aux.add(str) ;
                    if(cadena.readCol(1,str).trim().equals("Cartesian")){
                        str = in.readLine();
                        while (cadena.nCol(str)==6){
                            str = in.readLine(); // pasamos las posiciones
                        }
                        String auxFrag="";
                        for(int i=0;i<bas.size();i++){
                            if(fragments){
                                if(!bas.get(i).fix) auxFrag=" T T T";
                                else auxFrag=" F F F";
                            } else{
                                if(!bas.get(i).selec) auxFrag=" T T T";
                                else auxFrag=" F F F";
                            }
                            aux.add(
                                    cadena.formatFortran(2,14,6,bas.get(i).R[0])
                                    +cadena.formatFortran(2,14,6,bas.get(i).R[1])
                                    +cadena.formatFortran(2,14,6,bas.get(i).R[2])+auxFrag) ;
                        }
                    }
                }
                in.close();
            }catch (IOException oe) {System.out.println("error read .cell");}
        }
        return aux;
    }
    
}
