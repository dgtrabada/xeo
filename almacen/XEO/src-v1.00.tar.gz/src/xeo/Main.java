/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;


import java.awt.image.RenderedImage;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class Main {
    
    public Main() {       
    }
    
    public static void main(String args[]) {
        boolean visible=true;
        String SEP = System.getProperty("file.separator");
        if(args.length>2){
            String expresion="0+";
            if(args[2].toString().equals("help")){
                System.out.println("xeo version");
                System.out.println("xeo Calc 4+8" );
                System.out.println("xeo xyz answer.xyz output.dat timeStep d[2][9]*2-1.8 N d[1][2] // use N to separe columns ") ;
                System.out.println("xeo Bulk function [ bcc fcc zincblende ]");
                System.out.println("xeo editor file");
                System.out.println("xeo plotNY  file1 file2 ...");
                System.out.println("xeo plotXNY [visible] file");
                System.out.println("xeo plotXNY-AjY [visible] Yini Yfin file");
                System.out.println("                [visible] = false, true");
                System.out.println("xeo Fireball Calc_bas x[1]*2 y[1]*2 z[1]*2 answer.bas");
                System.exit(0);
            }
            if(args[2].toString().equals("xyz")){
                Calc_xyz xyz = new Calc_xyz();
                xyz.xyzfile=new File(args[3].toString());
                xyz.outfile=new File(args[4].toString());
                xyz.timeStep=Double.valueOf(args[5].toString()).doubleValue();
                String exp="";
                for(int i=6;i<args.length;i++)
                    if(args[i].toString().equals("N")) exp+="\n";
                    else exp+=args[i];
                xyz.loadCodigo(exp);
                xyz.calculator_xyz();
                System.exit(0);
            }
            
            if(args[2].toString().equals("Calc")){
                for(int i=3;i<args.length;i++) expresion+=args[i];
                Calc cal=new Calc();
                System.out.println(cal.calcular(expresion));
                System.exit(0);
            }
            if(args[2].toString().equals("Fireball Calc_bas")){
                expresion="";
                for(int i=6;i<args.length;i++) expresion+=args[i]+"\n";
                Calc_bas cal = new Calc_bas();
                System.out.println(cal.calcular("0+"+args[3].toString(),"0+"+args[4].toString(),"0+"+args[5].toString(),expresion));
                System.exit(0);
            }
            if(args[2].toString().equals("Bulk")){
                bulk bulk = new bulk();
                bulk.nameFile=args[3].toString();
                if(args[4].toString().equals("bcc"))bulk.bcc=true;
                if(args[4].toString().equals("fcc"))bulk.fcc=true;
                if(args[4].toString().equals("zincblende"))bulk.fcc=true;
                bulk.makeBulk();
                System.out.println(bulk.out);
                System.exit(0);
            }
            if(args[2].toString().equals("editor")){
                if(args.length>3){
                    String file_name=args[3].toString();
                    if(new File(file_name).exists()){
                        if(file_name.substring(file_name.length()-3,file_name.length()).equals("jpg"))
                            new show_picture(SEP,file_name).plotJPG(file_name);
                        else new editor(SEP,file_name).openFile(new File(file_name));
                    }else new editor(SEP,SEP).setVisible(true);
                }else new editor(SEP,SEP).setVisible(true);
                visible=false;
            }
            if(args[2].toString().equals("plotNY")){
                File [] file_name=new File[args.length-3];
                for(int i=0;i<args.length-3;i++)
                    file_name[i]=new File(args[i+3].toString());
                new pintar2D().plotNY(file_name,SEP);
                visible=false;
            }
            
            if(args[2].toString().equals("plotXNY-AjY")){
                pintar2D pint =  new pintar2D();
                pint.inputfile2D=new File(args[6].toString());
                pint.g2d.clear();
                pint.imageBuffered = new BufferedImage(300,300, BufferedImage.TYPE_INT_RGB);
                int NCol=pint.cadena.numeroCol(pint.inputfile2D);
                for(int k=1;k<=NCol;k++) pint.g2d.add(k+" "+k+" "+"col.temp");
                // pint.opt.x_min=Double.valueOf(args[3].toString()).doubleValue();
                // pint.opt.x_max=Double.valueOf(args[4].toString()).doubleValue();
                pint.Max_onefile_XNY();
                pint.opt.y_min=Double.valueOf(args[4].toString()).doubleValue();
                pint.opt.y_max=Double.valueOf(args[5].toString()).doubleValue();
                pint.show_onefile_XNY();
                pint.VLine((pint.opt.y_min+pint.opt.y_max)/2);
                if(args[3].toString().equals("false")){
                    try{
                        RenderedImage o = pint.imageBuffered;
                        ImageIO.write(o,"jpg",new File("out.jpg"));
                        System.exit(0);
                    } catch (IOException e) { }
                }else{
                    System.out.println("press Ctrl + c to exit");
                    new show_picture(args[1].toString(),args[2].toString()).plotBuffered(pint.imageBuffered);
                    
                }
                visible=false;
            }
            
            if(args[2].toString().equals("plotXNY")){
                pintar2D pint =  new pintar2D();
                pint.inputfile2D=new File(args[4].toString());
                pint.g2d.clear();
                pint.imageBuffered = new BufferedImage(300,300, BufferedImage.TYPE_INT_RGB);
                int NCol=pint.cadena.numeroCol(pint.inputfile2D);
                for(int k=1;k<=NCol;k++) pint.g2d.add(k+" "+k+" "+"col.temp");
                pint.Max_onefile_XNY();
                pint.show_onefile_XNY();
                if(args[3].toString().equals("false")){
                    try{
                        RenderedImage o = pint.imageBuffered;
                        ImageIO.write(o,"jpg",new File("out.jpg"));
                        System.exit(0);
                    } catch (IOException e) { }
                }else{
                    System.out.println("press Ctrl + c to exit");
                    new show_picture(args[1].toString(),args[2].toString()).plotBuffered(pint.imageBuffered);
                }
                visible=false;
            }
            if(args[2].toString().equals("version")){
                System.out.println("xeo 1.00");
                visible=false;
            }
        }
        //case !exit
        if(visible){
            xeo xeo = new xeo();
            for(int i=0;i<args.length;i++){
                if(i==0) xeo.homexeo = args[i]+SEP;
                if(i==1) xeo.HOME = args[i]+SEP;
            }
            xeo.Iniciar(); //hacemos esto despues de tomar las variable homefireball y HOME
            xeo.setVisible(true);
        }
    }
    
}