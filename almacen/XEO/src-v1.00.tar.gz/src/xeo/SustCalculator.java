/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.util.Vector;

public class SustCalculator {
    reader cadena = new reader();
    Calc cal = new Calc();
    
    //----------- case of answer.xyz ---------------------------
    String compilar_xyz(Vector atoms, Vector codigo){
        String salida="";
        double D=0.0;
        for(int i=0;i<codigo.size();i++){ //numero de columnas
            salida+=numero(atoms,codigo.elementAt(i).toString())+" ";
        }
        return salida;
    }
    
    double numero(Vector atoms,String linea){
        String aux="";
        //primero pasamos todo a numeros  (z[1],z[2],x[1],y[1],d[1][2],d[1][3]........)
        for(int i=0;i<linea.length()-2;i++){
            if(     linea.substring(i,i+2).equals("x[")|
                    linea.substring(i,i+2).equals("y[")|
                    linea.substring(i,i+2).equals("z[")|
                    linea.substring(i,i+2).equals("d[")){
                if( linea.substring(i,i+2).equals("d[")){
                    int ini=-1,fin=-1;
                    for(int j=i;j<linea.length();j++){
                        if(linea.substring(j,j+1).equals("[")&&ini==-1&&fin==-1)ini=j;
                        if(linea.substring(j,j+1).equals("]")&&ini!=-1&&fin==-1)fin=j;
                    }
                    int at1 =(int) Double.valueOf(linea.substring(ini+1,fin)).doubleValue();
                    int j_ini=fin;
                    ini=fin=-1;
                    for(int j=j_ini;j<linea.length();j++){
                        if(linea.substring(j,j+1).equals("[")&&ini==-1&&fin==-1)ini=j;
                        if(linea.substring(j,j+1).equals("]")&&ini!=-1&&fin==-1)fin=j;
                    }
                    int at2 =(int) Double.valueOf(linea.substring(ini+1,fin)).doubleValue();
                    aux="";
                    aux=linea.substring(0,i)+distancia(atoms,at1,at2)+linea.substring(fin+1,linea.length());
                    linea=aux;
                    i=0;
                }else{
                    aux=linea.substring(0,i);
                    int ini=-1,fin=-1;
                    for(int j=i;j<linea.length();j++){
                        if(linea.substring(j,j+1).equals("[")&&ini==-1&&fin==-1)ini=j;
                        if(linea.substring(j,j+1).equals("]")&&ini!=-1&&fin==-1)fin=j;
                    }
                    int at1 =(int) Double.valueOf(linea.substring(ini+1,fin)).doubleValue();
                    if(linea.substring(i,i+1).equals("x")) aux+=cadena.readCol(2,atoms.elementAt((int) Double.valueOf(linea.substring(ini+1,fin)).doubleValue()).toString());
                    if(linea.substring(i,i+1).equals("y")) aux+=cadena.readCol(3,atoms.elementAt((int) Double.valueOf(linea.substring(ini+1,fin)).doubleValue()).toString());
                    if(linea.substring(i,i+1).equals("z")) aux+=cadena.readCol(4,atoms.elementAt((int) Double.valueOf(linea.substring(ini+1,fin)).doubleValue()).toString());
                    aux+=linea.substring(fin+1,linea.length());
                    linea=aux;
                    i=0;
                }
            }
        }
        return cal.calcular(linea);
    }
    
    
    double distancia(Vector atoms,int i,int j){
        return  Math.pow(
                Math.pow(Double.valueOf(cadena.readCol(2,atoms.elementAt(i).toString())).doubleValue()
                -Double.valueOf(cadena.readCol(2,atoms.elementAt(j).toString())).doubleValue(),2)+
                Math.pow(Double.valueOf(cadena.readCol(3,atoms.elementAt(i).toString())).doubleValue()
                -Double.valueOf(cadena.readCol(3,atoms.elementAt(j).toString())).doubleValue(),2)+
                Math.pow(Double.valueOf(cadena.readCol(4,atoms.elementAt(i).toString())).doubleValue()
                -Double.valueOf(cadena.readCol(4,atoms.elementAt(j).toString())).doubleValue(),2)
                ,0.5);
    }
    
}

