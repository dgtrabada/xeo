/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.ArrayList;
import java.util.Vector;

public class read_fireball {
    File basfile;
    ArrayList<atom> bas;
    File lvsfile;
    double [][] lvs = new double[3][3];
    File kptsfile;
    File xvfile;
    File xyzfile;
    String path;
    periodicTable  periodicTable = new  periodicTable();
    reader cadena = new reader();
    double res;
    boolean Error;
    String Error_out;
    /** Creates a new instance of script */
    public read_fireball() {
        bas = new ArrayList();
        path="./";
        basfile=null;
        lvsfile=null;
        kptsfile=null;
        xvfile=null;
        xyzfile=null;
        bas = new ArrayList();
        res=1;
    }
    String getpath(){ return path; }
    File getBAS(){ return basfile; }
    File getLVS(){ return lvsfile; }
    File getKPTS(){return kptsfile;}
    
    void loadScript(String aux){
        path=aux;
        File scriptFile=new File(path+"/script.input");
        if(scriptFile.exists()){
            try{
                BufferedReader inScript = new BufferedReader(new FileReader(scriptFile.getAbsolutePath()));
                basfile=new File(path+"/"+cadena.readCol(1,inScript.readLine()));
                lvsfile=new File(path+"/"+cadena.readCol(1,inScript.readLine()));
                kptsfile=new File(path+"/"+cadena.readCol(1,inScript.readLine()));
                inScript.readLine() ; //   1,100                                 initstep,finalstep
                inScript.readLine() ; //0.500                                  time step (fs)
                xvfile=new File(path+"/"+cadena.readCol(1,inScript.readLine()));
                xyzfile=new File(path+"/"+cadena.readCol(1,inScript.readLine()));
                ///0.0
                inScript.close();
            }catch (IOException oe) {System.out.println("error read basfile");}
        }
    }
    
    void load_bas(){
        int il=0;
        Error=false;
        if(basfile!=null)
            if(basfile.exists()){
            try{
                String str="";
                bas.clear();
                BufferedReader inbas = new BufferedReader(new FileReader(basfile.getAbsolutePath()));
                int natom=0;
                str = inbas.readLine();
                try{natom =(int) Double.valueOf(cadena.readCol(1,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read numero de atomos bas");}
                str = inbas.readLine();
                boolean formatBas=true;
                if(basfile.getName().substring(basfile.getName().length()-3,basfile.getName().length()).equals("xyz")){
                    formatBas=false;
                    str = inbas.readLine(); //leemos otra linea
                }
                for(int k=0;k<natom;k++){
                    // while ((str = inbas.readLine()) != null){
                    atom atom = new atom();
                    atom.posBas=il;
                    atom.posOut=il;
                    if(formatBas)try{atom.Z=((int) Double.valueOf(cadena.readCol(1,str)).doubleValue()); }catch(NumberFormatException ex){System.out.println("error read Z bas");} else{try{atom.Z=(periodicTable.getZ(cadena.readCol(1,str).trim())); }catch(NumberFormatException ex){System.out.println("error read Z bas");}}
                    for(int i=0;i<3;i++)
                        try{atom.R[i]=(Double.valueOf(cadena.readCol(i+2,str)).doubleValue()); }catch(NumberFormatException ex){System.out.println("error read "+i+" bas");}
                    atom.symbol=periodicTable.getSymbol(atom.Z);
                    bas.add(atom);
                    il++;
                    str = inbas.readLine();
                }
                inbas.close();
            }catch (IOException oe) {System.out.println("error read basfile");}
            }else {
            Error=true; //System.out.println("error read CASTEP ");
            Error_out="there are problems with "+basfile.getName();
            }
    }
    
    void load_frag(){
        File fragfile = new File(path+"/FRAGMENTS");
        if(fragfile.exists()){
            try{
                for(int i=0;i<bas.size();i++) bas.get(i).fix=false; //iniciamos
                String str;
                int ifrag=0;
                BufferedReader infrag = new BufferedReader(new FileReader(fragfile.getAbsolutePath()));
                str = infrag.readLine();  //we do nothing with the 2 firts lines of FRAGMENTS
                str = infrag.readLine();
                int NFr = (int) Double.valueOf(infrag.readLine()).doubleValue();
                for(int j=1;j<=NFr;j++){
                    str=infrag.readLine();
                    ifrag=(int) Double.valueOf(cadena.readCol(1,str)).doubleValue();
                    for(int i = 0; i<bas.size();i++){
                        if((bas.get(i).posOut+1)==ifrag) {  //ojo con el 1
                            bas.get(i).fix=true;
                        }
                    }
                }
                infrag.close();
            }catch (IOException oe) {System.out.println("error read FRAGMENTS");}
        }
    }
    
    void load_lvs(){
        if(lvsfile!=null)
            if(lvsfile.exists()){
            try{
                BufferedReader inlvs = new BufferedReader(new FileReader(lvsfile));
                String str="";
                for(int i=0;i<3;i++){
                    str = inlvs.readLine();
                    try{lvs[i][0] = Double.valueOf(cadena.readCol(1,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs X");}
                    try{lvs[i][1] = Double.valueOf(cadena.readCol(2,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Y");}
                    try{lvs[i][2] = Double.valueOf(cadena.readCol(3,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Z");}
                }
                inlvs.close();
            }catch (IOException oe) {System.out.println("error read lvs");}
            }
    }
    
    void load_charges(){
        File chargefile = new File(path+"/CHARGES");
        if(chargefile.exists()){
            try{
                String str;
                int ifrag=0;
                BufferedReader inchar = new BufferedReader(new FileReader(chargefile.getAbsolutePath()));
                int i =(int) Double.valueOf(cadena.readCol(1,inchar.readLine())).doubleValue();
                for(int j=0;j<i;j++){
                    str=inchar.readLine();
                    String charge_spd="";
                    double charge=0;
                    for(int k=1;k<=cadena.nCol(str);k++){
                        charge_spd+=cadena.formatFortran(2,2,2,Double.valueOf(cadena.readCol(k,str)).doubleValue())+" ";
                        charge+=Double.valueOf(cadena.readCol(k,str)).doubleValue();
                    }
                    if(j<bas.size()){
                        bas.get(j).Charge_spd=charge_spd;
                        bas.get(j).Charge=cadena.formatFortran(2,2,2,charge);
                    }
                    //si quitas atomos esto " if(j<bas.size())" hace que no se desborde pero las cargas estaran mal puestas
                }
                inchar.close();
                //si tenemos mas atomos que en CHARGES las ponemos a 0 para evitar los desbordamientos,
                // es el caso contrario a " if(j<bas.size())" y solo sucedera cuando editemos el archivo bas
                for(int j=i;j<bas.size();j++) bas.get(j).Charge="NAN";
            }catch (IOException oe) {System.out.println("error read CHARGES");}
        }
    }
    //--- Output ----
    Vector outbas(){
        Vector aux=new Vector(bas.size()+1);
        aux.add(bas.size());
        for(int i=0;i<bas.size();i++)
            aux.add(cadena.format(4,bas.get(i).Z )
            +cadena.formatFortran(2,14,6,bas.get(i).R[0]*res)
            +cadena.formatFortran(2,14,6,bas.get(i).R[1]*res)
            +cadena.formatFortran(2,14,6,bas.get(i).R[2]*res)) ;
        return aux;
    }
    
    Vector fix(boolean fragments){ //solo tiene sentido guardar cuando hemos cambiado algo
        Vector aux=new Vector(bas.size()+1);
        aux.add("0");
        aux.add("1");
        int nfrag=0;
        for(int i=0;i<bas.size();i++){
            if(fragments){
                if( bas.get(i).fix )
                    nfrag++;
            }else{
                if( bas.get(i).selec )
                    nfrag++;
            }
        }
        aux.add(nfrag);
        for(int i=0;i<bas.size();i++){
            if(fragments){
                if(  bas.get(i).fix )
                    aux.add((bas.get(i).posOut+1)+"  1 1 1");
            }else{
                if(  bas.get(i).selec )
                    aux.add((bas.get(i).posOut+1)+"  1 1 1");
            }
        }
        return aux;
    }
    
    Vector outlvs(){
        Vector aux=new Vector();
        for(int i=0;i<3;i++)
            aux.add(cadena.formatFortran(2,14,6,lvs[i][0]*res)
            +cadena.formatFortran(2,14,6,lvs[i][1]*res)
            +cadena.formatFortran(2,14,6,lvs[i][2]*res)) ;
        return aux;
    }
}

