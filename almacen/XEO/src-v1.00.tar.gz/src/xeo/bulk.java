/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;

public class bulk {
    double volumen;
    double [][] lvs = new double[4][4];
    String nameFile;
    String lvsFile;
    reader cadena = new reader();
    statistic  estadistica = new statistic();
    boolean fcc,bcc,usefile,Zincblende;
    String out;
    boolean opt;
    /** Creates a new instance of bulk */
    public bulk() {
        volumen=0;
        nameFile="/.";
        lvsFile="/.";
        for(int i=1;i<=3;i++)
            for(int j=1; j<=3;j++){
            lvs[i][j]=0;
            if(i==j)lvs[i][j]=1;
            }
        bcc=false;
        fcc=true;
        usefile=false;
        opt=true; //por defecto usamos el filtro
    }
    
    void makeBulk() {
        File inputFile=new File(nameFile);
        if(inputFile.exists()) {
            estadistica.Datos=cadena.readFile(inputFile);
            double P=100;
            if(opt){
                for(int i=0;i<8;i++){
                    estadistica.filtro(P);
                    estadistica.ParabolaMinimosCuadrados();
                    // System.out.println(estadistica.RMS+"  "+P);
                    if(estadistica.RMS > 0.01)   P-=100/(Math.pow(2,i+1));  //ojo aqui la tolerancia 0.01
                    else P+=100/(Math.pow(2,i+1));
                    if(P>100){P=100;i=8;}
                    if(P<0) P=0;
                }
            } else {
                estadistica.Load() ;
                estadistica.ParabolaMinimosCuadrados();
            }
            double r_min = -estadistica.b1/2/estadistica.b2;
            double e_min=estadistica.b0+estadistica.b1*r_min+estadistica.b2*r_min*r_min;
            Cristal(r_min);
            String salida=cadena.formatFortran(2,12,5,estadistica.b2)+"*x*x";
            if(estadistica.b1>0) salida+="+";
            salida+=cadena.formatFortran(2,12,5,estadistica.b1)+"*x";
            if(estadistica.b0>0) salida+="+";
            salida+=cadena.formatFortran(2,12,5,estadistica.b0);
            salida+="\n RMS = "+estadistica.RMS+"  TOL = "+(int) P+" % \n";
            salida+="E_min = "+cadena.formatFortran(2,12,5,e_min)+"    eV\n";
            salida+="a_min = "+cadena.formatFortran(2,12,5,r_min)+"    angs \n" ;
            salida+="Volumen = "+cadena.formatFortran(2,12,5,volumen)+" ang**3 \n";
            double beta=volumen/Math.pow(r_min,3);
            double B=(2/9/r_min/r_min/beta*(2*estadistica.b2*r_min+estadistica.b1)+2*estadistica.b2/9/r_min/beta)*160.2177;
            salida+="Bulk modulus = "+cadena.formatFortran(2,12,5,B)+"  GPa";
            out=salida;
        }
        
    }
    
    void Cristal(double a){
        if(fcc||Zincblende){
            // v1=lvs[1][...]=1,1,0
            lvs[1][1] = 1*a/2 ; lvs[1][2] = 1*a/2 ; lvs[1][3] = 0     ;
            lvs[2][1] = 1*a/2 ; lvs[2][2] = 0     ; lvs[2][3] = 1*a/2 ;
            lvs[3][1] = 0     ; lvs[3][2] = 1*a/2 ; lvs[3][3] = 1*a/2 ;
        }
        if(bcc){
            // v1=lvs[1][...]=1,1,0
            lvs[1][1] = -1*a/2 ; lvs[1][2] =  1*a/2 ; lvs[1][3] =  1*a/2 ;
            lvs[2][1] =  1*a/2 ; lvs[2][2] = -1*a/2 ; lvs[2][3] =  1*a/2 ;
            lvs[3][1] =  1*a/2 ; lvs[3][2] =  1*a/2 ; lvs[3][3] = -1*a/2 ;
        }
        if(usefile)
            if(new File(lvsFile).exists()){
            try{
                BufferedReader inlvs = new BufferedReader(new FileReader(new File(lvsFile)));
                String str="";
                for(int i=1;i<=3;i++){
                    str = inlvs.readLine();
                    try{lvs[i][1] = Double.valueOf(cadena.readCol(1,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs X");lvs[i][1]=i+1;}
                    try{lvs[i][2] = Double.valueOf(cadena.readCol(2,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Y");lvs[i][2]=i;}
                    try{lvs[i][3] = Double.valueOf(cadena.readCol(3,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Z");lvs[i][3]=i-1;}
                }
                inlvs.close();
            }catch (IOException oe) {System.out.println("error read lvs");}
            }
        volumen=0;
        volumen=Math.abs(lvs[1][1]*lvs[2][2]*lvs[3][3]+lvs[1][2]*lvs[2][3]*lvs[3][1]+lvs[2][1]*lvs[3][2]*lvs[1][3]
                -lvs[3][1]*lvs[2][2]*lvs[1][3]-lvs[3][2]*lvs[2][3]*lvs[1][1]-lvs[2][1]*lvs[1][2]*lvs[3][3]);
        if(Zincblende) volumen=volumen/2;
    }
    /*
     Esto funciona asi:
     V=a³*beta
     B0=-V*dP/dV = -a/3 * dP/da
     P=dE/dV=-dE/da*1/(3*a²beta)
     E=Aa²+Ba+C    <----------------------------------------------- *
     B0=2/(9a²beta)*(2Aa+B)+1/(9abeta)*2A
     B0=[ 2/(9a²beta)(2Aa+B)+2A/(9a*beta) ]*160.2177 GPa <--------- *
     */
}
