/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.ArrayList;

public class read_abinit {
    ArrayList<atom> bas;
    reader cadena = new reader();
    double [][] lvs = new double[3][3];
    double res;
    periodicTable  periodicTable = new  periodicTable();
    boolean Error;
    String Error_out;
    //---------------
    double acellx,acelly,acellz;
    int natoms;
    String typat,znucl;
    /** Creates a new instance of read_abinit */
    public read_abinit() {
        bas = new ArrayList();
    }
    //---read----
    void Load(File infile){
        if(infile.exists()){
            try{
                int ab=0;
                int il=1;
                String str="";
                bas.clear();
                BufferedReader in = new BufferedReader(new FileReader(infile.getAbsolutePath()));
                while ((str = in.readLine()) != null){
                    if(cadena.readCol(2,str).trim().equals("acell")){
                        try{acellx=(Double.valueOf(cadena.readCol(2,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read acell");}
                        try{acelly=(Double.valueOf(cadena.readCol(3,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read acell");}
                        try{acellz=(Double.valueOf(cadena.readCol(4,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read acell");}
                    }
                    if(cadena.readCol(1,str).trim().equals("typat")) typat=str;
                    if(cadena.readCol(1,str).trim().equals("znucl")) znucl=str;
                    if(cadena.readCol(1,str).trim().equals("natom"))
                        try{natoms=((int) Double.valueOf(cadena.readCol(2,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read acell");}
                    if(cadena.readCol(1,str).trim().equals("xcart")){
                        for(int i=1;i<=natoms;i++){
                            atom atom = new atom();
                            atom.posBas=i;
                            atom.posOut=i;
                            ab=(i==1)?1:0;
                            try{atom.R[0]=(Double.valueOf(cadena.readCol(1+ab,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read x bas");}
                            try{atom.R[1]=(Double.valueOf(cadena.readCol(2+ab,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read y bas");}
                            try{atom.R[2]=(Double.valueOf(cadena.readCol(3+ab,str)).doubleValue());}catch(NumberFormatException ex){System.out.println("error read z bas");}
                            bas.add(atom);
                            il++;
                            str = in.readLine();
                        }
                    }
                    if(cadena.readCol(1,str).equals("rprim")){
                        try{lvs[0][0] = Double.valueOf(cadena.readCol(2,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs X");}
                        try{lvs[1][0] = Double.valueOf(cadena.readCol(3,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Y");}
                        try{lvs[2][0] = Double.valueOf(cadena.readCol(4,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Z");}
                        try{lvs[0][1] = Double.valueOf(cadena.readCol(5,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs X");}
                        try{lvs[1][1] = Double.valueOf(cadena.readCol(6,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Y");}
                        try{lvs[2][1] = Double.valueOf(cadena.readCol(7,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Z");}
                        try{lvs[0][2] = Double.valueOf(cadena.readCol(8,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs X");}
                        try{lvs[1][2] = Double.valueOf(cadena.readCol(9,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Y");}
                        try{lvs[2][2] = Double.valueOf(cadena.readCol(10,str)).doubleValue(); }catch(NumberFormatException ex){System.out.println("error read lvs Z");}
                    }
                }
                in.close();
                Error=false;
                if(il==1) {
                    Error=true; //System.out.println("error read CASTEP ");
                    Error_out="we can't read abinit files, we are working on";
                }
                if(!Error){
                    for(int i=0;i<natoms;i++){
                        bas.get(i).Z=(int) Double.valueOf(cadena.readCol((int) Double.valueOf(cadena.readCol(i+2,typat)).doubleValue()+1,znucl)).doubleValue();
                        bas.get(i).symbol=periodicTable.getSymbol(bas.get(i).Z);
                    }
                }
            }catch (IOException oe) {System.out.println("error read .cell");}
        }
    }        
}
