/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.awt.*;
import javax.swing.JColorChooser;


public class Options2DPlot extends javax.swing.JFrame {
    reader cadena = new reader();
    double y_max,y_min;
    double x_max,x_min;
    
    //marco (40-10,20-10)
    int MxL,MxR;
    int MyU,MyD,L;
    
    boolean indexDown;
    boolean indexRight;
    boolean showTitle;
    String Title;
    //---ejes-----
    int Aox;
    int Aoy;
    int nfx;
    int nfy;
    double hx,hy;
    
    Font currentTitle, currentIndex,currentEjes;
    Color colorFondo, colorEjes, colorGrafico,colorTitulo;
    boolean ajustarMaximos;
    /** Creates new form Options2DPlot */
    public Options2DPlot() {
        initComponents();
        y_min=1;y_max=10;x_min=1;x_max=10;
        MxL=40;MxR=10;MyU=10;MyD=20;L=5;
        indexDown=false;
        indexRight=false;
        showTitle=false;
        Aoy=5;
        Aox=5;
        nfx=7;
        nfy=7;
        currentTitle = new Font("Dialog",Font.PLAIN,12);
        currentIndex = new Font("Monospaced",Font.PLAIN,12);
        currentEjes = new Font("Curier",Font.BOLD,9);
        colorFondo = Color.WHITE;
        colorEjes  = Color.GRAY;
        colorGrafico = Color.RED ;
        colorTitulo = Color.BLACK ;
        ajustarMaximos=true;
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Código Generado ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jColorChooser = new javax.swing.JColorChooser();
        Option2DMenu = new javax.swing.JPopupMenu();
        options = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jButton20 = new javax.swing.JButton();
        colorEjesLabel = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        fontEjes = new javax.swing.JTextField();
        fonTamEjes = new javax.swing.JSpinner();
        jPanel4 = new javax.swing.JPanel();
        labell = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        AxL = new javax.swing.JSpinner();
        AyL = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        nfxT = new javax.swing.JSpinner();
        nfyT = new javax.swing.JSpinner();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Xmax = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Ymax = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Xmin = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Ymin = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        fontTitlulo = new javax.swing.JTextField();
        seeTitle = new javax.swing.JCheckBox();
        Titulo = new javax.swing.JTextField();
        jButton22 = new javax.swing.JButton();
        colorTituloLabel = new javax.swing.JPanel();
        jButton18 = new javax.swing.JButton();
        colorFondoLabel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();
        colorGLabel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        fonTamTitulo = new javax.swing.JSpinner();
        jPanel3 = new javax.swing.JPanel();
        seeIndexRight = new javax.swing.JCheckBox();
        fontLeyenda = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        seeIndexDown = new javax.swing.JCheckBox();
        fonTamIndex = new javax.swing.JSpinner();

        options.setFont(new java.awt.Font("Dialog", 0, 12));
        options.setText("Options");
        Option2DMenu.add(options);

        setTitle("2D Options");
        setResizable(false);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton20.setText("...");
        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton20MousePressed(evt);
            }
        });

        colorEjesLabel.setBackground(java.awt.Color.gray);
        colorEjesLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorEjesLabelLayout = new org.jdesktop.layout.GroupLayout(colorEjesLabel);
        colorEjesLabel.setLayout(colorEjesLabelLayout);
        colorEjesLabelLayout.setHorizontalGroup(
            colorEjesLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorEjesLabelLayout.setVerticalGroup(
            colorEjesLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );

        jLabel9.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel9.setText("Axis");

        fontEjes.setText("tipo");

        fonTamEjes.setFont(new java.awt.Font("Dialog", 0, 12));

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        labell.setFont(new java.awt.Font("Dialog", 0, 12));
        labell.setText("n. divisions Y =");

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel5.setText("n. divisions X =");

        AxL.setFont(new java.awt.Font("Dialog", 0, 12));

        AyL.setFont(new java.awt.Font("Dialog", 0, 12));

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel6.setText("n. digits =");

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel7.setText("n. digits =");

        nfxT.setFont(new java.awt.Font("Dialog", 0, 12));

        nfyT.setFont(new java.awt.Font("Dialog", 0, 12));

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel5)
                    .add(labell))
                .add(4, 4, 4)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(AyL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel7)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(nfyT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(AxL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel6)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(nfxT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(AxL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel6)
                    .add(nfxT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(labell, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(AyL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel7)
                    .add(nfyT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel1.setText("Xmax =");

        Xmax.setText("0");

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel3.setText("Ymax =");

        Ymax.setText("0");

        jButton1.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton1.setText("...");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel2.setText("Xmin  =");

        Xmin.setText("0");

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel4.setText("Ymin  =");

        Ymin.setText("0");

        jButton2.setFont(new java.awt.Font("Dialog", 0, 12));
        jButton2.setText("...");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton2MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel5Layout.createSequentialGroup()
                        .add(jLabel2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Xmin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 61, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel5Layout.createSequentialGroup()
                        .add(jLabel3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Ymax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel1)
                    .add(jLabel4))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel5Layout.createSequentialGroup()
                        .add(Xmax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jButton2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel5Layout.createSequentialGroup()
                        .add(Ymin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(Xmin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1)
                    .add(Xmax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel3)
                    .add(jLabel4)
                    .add(Ymax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(Ymin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jButton20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(colorEjesLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(16, 16, 16)
                        .add(jLabel9)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fontEjes, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fonTamEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(colorEjesLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel9)
                        .add(fonTamEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(fontEjes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        fontTitlulo.setText("tipo");

        seeTitle.setFont(new java.awt.Font("Dialog", 0, 12));
        seeTitle.setText("Title");
        seeTitle.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeTitle.setMargin(new java.awt.Insets(0, 0, 0, 0));

        Titulo.setText("titlulo");

        jButton22.setText("...");
        jButton22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton22MousePressed(evt);
            }
        });

        colorTituloLabel.setBackground(new java.awt.Color(51, 51, 51));
        colorTituloLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorTituloLabelLayout = new org.jdesktop.layout.GroupLayout(colorTituloLabel);
        colorTituloLabel.setLayout(colorTituloLabelLayout);
        colorTituloLabelLayout.setHorizontalGroup(
            colorTituloLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorTituloLabelLayout.setVerticalGroup(
            colorTituloLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );

        jButton18.setText("...");
        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton18MousePressed(evt);
            }
        });

        colorFondoLabel.setBackground(new java.awt.Color(255, 255, 255));
        colorFondoLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorFondoLabelLayout = new org.jdesktop.layout.GroupLayout(colorFondoLabel);
        colorFondoLabel.setLayout(colorFondoLabelLayout);
        colorFondoLabelLayout.setHorizontalGroup(
            colorFondoLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorFondoLabelLayout.setVerticalGroup(
            colorFondoLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 17, Short.MAX_VALUE)
        );

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel8.setText("background");

        jButton21.setText("...");
        jButton21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton21MousePressed(evt);
            }
        });

        colorGLabel.setBackground(java.awt.Color.red);
        colorGLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        org.jdesktop.layout.GroupLayout colorGLabelLayout = new org.jdesktop.layout.GroupLayout(colorGLabel);
        colorGLabel.setLayout(colorGLabelLayout);
        colorGLabelLayout.setHorizontalGroup(
            colorGLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );
        colorGLabelLayout.setVerticalGroup(
            colorGLabelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 18, Short.MAX_VALUE)
        );

        jLabel10.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel10.setText("function");

        fonTamTitulo.setFont(new java.awt.Font("Dialog", 0, 12));

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jButton18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(colorFondoLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel8)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 84, Short.MAX_VALUE)
                        .add(jButton21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(colorGLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(2, 2, 2)
                        .add(jLabel10))
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(seeTitle)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(colorTituloLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fontTitlulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fonTamTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(Titulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, fonTamTitulo)
                    .add(seeTitle)
                    .add(jButton22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, colorTituloLabel, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(fontTitlulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Titulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel8)
                            .add(jButton21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(org.jdesktop.layout.GroupLayout.LEADING, colorGLabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel10))
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, colorFondoLabel, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jButton18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        seeIndexRight.setFont(new java.awt.Font("Dialog", 0, 12));
        seeIndexRight.setText("Index Right");
        seeIndexRight.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeIndexRight.setMargin(new java.awt.Insets(0, 0, 0, 0));

        fontLeyenda.setText("tipo");

        jLabel11.setFont(new java.awt.Font("Dialog", 0, 12));
        jLabel11.setText("INDEX Font");

        seeIndexDown.setFont(new java.awt.Font("Dialog", 0, 12));
        seeIndexDown.setText("Index Down");
        seeIndexDown.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeIndexDown.setMargin(new java.awt.Insets(0, 0, 0, 0));

        fonTamIndex.setFont(new java.awt.Font("Dialog", 0, 12));

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jLabel11)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fontLeyenda, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fonTamIndex, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(seeIndexRight)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(seeIndexDown)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(14, 14, 14)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel11)
                    .add(fonTamIndex, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(fontLeyenda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(seeIndexRight)
                    .add(seeIndexDown))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void jButton2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MousePressed
        hx=cadena.ultimos2Decimales((x_max-x_min)/Aox);
        x_min=cadena.ajustarDecimal(x_min,hx);
        auxMax=x_min;
        while(auxMax<x_max)auxMax+=hx;
        x_max=auxMax;
        Xmax.setText(x_max+"");
        Xmin.setText(x_min+"");
    }//GEN-LAST:event_jButton2MousePressed
    
    double auxMax;
    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MousePressed
        hy=cadena.ultimos2Decimales((y_max-y_min)/Aoy);
        y_min=cadena.ajustarDecimal(y_min,hy);
        auxMax=y_min;
        while(auxMax<y_max)auxMax+=hy;
        y_max=auxMax;
        Ymax.setText(y_max+"");
        Ymin.setText(y_min+"");
    }//GEN-LAST:event_jButton1MousePressed
    
    private void jButton22MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MousePressed
        colorTituloLabel.setBackground( JColorChooser.showDialog( this , "axis color", colorTituloLabel.getBackground()));
        colorTitulo=colorTituloLabel.getBackground();
    }//GEN-LAST:event_jButton22MousePressed
    
    private void jButton21MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MousePressed
        colorGLabel.setBackground( JColorChooser.showDialog( this , "axis color", colorGLabel.getBackground()));
        colorGrafico=colorGLabel.getBackground();
    }//GEN-LAST:event_jButton21MousePressed
    
    private void jButton20MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MousePressed
        colorEjesLabel.setBackground( JColorChooser.showDialog( this , "axis color", colorEjesLabel.getBackground()));
        colorEjes=colorEjesLabel.getBackground();
    }//GEN-LAST:event_jButton20MousePressed
    
    private void jButton18MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MousePressed
        colorFondoLabel.setBackground( JColorChooser.showDialog( this , "background color", colorFondoLabel.getBackground()));
        colorFondo=colorFondoLabel.getBackground();
    }//GEN-LAST:event_jButton18MousePressed
    
    
    
    // Declaración de variables - no modificar//GEN-BEGIN:variables
    private javax.swing.JSpinner AxL;
    private javax.swing.JSpinner AyL;
    private javax.swing.JPopupMenu Option2DMenu;
    private javax.swing.JTextField Titulo;
    private javax.swing.JTextField Xmax;
    private javax.swing.JTextField Xmin;
    private javax.swing.JTextField Ymax;
    private javax.swing.JTextField Ymin;
    private javax.swing.JPanel colorEjesLabel;
    private javax.swing.JPanel colorFondoLabel;
    private javax.swing.JPanel colorGLabel;
    private javax.swing.JPanel colorTituloLabel;
    private javax.swing.JSpinner fonTamEjes;
    private javax.swing.JSpinner fonTamIndex;
    private javax.swing.JSpinner fonTamTitulo;
    private javax.swing.JTextField fontEjes;
    private javax.swing.JTextField fontLeyenda;
    private javax.swing.JTextField fontTitlulo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JColorChooser jColorChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel labell;
    private javax.swing.JSpinner nfxT;
    private javax.swing.JSpinner nfyT;
    private javax.swing.JMenuItem options;
    private javax.swing.JCheckBox seeIndexDown;
    private javax.swing.JCheckBox seeIndexRight;
    private javax.swing.JCheckBox seeTitle;
    // Fin de declaración de variables//GEN-END:variables
    
    
    void ini(){
        colorGLabel.setBackground(colorGrafico);
        colorFondoLabel.setBackground(colorFondo);
        colorEjesLabel.setBackground(colorEjes);
        Xmax.setText(x_max+"");
        Xmin.setText(x_min+"");
        Ymax.setText(y_max+"");
        Ymin.setText(y_min+"");
        fontEjes.setText(currentEjes.getFontName());
        fonTamEjes.setValue(currentEjes.getSize());
        fontTitlulo.setText(currentTitle.getFontName());
        fonTamTitulo.setValue(currentTitle.getSize());
        fontLeyenda.setText(currentIndex.getFontName());
        fonTamIndex.setValue(currentIndex.getSize());
        seeIndexDown.setSelected(indexDown);
        seeIndexRight.setSelected(indexRight);
        seeTitle.setSelected(showTitle);
        Titulo.setText(Title);
        AxL.setValue(Aox);
        AyL.setValue(Aoy);
        nfxT.setValue(nfx);
        nfyT.setValue(nfy);
    }
    
    
    void load(){
        //el color no hace fasta
        x_max=Double.valueOf(Xmax.getText()).doubleValue();
        x_min=Double.valueOf(Xmin.getText()).doubleValue();
        y_max=Double.valueOf(Ymax.getText()).doubleValue();
        y_min=Double.valueOf(Ymin.getText()).doubleValue();
        currentEjes = new Font(fontEjes.getText(),Font.PLAIN,fonTamEjes.getValue().hashCode());
        currentTitle = new Font(fontTitlulo.getText(),Font.PLAIN,fonTamTitulo.getValue().hashCode());
        currentIndex = new Font(fontLeyenda.getText(),Font.PLAIN,fonTamIndex.getValue().hashCode());
        indexDown=seeIndexDown.isSelected();
        indexRight=seeIndexRight.isSelected();
        showTitle=seeTitle.isSelected();
        Aox=AxL.getValue().hashCode();
        Aoy=AyL.getValue().hashCode();
        nfx=nfxT.getValue().hashCode();
        nfy=nfyT.getValue().hashCode();
        if(Title!=null)Title=Titulo.getText();
        else {
            Title="Title";
            Titulo.setText(Title);
        }
    }
    
}
