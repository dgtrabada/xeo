/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.*;

public class javaSTM extends javax.swing.JFrame {
    String path;
    stm stm = new stm();
    hopping hopping = new hopping();
    suma suma = new suma();
    reader cadena = new reader();
    String SEP = System.getProperty("file.separator");
    /** Creates new form javaSTM */
    public javaSTM(String aux) {
        initComponents();
        path=aux;
    }
    
    void hopping(){
        jFrameHopping.pack();
        jFrameHopping.setVisible(true);
    }
    
    void Iniciar(String homefireball){
        stm.pathIcon=homefireball+SEP+"iconos";
        if((new File(homefireball+"iconos"+SEP+"open.gif")).exists()) {
            open_stm.setIcon(new ImageIcon(homefireball+"iconos"+SEP+"open.gif"));
            open_hopping.setIcon(new ImageIcon(homefireball+"iconos"+SEP+"open.gif"));
        }else{
            open_stm.setText("open");
            open_hopping.setText("open");
        }
        if((new File(homefireball+"iconos"+SEP+"save.gif")).exists())
            save_stm.setIcon(new ImageIcon(homefireball+"iconos"+SEP+"save.gif"));
        else
            save_stm.setText("save") ;
        if((new File(homefireball+"iconos"+SEP+"reload.gif")).exists())
            reload_stm.setIcon(new ImageIcon(homefireball+"iconos"+SEP+"reload.gif"));
        else
            reload_stm.setText("reload") ;
        if((new File(homefireball+"iconos"+SEP+"formula.gif")).exists())   formula.setIcon(new ImageIcon(homefireball+"iconos/formula.gif"));
        else {formula.setText("T=A/pow(T,alfa)*exp(-d*pow(2*phi))") ;}
        //----------Load STM----------:
        //stm.resolucion=re
        stm.resolucion=(int) Double.valueOf(resol_Y.getText()).doubleValue();
        Sinter1.setValue(stm.posicion_1);
        Sinter2.setValue(stm.posicion_2);
        color_Fondo.setBackground(stm.colorFondo);
        color_ini.setBackground(stm.colorIni);
        color_inter_1.setBackground(stm.colorInter1);
        color_inter_2.setBackground(stm.colorInter2);
        color_fin.setBackground(stm.colorFin);
        //--atoms---
        stm.alfa=D_alfa.getValue();
        stm.basfile=new File(D_bas.getText());
        stm.lvsfile=new File(D_lvs.getText());
        stm.verAtomos=D_verAtomos.isSelected();
        stm.radio = (int) (Double.valueOf(D_Ratom.getText()).doubleValue());
        stm.verIconosAtomos=verIconosAtomos.isSelected();
        Col1.setValue(1);
        Col2.setValue(2);
        Col3.setValue(3);
        dialogo_color();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Código Generado ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jFrameHopping = new javax.swing.JFrame();
        jPanel30 = new javax.swing.JPanel();
        open_hopping = new javax.swing.JButton();
        screen_hop = new javax.swing.JLabel();
        logScale = new javax.swing.JCheckBox();
        CheckFireball = new javax.swing.JCheckBox();
        CheckFormula = new javax.swing.JCheckBox();
        stm_save = new javax.swing.JButton();
        stm_load = new javax.swing.JButton();
        Checkmix = new javax.swing.JCheckBox();
        NTOT_Edit = new javax.swing.JSpinner();
        stm_all = new javax.swing.JCheckBox();
        jPanel31 = new javax.swing.JPanel();
        formula = new javax.swing.JLabel();
        Ahop = new javax.swing.JTextField();
        Whop = new javax.swing.JTextField();
        alfahop = new javax.swing.JTextField();
        cuthop = new javax.swing.JTextField();
        stm_change = new javax.swing.JButton();
        corte = new javax.swing.JSpinner();
        stm_run = new javax.swing.JButton();
        stm_paint = new javax.swing.JButton();
        TAB_STM = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        STextArea_stm = new javax.swing.JTextArea();
        jButton41 = new javax.swing.JButton();
        Sname_stm = new javax.swing.JTextField();
        jButton42 = new javax.swing.JButton();
        stm_help = new javax.swing.JButton();
        open_stm = new javax.swing.JButton();
        save_stm = new javax.swing.JButton();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        color_Fondo = new javax.swing.JButton();
        Sinter2 = new javax.swing.JSlider();
        Clabel = new javax.swing.JLabel();
        Sinter1 = new javax.swing.JSlider();
        color_inter_1 = new javax.swing.JButton();
        color_ini = new javax.swing.JButton();
        color_inter_2 = new javax.swing.JButton();
        color_fin = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton60 = new javax.swing.JButton();
        verEjesSTM = new javax.swing.JCheckBox();
        verBarra = new javax.swing.JCheckBox();
        verCamino = new javax.swing.JCheckBox();
        jPanel29 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        resol_X = new javax.swing.JTextField();
        resol_Y = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jButton48 = new javax.swing.JButton();
        jPanel34 = new javax.swing.JPanel();
        Col1 = new javax.swing.JSpinner();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Col2 = new javax.swing.JSpinner();
        Col3 = new javax.swing.JSpinner();
        Border = new javax.swing.JCheckBox();
        jButton34 = new javax.swing.JButton();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel35 = new javax.swing.JPanel();
        jButton46 = new javax.swing.JButton();
        D_lvs = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        D_bas = new javax.swing.JTextField();
        jButton45 = new javax.swing.JButton();
        jPanel37 = new javax.swing.JPanel();
        stmXini = new javax.swing.JTextField();
        stmXfin = new javax.swing.JTextField();
        stmYini = new javax.swing.JTextField();
        stmZini = new javax.swing.JTextField();
        stmYfin = new javax.swing.JTextField();
        stmZfin = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        stm_seeVol1 = new javax.swing.JCheckBox();
        jButton47 = new javax.swing.JButton();
        D_verAtomos = new javax.swing.JCheckBox();
        jPanel28 = new javax.swing.JPanel();
        seeBond1 = new javax.swing.JCheckBox();
        TOL1 = new javax.swing.JSlider();
        jLabel39 = new javax.swing.JLabel();
        D_alfa = new javax.swing.JSlider();
        jLabel40 = new javax.swing.JLabel();
        D_Ratom = new javax.swing.JTextField();
        stm_seeLabel = new javax.swing.JCheckBox();
        verIconosAtomos = new javax.swing.JCheckBox();
        jButton53 = new javax.swing.JButton();
        stm_grosor = new javax.swing.JTextField();
        jButton55 = new javax.swing.JButton();
        reload_stm = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        screen_stm = new javax.swing.JLabel();

        open_hopping.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/open.gif"));
        open_hopping.setAlignmentY(0.0F);
        open_hopping.setDisabledIcon(new javax.swing.ImageIcon(""));
        open_hopping.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                open_hoppingMousePressed(evt);
            }
        });

        screen_hop.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        screen_hop.setEnabled(false);
        screen_hop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                screen_hopMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                screen_hopMouseReleased(evt);
            }
        });
        screen_hop.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                screen_hopMouseDragged(evt);
            }
        });

        logScale.setSelected(true);
        logScale.setText("log (scale)");
        logScale.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        logScale.setMargin(new java.awt.Insets(0, 0, 0, 0));

        CheckFireball.setForeground(new java.awt.Color(0, 102, 255));
        CheckFireball.setSelected(true);
        CheckFireball.setText("hopping fireball");
        CheckFireball.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        CheckFireball.setMargin(new java.awt.Insets(0, 0, 0, 0));

        CheckFormula.setForeground(new java.awt.Color(255, 51, 51));
        CheckFormula.setSelected(true);
        CheckFormula.setText("hopping formula");
        CheckFormula.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        CheckFormula.setMargin(new java.awt.Insets(0, 0, 0, 0));

        stm_save.setText("save the changes ");
        stm_save.setEnabled(false);
        stm_save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                stm_saveMousePressed(evt);
            }
        });

        stm_load.setText("Load");
        stm_load.setEnabled(false);
        stm_load.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                stm_loadMousePressed(evt);
            }
        });

        Checkmix.setForeground(new java.awt.Color(51, 204, 0));
        Checkmix.setText("mix ");
        Checkmix.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        Checkmix.setMargin(new java.awt.Insets(0, 0, 0, 0));

        NTOT_Edit.setFont(new java.awt.Font("Dialog", 1, 14));

        stm_all.setText("see all");
        stm_all.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        stm_all.setMargin(new java.awt.Insets(0, 0, 0, 0));

        formula.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/formula.gif"));

        Ahop.setText("0.00000");

        Whop.setText("1.00");

        alfahop.setText("0");

        cuthop.setText("0.00");

        stm_change.setText("change ");
        stm_change.setEnabled(false);
        stm_change.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                stm_changeMousePressed(evt);
            }
        });

        stm_run.setText("set A ");
        stm_run.setEnabled(false);
        stm_run.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                stm_runMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel31Layout = new org.jdesktop.layout.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel31Layout.createSequentialGroup()
                        .add(formula)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(Ahop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 80, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(Whop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 80, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(alfahop, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                            .add(cuthop)))
                    .add(jPanel31Layout.createSequentialGroup()
                        .add(10, 10, 10)
                        .add(stm_run)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(corte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(stm_change))))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel31Layout.createSequentialGroup()
                .add(jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel31Layout.createSequentialGroup()
                        .add(Ahop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Whop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cuthop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(alfahop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(formula))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(stm_change, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel31Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(corte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(stm_run, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        stm_paint.setText("Paint");
        stm_paint.setEnabled(false);
        stm_paint.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                stm_paintMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel30Layout = new org.jdesktop.layout.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, screen_hop, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel30Layout.createSequentialGroup()
                        .add(open_hopping, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(stm_load)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(NTOT_Edit, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 53, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 119, Short.MAX_VALUE)
                        .add(stm_save))
                    .add(jPanel30Layout.createSequentialGroup()
                        .add(jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(CheckFormula, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(Checkmix)
                            .add(logScale)
                            .add(CheckFireball)
                            .add(stm_all)
                            .add(stm_paint, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jPanel31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(open_hopping, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(stm_load, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(NTOT_Edit, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(stm_save, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(screen_hop, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 284, Short.MAX_VALUE)
                .add(13, 13, 13)
                .add(jPanel30Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 126, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel30Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(stm_paint, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(CheckFormula)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(CheckFireball)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Checkmix)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(logScale)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(stm_all)))
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout jFrameHoppingLayout = new org.jdesktop.layout.GroupLayout(jFrameHopping.getContentPane());
        jFrameHopping.getContentPane().setLayout(jFrameHoppingLayout);
        jFrameHoppingLayout.setHorizontalGroup(
            jFrameHoppingLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 457, Short.MAX_VALUE)
            .add(jPanel30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jFrameHoppingLayout.setVerticalGroup(
            jFrameHoppingLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 488, Short.MAX_VALUE)
            .add(jPanel30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        setTitle("javaSTM");
        TAB_STM.setFont(new java.awt.Font("Monospaced", 0, 12));
        jPanel24.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        STextArea_stm.setColumns(10);
        STextArea_stm.setRows(1);
        STextArea_stm.setTabSize(1);
        jScrollPane7.setViewportView(STextArea_stm);

        jButton41.setText("...");
        jButton41.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton41MousePressed(evt);
            }
        });

        Sname_stm.setText("current_i-j.out");

        jButton42.setText("accept");
        jButton42.setEnabled(false);
        jButton42.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton42MousePressed(evt);
            }
        });

        stm_help.setText("help");
        stm_help.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                stm_helpMousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel24Layout = new org.jdesktop.layout.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jButton42, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(Sname_stm, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel24Layout.createSequentialGroup()
                        .add(jButton41)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(stm_help)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 67, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel24Layout.createSequentialGroup()
                        .add(jButton42, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(Sname_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel24Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(stm_help, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jButton41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        open_stm.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/open.gif"));
        open_stm.setAlignmentY(0.0F);
        open_stm.setDisabledIcon(new javax.swing.ImageIcon(""));
        open_stm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                open_stmMousePressed(evt);
            }
        });

        save_stm.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/save.gif"));
        save_stm.setEnabled(false);
        save_stm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                save_stmMousePressed(evt);
            }
        });

        jTabbedPane3.setFont(new java.awt.Font("Monospaced", 0, 12));
        jPanel26.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        color_Fondo.setBackground(new java.awt.Color(255, 255, 255));
        color_Fondo.setForeground(new java.awt.Color(153, 153, 255));
        color_Fondo.setText("...");
        color_Fondo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_FondoMousePressed(evt);
            }
        });

        Sinter2.setValue(80);
        Sinter2.setAlignmentX(0.0F);
        Sinter2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                Sinter2MouseDragged(evt);
            }
        });

        Clabel.setBackground(new java.awt.Color(255, 255, 255));
        Clabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Sinter1.setValue(20);
        Sinter1.setAlignmentX(0.0F);
        Sinter1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                Sinter1MouseDragged(evt);
            }
        });

        color_inter_1.setBackground(new java.awt.Color(255, 255, 255));
        color_inter_1.setForeground(new java.awt.Color(153, 153, 255));
        color_inter_1.setText("...");
        color_inter_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_inter_1MousePressed(evt);
            }
        });

        color_ini.setBackground(new java.awt.Color(255, 255, 255));
        color_ini.setForeground(new java.awt.Color(153, 153, 255));
        color_ini.setText("...");
        color_ini.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_iniMousePressed(evt);
            }
        });

        color_inter_2.setBackground(new java.awt.Color(255, 255, 255));
        color_inter_2.setForeground(new java.awt.Color(153, 153, 255));
        color_inter_2.setText("...");
        color_inter_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_inter_2MousePressed(evt);
            }
        });

        color_fin.setBackground(new java.awt.Color(255, 255, 255));
        color_fin.setForeground(new java.awt.Color(153, 153, 255));
        color_fin.setText("...");
        color_fin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                color_finMousePressed(evt);
            }
        });

        jButton49.setText("accept");
        jButton49.setEnabled(false);
        jButton49.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton49.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton49MousePressed(evt);
            }
        });

        jButton60.setText("difumi.");
        jButton60.setEnabled(false);
        jButton60.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton60.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton60MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel26Layout = new org.jdesktop.layout.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(Sinter1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .add(Sinter2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .add(Clabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 149, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel26Layout.createSequentialGroup()
                        .add(color_ini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(color_inter_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 45, Short.MAX_VALUE)
                        .add(color_inter_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(color_fin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel26Layout.createSequentialGroup()
                        .add(color_Fondo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton60, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton49)))
                .addContainerGap())
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(color_ini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(color_inter_1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(color_fin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(color_inter_2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Sinter1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Clabel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Sinter2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel26Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(color_Fondo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton49)
                    .add(jButton60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        verEjesSTM.setSelected(true);
        verEjesSTM.setText("see info XY-Axis");
        verEjesSTM.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        verEjesSTM.setMargin(new java.awt.Insets(0, 0, 0, 0));

        verBarra.setSelected(true);
        verBarra.setText("see info Z-Axi");
        verBarra.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        verBarra.setMargin(new java.awt.Insets(0, 0, 0, 0));

        verCamino.setText("see Direction");
        verCamino.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        verCamino.setEnabled(false);
        verCamino.setMargin(new java.awt.Insets(0, 0, 0, 0));

        org.jdesktop.layout.GroupLayout jPanel25Layout = new org.jdesktop.layout.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel25Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel26, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(verEjesSTM)
                    .add(verBarra)
                    .add(verCamino))
                .addContainerGap())
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel26, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(verEjesSTM)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(verBarra)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(verCamino)
                .add(77, 77, 77))
        );
        jTabbedPane3.addTab("color", jPanel25);

        jPanel27.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        resol_X.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        resol_X.setText("jTextField1");
        resol_X.setAlignmentY(0.0F);
        resol_X.setAutoscrolls(false);
        resol_X.setEnabled(false);

        resol_Y.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        resol_Y.setText("150");
        resol_Y.setAlignmentY(0.0F);
        resol_Y.setAutoscrolls(false);

        jLabel33.setText("image size ( pixels ): ");

        jButton48.setText("accept");
        jButton48.setEnabled(false);
        jButton48.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton48.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton48MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel27Layout = new org.jdesktop.layout.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel27Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jButton48, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel33)
                    .add(jPanel27Layout.createSequentialGroup()
                        .add(resol_X, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(resol_Y, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel33)
                .add(4, 4, 4)
                .add(jPanel27Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(resol_X, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(resol_Y, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jButton48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel34.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel9.setText("set Col1 (x) ");

        jLabel10.setText("set Col2 (y)");

        jLabel11.setText("set Col3 (z,I)");

        Border.setText("Border ");
        Border.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        Border.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jButton34.setText("accept");
        jButton34.setEnabled(false);
        jButton34.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton34MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel34Layout = new org.jdesktop.layout.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel34Layout.createSequentialGroup()
                        .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel9)
                            .add(jLabel10)
                            .add(jLabel11))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 16, Short.MAX_VALUE)
                        .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, Col1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, Col2)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, Col3)))
                    .add(jPanel34Layout.createSequentialGroup()
                        .add(Border)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton34, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel9)
                    .add(Col1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel10)
                    .add(Col2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel11)
                    .add(Col3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel34Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(Border)
                    .add(jButton34, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout jPanel29Layout = new org.jdesktop.layout.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel29Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel34, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel27, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .add(15, 15, 15))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel27, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 85, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel34, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(17, 17, 17))
        );
        jTabbedPane3.addTab("Size", jPanel29);

        jButton46.setText("...");
        jButton46.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton46MousePressed(evt);
            }
        });

        D_lvs.setText("...");

        jLabel37.setText("*.lvs file:");

        jLabel36.setText("*.bas file:");

        D_bas.setText("...");

        jButton45.setText("...");
        jButton45.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton45MousePressed(evt);
            }
        });

        jPanel37.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        stmXini.setText("0.0");

        stmXfin.setText("10.0");

        stmYini.setText("0.0");

        stmZini.setText("0.0");

        stmYfin.setText("10.0");

        stmZfin.setText("10.0");

        jLabel47.setText("X");

        jLabel48.setText("Y");

        jLabel49.setText("Z");

        stm_seeVol1.setText("only the atoms ");
        stm_seeVol1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        stm_seeVol1.setEnabled(false);
        stm_seeVol1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        stm_seeVol1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stm_seeVol1MouseClicked(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel37Layout = new org.jdesktop.layout.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel37Layout.createSequentialGroup()
                        .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(stmXini)
                            .add(stmYini)
                            .add(stmZini, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(stmXfin)
                            .add(stmYfin)
                            .add(stmZfin, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel49)
                            .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jLabel47)
                                .add(jLabel48)))
                        .addContainerGap())
                    .add(stm_seeVol1)))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .add(stm_seeVol1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(stmXini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(stmXfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel47))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(stmYini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(stmYfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel48))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel37Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(stmZfin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(stmZini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel49))
                .addContainerGap())
        );

        jButton47.setText("accept");
        jButton47.setEnabled(false);
        jButton47.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton47.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton47MousePressed(evt);
            }
        });

        D_verAtomos.setText("see atoms");
        D_verAtomos.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        D_verAtomos.setEnabled(false);
        D_verAtomos.setMargin(new java.awt.Insets(0, 0, 0, 0));
        D_verAtomos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D_verAtomosMouseClicked(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel35Layout = new org.jdesktop.layout.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 171, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel35Layout.createSequentialGroup()
                            .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel35Layout.createSequentialGroup()
                                    .add(3, 3, 3)
                                    .add(jLabel37))
                                .add(jLabel36))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(D_lvs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(D_bas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jButton46, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jButton45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(jPanel35Layout.createSequentialGroup()
                            .add(jButton47)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(D_verAtomos))))
                .add(21, 21, 21))
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(D_bas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel36))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel37)
                    .add(jButton46, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(D_lvs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel35Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(D_verAtomos))
                .addContainerGap())
        );
        jTabbedPane4.addTab("path", jPanel35);

        seeBond1.setText(" Bonds");
        seeBond1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        seeBond1.setEnabled(false);
        seeBond1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        seeBond1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seeBond1MouseClicked(evt);
            }
        });

        TOL1.setMaximum(8);
        TOL1.setMinimum(1);
        TOL1.setValue(4);
        TOL1.setEnabled(false);

        jLabel39.setText("alfa");

        D_alfa.setMaximum(255);
        D_alfa.setValue(150);
        D_alfa.setEnabled(false);
        D_alfa.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                D_alfaMouseDragged(evt);
            }
        });

        jLabel40.setText("radio of atoms");

        D_Ratom.setText("6");

        stm_seeLabel.setText("see label");
        stm_seeLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        stm_seeLabel.setEnabled(false);
        stm_seeLabel.setMargin(new java.awt.Insets(0, 0, 0, 0));
        stm_seeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stm_seeLabelMouseClicked(evt);
            }
        });

        verIconosAtomos.setText("see picture of atoms");
        verIconosAtomos.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        verIconosAtomos.setEnabled(false);
        verIconosAtomos.setMargin(new java.awt.Insets(0, 0, 0, 0));
        verIconosAtomos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verIconosAtomosMouseClicked(evt);
            }
        });

        jButton53.setText("accept");
        jButton53.setEnabled(false);
        jButton53.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton53.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton53MousePressed(evt);
            }
        });

        stm_grosor.setText("2");

        jButton55.setText("TOL:");
        jButton55.setEnabled(false);
        jButton55.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton55.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton55MousePressed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel28Layout = new org.jdesktop.layout.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton53)
                    .add(stm_seeLabel)
                    .add(verIconosAtomos)
                    .add(jPanel28Layout.createSequentialGroup()
                        .add(seeBond1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 68, Short.MAX_VALUE)
                        .add(stm_grosor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel28Layout.createSequentialGroup()
                        .add(jLabel40)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 32, Short.MAX_VALUE)
                        .add(D_Ratom, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel28Layout.createSequentialGroup()
                        .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel39)
                            .add(jButton55))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(D_alfa, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, TOL1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel28Layout.createSequentialGroup()
                .add(14, 14, 14)
                .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(seeBond1)
                    .add(stm_grosor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jButton55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(TOL1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jLabel39)
                    .add(D_alfa, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(15, 15, 15)
                .add(jPanel28Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel40)
                    .add(D_Ratom, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(10, 10, 10)
                .add(stm_seeLabel)
                .add(14, 14, 14)
                .add(verIconosAtomos)
                .add(19, 19, 19)
                .add(jButton53, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jTabbedPane4.addTab("options", jPanel28);

        jTabbedPane3.addTab("atoms", jTabbedPane4);

        reload_stm.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/reload.gif"));
        reload_stm.setEnabled(false);
        reload_stm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                reload_stmMousePressed(evt);
            }
        });

        screen_stm.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        screen_stm.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        screen_stm.setEnabled(false);
        screen_stm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                screen_stmMousePressed(evt);
            }
        });
        screen_stm.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                screen_stmMouseDragged(evt);
            }
        });

        jScrollPane8.setViewportView(screen_stm);

        org.jdesktop.layout.GroupLayout TAB_STMLayout = new org.jdesktop.layout.GroupLayout(TAB_STM);
        TAB_STM.setLayout(TAB_STMLayout);
        TAB_STMLayout.setHorizontalGroup(
            TAB_STMLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_STMLayout.createSequentialGroup()
                .addContainerGap()
                .add(TAB_STMLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, TAB_STMLayout.createSequentialGroup()
                        .add(TAB_STMLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(TAB_STMLayout.createSequentialGroup()
                                .add(open_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(save_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(reload_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jTabbedPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 206, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel24, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        TAB_STMLayout.setVerticalGroup(
            TAB_STMLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_STMLayout.createSequentialGroup()
                .addContainerGap()
                .add(TAB_STMLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(TAB_STMLayout.createSequentialGroup()
                        .add(TAB_STMLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(open_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(save_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(reload_stm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE))
                    .add(jTabbedPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 266, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_STM, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(TAB_STM, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void stm_paintMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_paintMousePressed
        if(stm_paint.isEnabled()){
            Ahop.setText(cadena.pasarString(hopping.A));
            alfahop.setText(hopping.alfa+"");
            Whop.setText(hopping.W+"");
            cuthop.setText(cadena.pasarString(hopping.corte));
            DrawHopping(true);
        }
    }//GEN-LAST:event_stm_paintMousePressed
    
    private void stm_runMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_runMousePressed
        if(stm_run.isEnabled()){
            hopping.A= Double.valueOf(Ahop.getText()).doubleValue();
            hopping.W= Double.valueOf(Whop.getText()).doubleValue();
            hopping.alfa = Double.valueOf(alfahop.getText()).doubleValue();
            if(corte.getValue().hashCode()<0)corte.setValue(hopping.NEnergias-1);
            if(corte.getValue().hashCode()>=hopping.NEnergias)corte.setValue(0);
            hopping.LoadA(corte.getValue().hashCode());
            Ahop.setText(cadena.pasarString(hopping.A));
            cuthop.setText(cadena.pasarString(hopping.corte));
            DrawHopping(true);
        }
    }//GEN-LAST:event_stm_runMousePressed
    
    private void stm_changeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_changeMousePressed
        if(stm_change.isEnabled()){
            hopping.A= Double.valueOf(Ahop.getText()).doubleValue();
            hopping.W= Double.valueOf(Whop.getText()).doubleValue();
            hopping.alfa = Double.valueOf(alfahop.getText()).doubleValue();
            hopping.corte = Double.valueOf(cuthop.getText()).doubleValue();
            DrawHopping(true);
        }
    }//GEN-LAST:event_stm_changeMousePressed
    
    private void stm_loadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_loadMousePressed
        if(stm_load.isEnabled()){
            hopping.nhop=NTOT_Edit.getValue().hashCode();
            hopping.nhop=(hopping.nhop<0)?0:hopping.nhop;
            hopping.nhop=(hopping.nhop>=hopping.NTOT)?(hopping.NTOT-1):hopping.nhop;
            NTOT_Edit.setValue(hopping.nhop);
            hopping.LoadParametrosAjuste(hopping.nhop);
            Ahop.setText(cadena.pasarString(hopping.A));
            alfahop.setText(hopping.alfa+"");
            Whop.setText(hopping.W+"");
            cuthop.setText(cadena.pasarString(hopping.corte));
            DrawHopping(true);
        }
    }//GEN-LAST:event_stm_loadMousePressed
    
    private void stm_saveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_saveMousePressed
        hopping.SAVE(  Ahop.getText(), alfahop.getText(), Whop.getText(), cuthop.getText() );
        hopping.LoadHopping();//recargamos!!
        hopping.LoadParametrosAjuste(hopping.nhop);
        Ahop.setText(cadena.pasarString(hopping.A));
        alfahop.setText(hopping.alfa+"");
        Whop.setText(hopping.W+"");
        cuthop.setText(cadena.pasarString(hopping.corte));
        DrawHopping(true);
    }//GEN-LAST:event_stm_saveMousePressed
    
    private void screen_hopMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_hopMouseDragged
        if(screen_hop.isEnabled()) {
            hopping.X_mouse_fin=evt.getX();
            hopping.Y_mouse_fin=evt.getY();
            hopping.Selected=true;
            DrawHopping(false);
        }
    }//GEN-LAST:event_screen_hopMouseDragged
    
    private void screen_hopMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_hopMouseReleased
        if(screen_hop.isEnabled()){
            hopping.lupa2D();
            hopping.Selected=false;
            DrawHopping(false);
        }
    }//GEN-LAST:event_screen_hopMouseReleased
    
    private void screen_hopMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_hopMousePressed
        if(evt.getButton()==evt.BUTTON1 && screen_hop.isEnabled()) {hopping.X_mouse_ini=evt.getX();hopping.Y_mouse_ini=evt.getY();}
    }//GEN-LAST:event_screen_hopMousePressed
    
    private void open_hoppingMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_open_hoppingMousePressed
        NTOT_Edit.setValue(0);
        if(hopping.inputfile != null) hopping.inputfile =  new chooser().fileChoose("Open file dens.out","open",hopping.inputfile.getAbsolutePath()) ;
        else hopping.inputfile =  new chooser().fileChoose("Open file","open",path+SEP+".") ;
        if(hopping.inputfile !=null) {
            hopping.LoadHopping();
            stm_save.setEnabled(true);
            stm_load.setEnabled(true);
            stm_run.setEnabled(true);
            stm_change.setEnabled(true);
            stm_paint.setEnabled(true);
            screen_hop.setEnabled(true);
            hopping.LoadParametrosAjuste(0);
            Ahop.setText(cadena.pasarString(hopping.A));
            alfahop.setText(hopping.alfa+"");
            Whop.setText(hopping.W+"");
            cuthop.setText(cadena.pasarString(hopping.corte));
            DrawHopping(true);
        }
        corte.setValue(1);
    }//GEN-LAST:event_open_hoppingMousePressed
    
    private void screen_stmMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_stmMouseDragged
        if(verCamino.isSelected()){
            if(   stm.X_mouse_fin!=evt.getX() ||  stm.Y_mouse_fin!=evt.getY()){
                stm.X_mouse_fin=evt.getX();
                stm.Y_mouse_fin=evt.getY();
                drawSTM(false);
            }
        }
    }//GEN-LAST:event_screen_stmMouseDragged
    
    private void screen_stmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_screen_stmMousePressed
        if(evt.getButton()==evt.BUTTON1) {
            stm.X_mouse_ini=evt.getX();
            stm.Y_mouse_ini=evt.getY();
        }
    }//GEN-LAST:event_screen_stmMousePressed
    
    private void reload_stmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reload_stmMousePressed
        if(stm.STM_enable)  {
            stm.maximos_dibujo();
            drawSTM(true);
        }
    }//GEN-LAST:event_reload_stmMousePressed
    
    private void jButton55MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton55MousePressed
        if(stm.STM_enable)  drawSTM(false);
    }//GEN-LAST:event_jButton55MousePressed
    
    private void jButton53MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton53MousePressed
        if(stm.STM_enable) drawSTM(false);
    }//GEN-LAST:event_jButton53MousePressed
    
    private void verIconosAtomosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verIconosAtomosMouseClicked
        if(stm.STM_enable) drawSTM(false);
    }//GEN-LAST:event_verIconosAtomosMouseClicked
    
    private void stm_seeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_seeLabelMouseClicked
        if(stm.STM_enable)  drawSTM(false);
    }//GEN-LAST:event_stm_seeLabelMouseClicked
    
    private void D_alfaMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D_alfaMouseDragged
        if(stm.STM_enable)  drawSTM(false);
    }//GEN-LAST:event_D_alfaMouseDragged
    
    private void seeBond1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_seeBond1MouseClicked
        if(stm.STM_enable)  drawSTM(false);
    }//GEN-LAST:event_seeBond1MouseClicked
    
    private void D_verAtomosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D_verAtomosMouseClicked
        if(stm.STM_enable)    drawSTM(false);
    }//GEN-LAST:event_D_verAtomosMouseClicked
    
    private void jButton47MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton47MousePressed
        if(stm.STM_enable)  drawSTM(false);
    }//GEN-LAST:event_jButton47MousePressed
    
    private void stm_seeVol1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_seeVol1MouseClicked
        if(stm.STM_enable)       drawSTM(false);
    }//GEN-LAST:event_stm_seeVol1MouseClicked
    
    private void jButton45MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton45MousePressed
        if(stm.inputfile !=null) stm.basfile=  new chooser().fileChoose("Open file bas","open",stm.inputfile.getPath()) ;
        else   stm.basfile =  new chooser().fileChoose("Open file bas","open",path+SEP+".") ;
        if(stm.basfile !=null) {
            D_bas.setText(stm.basfile.getAbsolutePath());
            if(!stm_seeVol1.isSelected()){
                stm.babel.read_fireball.basfile=stm.basfile;
                stm.babel.read_fireball.load_bas();
                stm.babel.infBas.bas=stm.babel.read_fireball.bas;
                stm.babel.read_fireball.lvsfile=stm.lvsfile;
                stm.babel.read_fireball.load_lvs();
                stm.babel.infBas.lvs=stm.babel.read_fireball.lvs;
                stm.babel.infBas.ajustar_maximos();
                stmZini.setText(cadena.pasarString(stm.babel.infBas.r_min[2]-0.1));
                stmZfin.setText(cadena.pasarString(stm.babel.infBas.r_max[2]+0.1));
                if(stm.babel.infBas.r_min[0]<stm.x_min) stmXini.setText(cadena.pasarString(stm.babel.infBas.r_min[0]-0.1));
                if(stm.babel.infBas.r_min[1]<stm.y_min) stmYini.setText(cadena.pasarString(stm.babel.infBas.r_min[1]-0.1));
                if(stm.babel.infBas.r_max[0]>stm.x_max) stmXfin.setText(cadena.pasarString(stm.babel.infBas.r_max[0]+0.1));
                if(stm.babel.infBas.r_max[1]>stm.x_max) stmYfin.setText(cadena.pasarString(stm.babel.infBas.r_max[1]+0.1));
            }
        }
    }//GEN-LAST:event_jButton45MousePressed
    
    private void jButton46MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton46MousePressed
        if(stm.inputfile !=null) stm.lvsfile=  new chooser().fileChoose("Open file lvs","open",stm.inputfile.getPath()) ;
        else stm.lvsfile =  new chooser().fileChoose("Open file lvs","open",path+SEP+".") ;
        if(stm.lvsfile !=null)  D_lvs.setText(stm.lvsfile.getAbsolutePath());
    }//GEN-LAST:event_jButton46MousePressed
    
    private void jButton34MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton34MousePressed
        if(stm.STM_enable){
            stm.col1=Col1.getValue().hashCode();
            stm.col2=Col2.getValue().hashCode();
            stm.col3=Col3.getValue().hashCode();
            stm.maximos_dibujo();
            drawSTM(true);
        }
    }//GEN-LAST:event_jButton34MousePressed
    
    private void jButton48MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton48MousePressed
        if(stm.STM_enable){
            stm.resolucion=(int) Double.valueOf(resol_Y.getText()).doubleValue();
            drawSTM(true);
            resol_X.setText(stm.ox+"");
            resol_Y.setText(stm.oy+"");
        }
    }//GEN-LAST:event_jButton48MousePressed
    
    private void jButton60MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton60MousePressed
        if(stm.STM_enable){
            stm.difuminate();
            drawSTM(false);
        }
    }//GEN-LAST:event_jButton60MousePressed
    
    private void jButton49MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton49MousePressed
        if(stm.STM_enable){
            stm.posicion_1=Sinter1.getValue();
            stm.posicion_2=Sinter2.getValue();
            drawSTM(false);
        }
    }//GEN-LAST:event_jButton49MousePressed
    
    private void color_finMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_finMousePressed
        color_fin.setBackground(JColorChooser.showDialog( this , "color final", color_fin.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_finMousePressed
    
    private void color_inter_2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_inter_2MousePressed
        color_inter_2.setBackground(JColorChooser.showDialog( this , "color final", color_inter_2.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_inter_2MousePressed
    
    private void color_iniMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_iniMousePressed
        color_ini.setBackground(JColorChooser.showDialog( this , "color final", color_ini.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_iniMousePressed
    
    private void color_inter_1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_inter_1MousePressed
        color_inter_1.setBackground(JColorChooser.showDialog( this , "color final", color_inter_1.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_inter_1MousePressed
    
    private void Sinter1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Sinter1MouseDragged
        dialogo_color();
    }//GEN-LAST:event_Sinter1MouseDragged
    
    private void Sinter2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Sinter2MouseDragged
        dialogo_color();
    }//GEN-LAST:event_Sinter2MouseDragged
    
    private void color_FondoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_color_FondoMousePressed
        color_Fondo.setBackground(JColorChooser.showDialog( this , "color final", color_inter_2.getBackground() ));
        dialogo_color();
    }//GEN-LAST:event_color_FondoMousePressed
    
    private void save_stmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_save_stmMousePressed
        if(stm.STM_enable)  new chooser().savePicture("Save file *.jpg","save",stm.inputfile.getAbsolutePath(),stm.image_buffered);
    }//GEN-LAST:event_save_stmMousePressed
    
    private void open_stmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_open_stmMousePressed
        File newFile = null;
        if(stm.inputfile != null) newFile =  new chooser().fileChoose("Open file dens.out","open",stm.inputfile.getAbsolutePath()) ;
        else newFile =  new chooser().fileChoose("Open file dens.out","open",path+"/.") ;
        if(newFile!=null)  {
            stm.inputfile=newFile;
            stm.col1=Col1.getValue().hashCode();
            stm.col2=Col2.getValue().hashCode();
            stm.col3=Col3.getValue().hashCode();
            stm.maximos_dibujo();
            drawSTM(true);
            stm_enable(true);
        }
    }//GEN-LAST:event_open_stmMousePressed
    
    private void stm_helpMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stm_helpMousePressed
        new help("help/utilities/stm.html").setVisible(true);
    }//GEN-LAST:event_stm_helpMousePressed
    
    private void jButton42MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton42MousePressed
        if(jButton42.isEnabled())   suma.sumaSTM(STextArea_stm,new File(Sname_stm.getText()));
    }//GEN-LAST:event_jButton42MousePressed
    
    private void jButton41MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton41MousePressed
        File newFile;
        if(stm.inputfile != null) newFile =  new chooser().fileChoose("Open file dens.out","open",stm.inputfile.getAbsolutePath()) ;
        else newFile =  new chooser().fileChoose("Open dens.out","open",path+SEP+".") ;
        if(newFile!=null) {
            STextArea_stm.setText(STextArea_stm.getText()+"\n"+newFile.getAbsolutePath());
            jButton42.setEnabled(true);
        }
    }//GEN-LAST:event_jButton41MousePressed
    
    
    // Declaración de variables - no modificar//GEN-BEGIN:variables
    private javax.swing.JTextField Ahop;
    private javax.swing.JCheckBox Border;
    private javax.swing.JCheckBox CheckFireball;
    private javax.swing.JCheckBox CheckFormula;
    private javax.swing.JCheckBox Checkmix;
    private javax.swing.JLabel Clabel;
    private javax.swing.JSpinner Col1;
    private javax.swing.JSpinner Col2;
    private javax.swing.JSpinner Col3;
    private javax.swing.JTextField D_Ratom;
    private javax.swing.JSlider D_alfa;
    private javax.swing.JTextField D_bas;
    private javax.swing.JTextField D_lvs;
    private javax.swing.JCheckBox D_verAtomos;
    private javax.swing.JSpinner NTOT_Edit;
    private javax.swing.JTextArea STextArea_stm;
    private javax.swing.JSlider Sinter1;
    private javax.swing.JSlider Sinter2;
    private javax.swing.JTextField Sname_stm;
    private javax.swing.JPanel TAB_STM;
    private javax.swing.JSlider TOL1;
    private javax.swing.JTextField Whop;
    private javax.swing.JTextField alfahop;
    private javax.swing.JButton color_Fondo;
    private javax.swing.JButton color_fin;
    private javax.swing.JButton color_ini;
    private javax.swing.JButton color_inter_1;
    private javax.swing.JButton color_inter_2;
    private javax.swing.JSpinner corte;
    private javax.swing.JTextField cuthop;
    private javax.swing.JLabel formula;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton60;
    private javax.swing.JFrame jFrameHopping;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JCheckBox logScale;
    private javax.swing.JButton open_hopping;
    private javax.swing.JButton open_stm;
    private javax.swing.JButton reload_stm;
    private javax.swing.JTextField resol_X;
    private javax.swing.JTextField resol_Y;
    private javax.swing.JButton save_stm;
    private javax.swing.JLabel screen_hop;
    private javax.swing.JLabel screen_stm;
    private javax.swing.JCheckBox seeBond1;
    private javax.swing.JTextField stmXfin;
    private javax.swing.JTextField stmXini;
    private javax.swing.JTextField stmYfin;
    private javax.swing.JTextField stmYini;
    private javax.swing.JTextField stmZfin;
    private javax.swing.JTextField stmZini;
    private javax.swing.JCheckBox stm_all;
    private javax.swing.JButton stm_change;
    private javax.swing.JTextField stm_grosor;
    private javax.swing.JButton stm_help;
    private javax.swing.JButton stm_load;
    private javax.swing.JButton stm_paint;
    private javax.swing.JButton stm_run;
    private javax.swing.JButton stm_save;
    private javax.swing.JCheckBox stm_seeLabel;
    private javax.swing.JCheckBox stm_seeVol1;
    private javax.swing.JCheckBox verBarra;
    private javax.swing.JCheckBox verCamino;
    private javax.swing.JCheckBox verEjesSTM;
    private javax.swing.JCheckBox verIconosAtomos;
    // Fin de declaración de variables//GEN-END:variables
    
    //--------STM------------------------
    void stm_enable(boolean ena){
        stm.STM_enable=ena;
        save_stm.setEnabled(ena);
        reload_stm.setEnabled(ena);
        jButton49.setEnabled(ena);
        jButton48.setEnabled(ena);
        jButton47.setEnabled(ena);
        jButton34.setEnabled(ena);
        jButton53.setEnabled(ena);
        seeBond1.setEnabled(ena);
        jButton55.setEnabled(ena);
        jButton60.setEnabled(ena);
        D_alfa.setEnabled(ena);
        stm_seeLabel.setEnabled(ena);
        verIconosAtomos.setEnabled(ena);
        D_verAtomos.setEnabled(ena);
        stm_seeVol1.setEnabled(ena);
        TOL1.setEnabled(ena);
        verCamino.setEnabled(ena);
        
    }
    
    
    void dialogo_color(){
        BufferedImage color_buffer;
        Graphics color_graphics ;
        color_buffer = new BufferedImage(Clabel.getWidth() ,Clabel.getHeight() , BufferedImage.TYPE_INT_RGB);
        color_graphics = color_buffer.createGraphics();
        int azul=0,rojo=0,verde=0;
        stm.colorFondo=color_Fondo.getBackground();
        stm.colorIni=color_ini.getBackground();
        stm.colorInter1=color_inter_1.getBackground();
        stm.colorInter2=color_inter_2.getBackground();
        stm.colorFin = color_fin.getBackground();
        int p_1=(Sinter1.getValue()*Clabel.getWidth())/Sinter1.getMaximum();
        int p_2=(Sinter2.getValue()*Clabel.getWidth())/Sinter2.getMaximum();
        if(p_1 >= p_2){
            int auxpos=p_2;
            p_2=p_1;
            p_1=auxpos;
        }
        for(int C_aux=0;C_aux < Clabel.getWidth(); C_aux+=4){
            
            if(C_aux<p_1 && p_1 > 0) {
                azul=C_aux*(stm.colorInter1.getBlue()-stm.colorIni.getBlue())/p_1 + stm.colorIni.getBlue();
                rojo=C_aux*(stm.colorInter1.getRed()-stm.colorIni.getRed())/p_1+stm.colorIni.getRed();
                verde=C_aux*(stm.colorInter1.getGreen()-stm.colorIni.getGreen())/p_1+stm.colorIni.getGreen();
            }
            if(C_aux>=p_1 && C_aux<p_2 && p_1!=p_2) {
                azul=(C_aux-p_1)*(stm.colorInter2.getBlue()-stm.colorInter1.getBlue())/(p_2-p_1) + stm.colorInter1.getBlue();
                rojo=(C_aux-p_1)*(stm.colorInter2.getRed()-stm.colorInter1.getRed())/(p_2-p_1)+stm.colorInter1.getRed();
                verde=(C_aux-p_1)*(stm.colorInter2.getGreen()-stm.colorInter1.getGreen())/(p_2-p_1)+stm.colorInter1.getGreen();
            }
            if(C_aux >= p_2  && p_2 < Clabel.getWidth() ){
                azul=(C_aux-p_2)*(stm.colorFin.getBlue()-stm.colorInter2.getBlue())/(Clabel.getWidth()-p_2)+stm.colorInter2.getBlue();
                rojo=(C_aux-p_2)*(stm.colorFin.getRed()-stm.colorInter2.getRed())/(Clabel.getWidth()-p_2)+stm.colorInter2.getRed();
                verde=(C_aux-p_2)*(stm.colorFin.getGreen()-stm.colorInter2.getGreen())/(Clabel.getWidth()-p_2)+stm.colorInter2.getGreen();
            }
            //azul  =  (int) (C[lx][ly]*Math.cos((C[lx][ly])*Math.PI/255/2)) ; //(C[lx][ly]*Math.pow(C[lx][ly],6)/Math.pow(255,6));
            color_graphics.setColor(new Color(rojo,verde,azul));
            color_graphics.fillRect(C_aux,0,4, Clabel.getHeight());
        }
        //  Dcolor_panel.getGraphics().drawImage(color_buffer,0,0,this);
        ImageIcon Cicon = new ImageIcon(color_buffer);
        Clabel.setIcon(Cicon);
        //ojo con esto -> deriva del problema de inicializar toda la mierda esta
    }
    
    void drawSTM(boolean calcular){
        stm.alfa=D_alfa.getValue();
        stm.basfile=new File(D_bas.getText());
        stm.lvsfile=new File(D_lvs.getText());
        stm.verAtomos=D_verAtomos.isSelected();
        stm.radio = (int) (Double.valueOf(D_Ratom.getText()).doubleValue());
        stm.verIconosAtomos=verIconosAtomos.isSelected();
        stm.babel.infBas.R_min[0]=Double.valueOf(stmXini.getText()).doubleValue();
        stm.babel.infBas.R_min[1]=Double.valueOf(stmYini.getText()).doubleValue();
        stm.babel.infBas.R_min[2]=Double.valueOf(stmZini.getText()).doubleValue();
        stm.babel.infBas.R_max[0]=Double.valueOf(stmXfin.getText()).doubleValue();
        stm.babel.infBas.R_max[1]=Double.valueOf(stmYfin.getText()).doubleValue();
        stm.babel.infBas.R_max[2]=Double.valueOf(stmZfin.getText()).doubleValue();
        stm.babel.infBas.tol=TOL1.getValue();
        stm.seeLabel=stm_seeLabel.isSelected();
        stm.babel.infBas.seeBond=seeBond1.isSelected();
        stm.grosor=(int) Double.valueOf(stm_grosor.getText()).doubleValue();
        stm.babel.infBas.seeCell_Vol=stm_seeVol1.isSelected();
        screen_stm.setEnabled(true) ;
        if(calcular)  {
            // clock(true);
            stm.calcular_dibujo();
            //  System.out.println(stm.resolucion+" "+stm.oy);
            // clock(false);
            if(!stm_seeVol1.isSelected()){
                stmXini.setText(cadena.pasarString(stm.x_min-0.1));
                stmYini.setText(cadena.pasarString(stm.y_min-0.1));
                stmXfin.setText(cadena.pasarString(stm.x_max+0.1));
                stmYfin.setText(cadena.pasarString(stm.y_max+0.1));
            }
        }
        stm.borde=Border.isSelected();
        stm.col1=Col1.getValue().hashCode();
        stm.col2=Col2.getValue().hashCode();
        stm.col3=Col3.getValue().hashCode();
        stm.verEjes=verEjesSTM.isSelected();
        stm.verBarra=verBarra.isSelected();
        stm.pintar_dibujo();
        stm.verDireccion=verCamino.isSelected();
        if(stm.verDireccion) stm.pintar_direccion();
        screen_stm.setIcon(stm.icon);
    }
    
    
    void DrawHopping(boolean ajustar_maximos){
        hopping.logScale=logScale.isSelected();
        hopping.sX=screen_hop.getWidth()-5;
        hopping.sY=screen_hop.getHeight()-5;
        hopping.CheckFireball=CheckFireball.isSelected();
        hopping.CheckFormula = CheckFormula.isSelected();
        hopping.CheckMix = Checkmix.isSelected();
        hopping.PintarTODOS=stm_all.isSelected();
        if(ajustar_maximos) hopping.ajustarMaximos();
        hopping.Planos_paralelos();
        screen_hop.setIcon(hopping.icon);
    }
    
}
