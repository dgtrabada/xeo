/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import javax.swing.JTextArea;
import java.io.*;

public class suma {
    reader cadena = new reader();
    /** Creates a new instance of suma */
    public suma() {
    }
    
    void sumaDensidad(JTextArea STextArea, File outFile){
        if(!STextArea.getText().equals("")){
            int nS=0;
            for(int i=1;i<=STextArea.getLineCount();i++){
                if(!cadena.readColString(1,cadena.readLine(i,STextArea.getText())).equals("0.0")) nS++;
                // if(nCol(readLine(i,STextArea.getText()))==1) System.out.println(readCol(1,readLine(i,STextArea.getText()))+"...."+nC);
                //else System.out.println(readCol(1,readLine(i,STextArea.getText()))+".."+readCol(2,readLine(i,STextArea.getText())));
            }
            String str [] = new String[nS];  //suponemos los mismo valores de x
            int Nm [] = new int[nS];
            int N_max=1;
            double CA [] = new double [nS];
            //     System.out.println(C_list.getItemAt(i).toString());
            int iS=0;
            try{
                BufferedReader [] inFile = new BufferedReader[nS];
                LineNumberReader [] inLines = new LineNumberReader[nS];
                for(int i=1;i<=STextArea.getLineCount();i++){
                    if(!cadena.readColString(1,cadena.readLine(i,STextArea.getText())).equals("0.0")){
                        inFile[iS] = new BufferedReader(new FileReader(cadena.readColString(1,cadena.readLine(i,STextArea.getText()))));
                        if(cadena.nCol(cadena.readLine(i,STextArea.getText()))==1)  CA[iS]=1.0;
                        else  CA[iS]=cadena.readColDouble(2,cadena.readLine(i,STextArea.getText()));
                        inLines[iS]= new LineNumberReader(inFile[iS]);
                        iS++;
                    }
                }
                for(int i=0;i<nS;i++) {
                    str[i] = inFile[i].readLine();
                    Nm[i] = cadena.nCol(str[i]);
                    N_max=(N_max<Nm[i])?Nm[i]:N_max;
                }
                
                for(int i=0;i<nS;i++) {
                    inLines[i].close();
                    inFile[i].close();
                }
            }catch (IOException oe) {System.out.println("hay error/es E1 en la suma");}
            try{
                FileOutputStream archivo_ant = new FileOutputStream(outFile.getAbsolutePath());
                DataOutputStream archivo = new DataOutputStream(archivo_ant);
                //   archivo.writeBytes("Copyright 2006  by Daniel Gonzalez Trabada \njavaSTM is free software you can redistribute it and/or modify it under the terms of the \nGNU General Public License as published by the Free Software Foundation. \n \n");
                BufferedReader [] inFile = new BufferedReader[nS];
                LineNumberReader [] inLines = new LineNumberReader[nS];
                iS=0;
                for(int i=1;i<=STextArea.getLineCount();i++){
                    if(!cadena.readColString(1,cadena.readLine(i,STextArea.getText())).equals("0.0")){
                        inFile[iS] = new BufferedReader(new FileReader(cadena.readColString(1,cadena.readLine(i,STextArea.getText()))));
                        if(cadena.nCol(cadena.readLine(i,STextArea.getText()))==1)  CA[iS]=1.0;
                        else  CA[iS]=cadena.readColDouble(2,cadena.readLine(i,STextArea.getText()));
                        inLines[iS]= new LineNumberReader(inFile[iS]);
                        iS++;
                    }
                }
                double Cm[][] = new double [N_max+1][nS];
                double aux[] = new double [N_max+1];
                String cadenaText="";
                while ((str[0] = inFile[0].readLine()) != null) {
                    aux[0]=0;
                    cadenaText="";
                    for(int i=1;i<nS;i++){aux[i]=0; str[i]=inLines[i].readLine();}
                    for(int j=0;j<nS;j++ )
                        for(int i=1;i<=Nm[j];i++) {
                        if(j==0) aux[i]=0;
                        Cm[i][j]= cadena.readColDouble(i,str[j]);
                        if(i==1) aux[i]=Cm[i][0]*CA[0];
                        else{
                            if(i<Nm[j]-1) aux[i]=aux[i]+Cm[i][j]*CA[j];
                            if(i==Nm[j]-1) aux[N_max-1]=aux[N_max-1]+Cm[i][j]*CA[j]; //hacemos todas
                            if(i==Nm[j])aux[N_max]=aux[N_max]+Cm[i][j]*CA[j];
                        }
                        }
                    for(int i=1;i<=N_max;i++) cadenaText+="   "+ cadena.pasarString(aux[i]);
                    archivo.writeBytes( cadenaText+"\n");
                    //    System.out.println( Double.valueOf(readCol(1,str[0])).doubleValue()+"\t"+ Double.valueOf(readCol(2,str[0])).doubleValue()+"\t"+aux/auxd);
                    
                }
                archivo.close();
                archivo_ant.close();
                for(int i=0;i<nS;i++) {
                    inLines[i].close();
                    inFile[i].close();
                }
                
            }catch (IOException oe) {System.out.println("hay error/es E1 en la suma");}
        }
    }
    
    void sumaSTM(JTextArea STextArea, File outFile){
        int nS=0;
        for(int i=1;i<=STextArea.getLineCount();i++){
            if(!cadena.readColString(1,cadena.readLine(i,STextArea.getText())).equals("0.0")) nS++;
            // if(nCol(readLine(i,STextArea.getText()))==1) System.out.println(readCol(1,readLine(i,STextArea.getText()))+"...."+nC);
            //else System.out.println(readCol(1,readLine(i,STextArea.getText()))+".."+readCol(2,readLine(i,STextArea.getText())));
        }
        //     System.out.println(C_list.getItemAt(i).toString());
        try{
            FileOutputStream archivo_ant = new FileOutputStream(outFile);
            DataOutputStream archivo = new DataOutputStream(archivo_ant);
            archivo.writeBytes("Copyright 2006  by Daniel Gonzalez Trabada \njavaSTM is free software you can redistribute it and/or modify it under the terms of the \nGNU General Public License as published by the Free Software Foundation. \n \n");
            
            BufferedReader [] inFile = new BufferedReader[nS];
            LineNumberReader [] inLines = new LineNumberReader[nS];
            double CA [] = new double [nS];
            int iS=0;
            for(int i=1;i<=STextArea.getLineCount();i++){
                if(!cadena.readColString(1,cadena.readLine(i,STextArea.getText())).equals("0.0")){
                    inFile[iS] = new BufferedReader(new FileReader(cadena.readColString(1,cadena.readLine(i,STextArea.getText()))));
                    if(cadena.nCol(cadena.readLine(i,STextArea.getText()))==1)  CA[iS]=1.0;
                    else  CA[iS]=cadena.readColDouble(2,cadena.readLine(i,STextArea.getText()));
                    inLines[iS]= new LineNumberReader(inFile[iS]);
                    iS++;
                }
            }
            
            
            String str []= new String[nS];
            //leemos el archivo para tomar el maximo y el minimo
            int N=0;
            double [] auxZ = new double [nS];
            double aux=0,auxd=0;
            while (( str[0] = inLines[0].readLine()) != null) {
                N++;
                for(int i=1;i<nS;i++) str[i]=inLines[i].readLine();
                if(N>4){  //dejamos esto
                    for(int i=0;i<nS;i++) auxZ[i]= cadena.readColDouble(3,str[i]);
                    aux=0;
                    auxd=0;
                    for(int i=0;i<nS;i++) {
                        aux+=auxZ[i]*Double.valueOf( CA[i] ).doubleValue();
                        auxd+=Double.valueOf(CA[i]).doubleValue();
                        //  System.out.println(auxZ[i]+" i="+i);
                    }
                    archivo.writeBytes( cadena.pasarString(cadena.readColDouble(1,str[0]))+"  \t  "+cadena.pasarString(cadena.readColDouble(2,str[0]))+"  \t  "+cadena.pasarString(aux/auxd)+"\n");
                    //    System.out.println( Double.valueOf(readCol(1,str[0])).doubleValue()+"\t"+ Double.valueOf(readCol(2,str[0])).doubleValue()+"\t"+aux/auxd);
                }
            }
            
            archivo.close();
            archivo_ant.close();
            for(int i=0;i<nS;i++) {
                inLines[i].close();
                inFile[i].close();
            }
            
        }catch (IOException oe) {System.out.println("hay error/es E1 en la suma");}
        
    }
}
