/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.Vector;
import java.awt.*;

public class reader {
    
    String aux;
    double auxD;
    int auxI;
    File auxF;
    
    reader(){}
    
    
    String readColString(int i,String Cadena){
        //            1               2               3
        //     |------|******|---------|******|-------|****|
        //Bit  000000011111111000000000111111110000000111111
        aux="0.0";
        int COL=0;
        boolean Bit=false;
        if(Cadena!=null){
            for(int j = 0; j<Cadena.length(); j++ ){
                if(Cadena.substring(j,j+1).equals(" ") || Cadena.substring(j,j+1).equals("\t")) Bit=false;
                else{
                    if(!Bit){
                        COL++;
                        Bit=true;
                        if(COL==i)aux=Cadena.substring(j,j+1);
                    }else if(COL==i)aux+=Cadena.substring(j,j+1);
                    
                }
            }
        }
        if(i>COL)aux="0.0";
        return aux.trim();
    }
    
    String readColStringSEP(int i,String Cadena, String SEP){
        //            1               2               3
        //     |------|******|---------|******|-------|****|
        //Bit  000000011111111000000000111111110000000111111
        aux="0.0";
        int COL=0;
        boolean Bit=false;
        if(Cadena!=null){
            for(int j = 0; j<Cadena.length(); j++ ){
                if(Cadena.substring(j,j+1).equals(SEP)) Bit=false;
                else{
                    if(!Bit){
                        COL++;
                        Bit=true;
                        if(COL==i)aux=Cadena.substring(j,j+1);
                    }else if(COL==i)aux+=Cadena.substring(j,j+1);
                    
                }
            }
        }
        if(i>COL)aux="0.0";
        return aux.trim();
    }
    
    
    double readColDouble(int i, String Cadena){
        auxD=0.0 ;
        try{
            auxD=Double.valueOf(readColString(i,Cadena)).doubleValue();
        }catch(NumberFormatException ex){System.out.println("error in  readColDouble : reader.java : "+Cadena);}
        return auxD ;
    }
    
    int readColInt(int i, String Cadena){
        auxI=0 ;
        try{
            auxI=(int) Double.valueOf(readColString(i,Cadena)).doubleValue();
        }catch(NumberFormatException ex){System.out.println("error in  readColInt : reader.java : "+Cadena);}
        return auxI ;
    }
    
    File readColFile(int i, String Cadena){
        auxF=null ;
        try{
            auxF=new File(readColString(i,Cadena));
        }catch(NumberFormatException ex){System.out.println("error in  readColFile : reader.java : "+Cadena);}
        return auxF ;
    }
    
    int endCol(int i,String Cadena){
        //            1               2               3
        //     |------|******|---------|******|-------|****|
        //Bit  000000011111111000000000111111110000000111111
        //                  |                |            |
        //return            15               30           45
        int COL=0,n=0;
        boolean Bit=false;
        if(i==0) n=0;
        else{
            if(Cadena!=null){
                for(int j = 0; j<Cadena.length(); j++ ){
                    if(COL<i)n++;
                    if(Cadena.substring(j,j+1).equals(" ") || Cadena.substring(j,j+1).equals("\t")) Bit=false;
                    else{
                        if(!Bit){
                            COL++;
                            Bit=true;
                            if(COL==i)n++;
                        }else if(COL==i)n++;
                    }
                }
            }
        }
        return n;
    }
    
    String SubtStrig(String A,String B,int col){
        //sustiuimos _._._.A.A.A   por  _._._._.B.B es decir colB en colA
        aux=A.substring(0,endCol(col-1,A));
        for(int i=1;i<(endCol(col,A)-endCol(col-1,A)-B.length());i++) aux+=" ";
        aux+=B;
        aux+=A.substring(endCol(col,A)-1,A.length());
        return aux;
    }
    
    String readLine(int i,String Cadena){
        //            1               2               3
        //     |------|******|---------|******|-------|****|
        //Bit  000000011111111000000000111111110000000111111
        aux="0.0";
        int COL=0;
        boolean Bit=false;
        if(Cadena!=null){
            for(int j = 0; j<Cadena.length(); j++ ){
                if(Cadena.substring(j,j+1).equals("\n")) Bit=false;
                else{
                    if(!Bit){
                        COL++;
                        Bit=true;
                        if(COL==i)aux=Cadena.substring(j,j+1);
                    }else if(COL==i)aux+=Cadena.substring(j,j+1);
                    
                }
            }
        }
        if(i>COL)aux="0.0";
        return aux;
    }
    int nLine(String Cadena){
        int COL=0;
        boolean Bit=false;
        if(Cadena!=null)
            for(int j = 0; j<Cadena.length(); j++ ){
            if(Cadena.substring(j,j+1).equals("\n")) Bit=false;
            else{if(!Bit){COL++;Bit=true;}}
            }
        return COL;
    }
    
    
    int nCol(String Cadena){
        int COL=0;
        boolean Bit=false;
        if(Cadena!=null)
            for(int j = 0; j<Cadena.length(); j++ ){
            if(Cadena.substring(j,j+1).equals(" ") || Cadena.substring(j,j+1).equals("\t")) Bit=false;
            else{if(!Bit){COL++;Bit=true;}}
            }
        return COL;
    }
    
    Vector readFile( File inputFile ){
        Vector vector = new Vector();
        if(inputFile.exists()) {
            try {
                BufferedReader in = new BufferedReader(new FileReader(inputFile)) ;
                String str="";
                while ((str = in.readLine()) != null) {
                    vector.addElement(str);
                }
                in.close();
            }catch (IOException oe) {System.out.println("error: read " +inputFile.getAbsolutePath());}
        } else System.out.println(inputFile.getAbsolutePath()+" doesn't exist");
        return vector;
    }
    
    Vector readFileCol(int i, File inputFile ){
        Vector vector = new Vector();
        if(inputFile.exists()) {
            try {
                BufferedReader in = new BufferedReader(new FileReader(inputFile.getPath())) ;
                String str="";
                while ((str = in.readLine()) != null) {
                    vector.addElement(readColString(i,str));
                }
                in.close();
            }catch (IOException oe) {System.out.println("error: read " +inputFile.getAbsolutePath().toString());}
        } else System.out.println(inputFile.getAbsolutePath()+" doesn't exist");
        return vector;
    }
    
    
    void writer( Vector vector , File inputFile ){
        try {
            FileOutputStream archivo = new FileOutputStream(inputFile);
            DataOutputStream in = new DataOutputStream(archivo);
            for(int i = 0 ; i < vector.size(); i++ ) in.writeBytes(vector.elementAt(i)+"\n");
            in.close();
            archivo.close();
        }catch (IOException oe) {System.out.println("error: read " +inputFile.getAbsolutePath());}
    }
    
    int numeroFilas(File inputFile){
        int nC=0;
        try {
            BufferedReader in = new BufferedReader(new FileReader(inputFile.getAbsolutePath())) ;
            String str="";
            nC=0;
            while ((str = in.readLine()) != null) nC++;
            in.close();
        }catch (IOException oe) {System.out.println("numeroCol");}
        return nC;
    }
    
    int numeroCol(File inputFile){
        try {
            BufferedReader in = new BufferedReader(new FileReader(inputFile.getAbsolutePath())) ;
            aux = in.readLine();
        }catch (IOException oe) {System.out.println("numeroCol");}
        return nCol(aux);
    }
    
    String noD(String a){
        if(a.indexOf("D")>0) aux = a.substring(0,a.indexOf("D"))+"E"+a.substring(a.indexOf("D")+1,a.length());
        else aux=a;
        return aux;
    }
    
    String pasarString(double z){
        String zOut="",zIn=z+"",Int="",Exp="";
        int n=0;
        int ex=-1;
        if(Math.abs(z)<1.0E-300) zOut="0.0";
        else{
            if((z>0.0001&&z<999999)||(z<-0.001&&z>-99999)){
                String h="";   //quitamos los 0000 que sobren
                for(int i=0;(i<zIn.length()&&i<6);i++)
                    h+=zIn.substring(i,i+1);
                int punto=0;
                for(int i=0;i<h.length();i++)
                    if(h.substring(i,i+1).equals("."))
                        punto=i;
                if(punto>0 && h.substring(h.length()-1,h.length()).equals("0")){
                    int corte=h.length();
                    for(int i = h.length();i>punto;i--)
                        if(h.substring(i-2,i).equals("00"))
                            corte=i-2;
                    zOut=h.substring(0,corte);
                }else zOut=h;
            } else {
                for(int i=0;i<zIn.length();i++)if(zIn.substring(i,i+1).equals("E"))ex=i;
                if(ex!=-1){
                    Exp=zIn.substring(ex,zIn.length());
                    Int=zIn.substring(0,ex-1);
                    for(int i=0;i<(6-Exp.length())&&i<Int.length();i++)zOut+=Int.substring(i,i+1);
                    if(zOut.substring(zOut.length()-1,zOut.length()).equals(".")) zOut=zOut.substring(0,zOut.length()-1);
                } else{
                    for(int i=0;i<zIn.length();i++)if(!(zIn.substring(i,i+1).equals("E")||zIn.substring(i,i+1).equals(".")||zIn.substring(i,i+1).equals("-")))Int+=zIn.substring(i,i+1);
                    if(Math.abs(z)<1)for(int i = -2; Math.abs(z)/Math.pow(10,i)<1;i-- ) Exp="E"+i;
                    else for(int i = 3; Math.abs(z)/Math.pow(10,i)>1;i++ ) Exp="E"+i;
                    if(zIn.substring(0,1).equals("-"))zOut+="-";
                    zOut+=Int.substring(0,1);
                    if((6-zOut.length()+Exp.length())>=2 ){
                        zOut+=".";
                        int aux=zOut.length();
                        for(int i=1;i<=(6-aux-Exp.length());i++)zOut+=Int.substring(i,i+1);
                    }
                }
                zOut+=Exp;
            }
            if(zOut.substring(zOut.length()-1,zOut.length()).equals(".")) zOut=zOut.substring(0,zOut.length()-1);
        }
        return zOut;
    }
    
    double potencia(double input){
        double aux=Math.abs(input);
        int i=0;
        if(aux<1) while(aux*Math.pow(10,i)<1)i++;
        else  while(aux*Math.pow(10,i)>1)i--;
        if(i<0)i++;
        input=Math.signum(input)*Math.pow(10,-i);
        return input;
    }
  /*  2500.0 1000.0
      250.0  100.0
      25.0   10.0
      2.5    1.0
      0.0    0.0
      0.25   0.1
      0.0025 0.0010
   */
    double ultimoDecimal(double a){
        a=((int) (a/potencia(a)))*potencia(a);
        return a;
    }
    
    double ultimos2Decimales(double a){
        double f =ultimoDecimal(a);
        a=ultimoDecimal(a-f);
        a=a+f;
        return a;
    }
    double ajustarDecimal(double y,double hy){
        //quiero que 1.345456 0.045 -> 1.340
        //           5421.215 15 -> 5420.0
        double aux=y/potencia(hy);
        if(aux<0) aux--;
        y=(int) (aux);
        return y*potencia(hy);
    }
    
    //  !formato de fotran ->  2x,f12.6  = Ix,fJ.k   float(I,J,K,string(entrada))
    String formatFortran(int I, int J , int K, double x){
        String ret="";
        aux="";
        int SA = (int) (x*Math.pow(10,K));
        aux=SA+"";
        if(Math.abs(x)>=1) ret=aux.substring(0,aux.length()-K)+"."+aux.substring(aux.length()-K,aux.length());
        else {
            if(x<0)ret="-0.";
            else ret="0.";
            for(int g=0;g<K-(Math.abs(SA)+"").toString().length();g++)ret+="0";
            ret+=Math.abs(SA);
        }
        ret=format(I+J,ret);
        //this is for the bas format file
        if(Math.abs(x)>1000) {
            aux=" ";
            for(int i=0;i<I;i++)aux+=" ";
            aux+=x;
            for(int i=0;i<J;i++)aux+=" ";
            ret=(aux).substring(0,J);
        }
        return ret;
    }
    
    String format(int i,double z){
        aux="";
        String Z=pasarString(z);
        for(int j=0;j<i-Z.length();j++) aux=" "+aux;
        return aux+Z;
    }
    String format(int i,int z){
        aux="";
        String Z=z+"";
        for(int j=0;j<i-Z.length();j++) aux=" "+aux;
        return aux+Z;
    }
    String format(int i,String z){
        aux="";
        for(int j=0;j<i-z.length();j++) aux=" "+aux;
        return aux+z;
    }
    
    
    String ceros(int i, int j){
        aux=j+"";
        int fin=i-aux.length();
        for(int h=0;h<fin;h++) aux=0+""+aux;
        return aux;
    }
    
    int colorcito(int k){
        int c=Color.BLACK.getRGB();
        if(k%10==2)  c=Color.RED.getRGB();
        if(k%10==3)  c=Color.CYAN.getRGB();
        if(k%10==4)  c=Color.BLUE.getRGB();
        if(k%10==5)  c=Color.DARK_GRAY.getRGB();
        if(k%10==7)  c=Color.GRAY.getRGB();
        if(k%10==8)  c=Color.GREEN.getRGB();
        if(k%10==9)  c=Color.ORANGE.getRGB();
        if(k%10==0)  c=Color.PINK.getRGB();
        return c;
    }
    
    
    
    //esta en pruebas, cuidado!, solo usar en grafica, si funciona sustituir  pasarString !!!
    String digitosGrafica(int dig, double z){
        String zOut="",zIn=z+"",Int="",Exp="";
        int n=0;
        int ex=-1;
        if(Math.abs(z)<1.0E-300) zOut="0.0";
        else{
            if((z>0.0001&&z<999999)||(z<-0.001&&z>-99999)){
                String h="";   //quitamos los 0000 que sobren
                for(int i=0;(i<zIn.length()&&i<dig);i++)
                    h+=zIn.substring(i,i+1);
                int punto=0;
                for(int i=0;i<h.length();i++)
                    if(h.substring(i,i+1).equals("."))
                        punto=i;
                if(punto>0 && h.substring(h.length()-1,h.length()).equals("0")){
                    int corte=h.length();
                    for(int i = h.length();i>punto;i--)
                        if(h.substring(i-2,i).equals("00"))
                            corte=i-2;
                    zOut=h.substring(0,corte);
                }else zOut=h;
            } else {
                for(int i=0;i<zIn.length();i++)if(zIn.substring(i,i+1).equals("E"))ex=i;
                if(ex!=-1){
                    Exp=zIn.substring(ex,zIn.length());
                    Int=zIn.substring(0,ex-1);
                    for(int i=0;i<(dig-Exp.length())&&i<Int.length();i++)zOut+=Int.substring(i,i+1);
                    if(zOut.substring(zOut.length()-1,zOut.length()).equals(".")) zOut=zOut.substring(0,zOut.length()-1);
                } else{
                    for(int i=0;i<zIn.length();i++)if(!(zIn.substring(i,i+1).equals("E")||zIn.substring(i,i+1).equals(".")||zIn.substring(i,i+1).equals("-")))Int+=zIn.substring(i,i+1);
                    if(Math.abs(z)<1)for(int i = -2; Math.abs(z)/Math.pow(10,i)<1;i-- ) Exp="E"+i;
                    else for(int i = 3; Math.abs(z)/Math.pow(10,i)>1;i++ ) Exp="E"+i;
                    if(zIn.substring(0,1).equals("-"))zOut+="-";
                    zOut+=Int.substring(0,1);
                    if((dig-zOut.length()+Exp.length())>=2 ){
                        zOut+=".";
                        int aux=zOut.length();
                        for(int i=1;i<=(dig-aux-Exp.length());i++)zOut+=Int.substring(i,i+1);
                    }
                }
                zOut+=Exp;
            }
            if(zOut.substring(zOut.length()-1,zOut.length()).equals(".")) zOut=zOut.substring(0,zOut.length()-1);
        }
        return zOut;
    }
    
    boolean startInNumber(String ggg){
        boolean out=false;
        if(ggg.substring(0,1).equals("0")) out=true;
        if(ggg.substring(0,1).equals("1")) out=true;
        if(ggg.substring(0,1).equals("2")) out=true;
        if(ggg.substring(0,1).equals("3")) out=true;
        if(ggg.substring(0,1).equals("4")) out=true;
        if(ggg.substring(0,1).equals("5")) out=true;
        if(ggg.substring(0,1).equals("6")) out=true;
        if(ggg.substring(0,1).equals("7")) out=true;
        if(ggg.substring(0,1).equals("8")) out=true;
        if(ggg.substring(0,1).equals("9")) out=true;
        return out;
    }
    
    boolean contiene(String ggg, String g){
        boolean out=false;
        for(int i = 0; i<=(ggg.length()-g.length());i++)
            if(ggg.substring(i,i+g.length()).equals(g)) out=true;
        return out;
    }
}