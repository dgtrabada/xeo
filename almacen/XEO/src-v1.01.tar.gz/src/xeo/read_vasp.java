/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.ArrayList;
import java.util.Vector;

public class read_vasp {
    ArrayList<atom> bas;
    reader cadena = new reader();
    double [][] lvs = new double[3][3];
    double lvsRes;
    double res;
    periodicTable  periodicTable = new  periodicTable();
    int natoms;
    boolean Error;
    String Error_out;
    String TIPOS="";
    int n_tipos;
    String MASAS;
    String SEP = System.getProperty("file.separator");
    /** Creates a new instance of read_vasp */
    public read_vasp() {
        bas = new ArrayList();
        lvsRes=1;
    }
    //--read----
    void Load(File infile){
        if(infile.exists())
            if(new File(infile.getParent()+SEP+"POTCAR").exists()){
            Vector aux=new Vector();
            try{
                int il=1;
                String str="";
                bas.clear();
                BufferedReader in = new BufferedReader(new FileReader(infile.getAbsolutePath()));
                aux.clear();
                str = in.readLine();
                str = in.readLine();
                lvsRes=cadena.readColDouble(1,str);
                for(int i=0;i<3;i++){
                    str = in.readLine();
                    lvs[i][0] =lvsRes*cadena.readColDouble(1,str);
                    lvs[i][1] =lvsRes*cadena.readColDouble(2,str);
                    lvs[i][2] =lvsRes*cadena.readColDouble(3,str);
                }
                TIPOS = in.readLine(); //importantisimo ...
                while ((str = in.readLine()) != null){
                    if(cadena.readColString(1,str).equals("Cartesian")){
                        str = in.readLine();
                        while (cadena.nCol(str)==6){
                            atom atom = new atom();
                            atom.posBas=il;
                            atom.posOut=il;
                            atom.R[0]=cadena.readColDouble(1,str);
                            atom.R[1]=cadena.readColDouble(2,str);
                            atom.R[2]=cadena.readColDouble(3,str);
                            if(cadena.readColString(4,str).equals("F")||cadena.readColString(5,str).equals("F")||cadena.readColString(6,str).equals("F"))
                                atom.fix=true;
                            bas.add(atom);
                            il++;
                            str = in.readLine();
                        }
                        natoms=bas.size();
                    }else aux.add(str);
                }
                in.close();
                Error=false;
                if(il==1) {
                    Error=true; //System.out.println("error read CASTEP ");
                    Error_out="we can't read this vasp file, we are working on";
                }
                if(!Error){
                    MASAS="";
                    BufferedReader potcar = new BufferedReader(new FileReader(infile.getParent()+SEP+"POTCAR"));
                    while ((str = potcar.readLine()) != null){
                        if(cadena.readColString(1,str).equals("POMASS")){
                            MASAS=MASAS+" "+cadena.readColString(3,str).trim();
                            MASAS=MASAS.substring(0,MASAS.length()-1);
                        }
                    }
                    potcar.close();
                    n_tipos =(int) Double.valueOf(cadena.nCol(TIPOS)).doubleValue();
                    int natom=0;
                    for(int i = 0; i<n_tipos; i++){
                        for(int j = 0; j<cadena.readColInt(i+1,TIPOS);j++){
                            bas.get(natom).Z=(int) (cadena.readColInt(i+1,MASAS)/2);
                            if(bas.get(natom).Z==0)bas.get(natom).Z=1; // el H no tiene neutron
                            bas.get(natom).symbol=periodicTable.getSymbol(bas.get(natom).Z);
                            natom++;
                        }
                    }
                }
            }catch (IOException oe) {System.out.println("error read .cell");}
            }
    }
    
    //--write---
    Vector writeOut(){
        Vector auR = new Vector();
        String auxFrag="";
        auR.add("project:");
        auR.add("1.000");
        auR.add("    "+cadena.formatFortran(2,14,6,lvs[0][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[0][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[0][2]*res));
        auR.add("    "+cadena.formatFortran(2,14,6,lvs[1][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[1][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[1][2]*res));
        auR.add("    "+cadena.formatFortran(2,14,6,lvs[2][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[2][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[2][2]*res));
        auR.add(TIPOS);
        auR.add("Cartesian");
        for(int i=0;i<bas.size();i++){
            if(!bas.get(i).fix) auxFrag=" T T T";
            else auxFrag=" F F F";
            auR.add(
                    cadena.formatFortran(2,14,6,bas.get(i).R[0]*res)
                    +cadena.formatFortran(2,14,6,bas.get(i).R[1]*res)
                    +cadena.formatFortran(2,14,6,bas.get(i).R[2]*res)+auxFrag) ;
        }
        return auR;
    }
    
    
    Vector savePosFix(File infile,boolean fragments){
        Vector aux=new Vector();
        if(infile.exists()){
            try{
                int il=1;
                String str="";
                BufferedReader in = new BufferedReader(new FileReader(infile.getAbsolutePath()));
                aux.clear();
                str = in.readLine();
                aux.add(str);
                str = in.readLine();
                aux.add(str);
                for(int i=0;i<3;i++){
                    //lvs
                    str = in.readLine();
                    aux.add(str);
                }
                //despues de lvs ...
                aux.add(TIPOS);
                int n=0;
                while (n<natoms){
                    str = in.readLine();
                    n+=cadena.readColInt(1,str);
                }
                while ((str = in.readLine()) != null){
                    aux.add(str) ;
                    if(cadena.readColString(1,str).equals("Cartesian")){
                        str = in.readLine();
                        while (cadena.nCol(str)==6){
                            str = in.readLine(); // pasamos las posiciones
                        }
                        String auxFrag="";
                        for(int i=0;i<bas.size();i++){
                            if(fragments){
                                if(!bas.get(i).fix) auxFrag=" T T T";
                                else auxFrag=" F F F";
                            } else{
                                if(!bas.get(i).selec) auxFrag=" T T T";
                                else auxFrag=" F F F";
                            }
                            aux.add(
                                    cadena.formatFortran(2,14,6,bas.get(i).R[0])
                                    +cadena.formatFortran(2,14,6,bas.get(i).R[1])
                                    +cadena.formatFortran(2,14,6,bas.get(i).R[2])+auxFrag) ;
                        }
                    }
                }
                in.close();
            }catch (IOException oe) {System.out.println("error read .cell");}
        }
        return aux;
    }
    
}
