/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import javax.swing.*;

public class calculadora_bas extends javax.swing.JFrame {
    reader cadena = new reader();
    Calc_bas cal = new Calc_bas();
    String homefireball;
    String path;
    periodicTable  periodicTable = new  periodicTable();
    /** Creates new form calculadora_bas */
    public calculadora_bas(String inifile,String home) {
        initComponents();
        inputText.setText(inifile);
        homefireball=home;
        path=inifile;
        this.setVisible(true);
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Código Generado ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        inputText = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        outputText = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        CalcX = new javax.swing.JTextField();
        CalcY = new javax.swing.JTextField();
        CalcZ = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        resText = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        rotText = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        n_interpol = new javax.swing.JTextField();

        setTitle("bas calculator");
        inputText.setColumns(20);
        inputText.setFont(new java.awt.Font("Monospaced", 0, 12));
        inputText.setRows(2);
        jScrollPane1.setViewportView(inputText);

        outputText.setColumns(20);
        outputText.setFont(new java.awt.Font("Monospaced", 0, 12));
        outputText.setRows(5);
        jScrollPane3.setViewportView(outputText);

        jLabel1.setText("Input files (it have the same number of atoms) ");

        jButton1.setText("add file");
        jButton1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });

        jButton2.setText("calulate");
        jButton2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton2MousePressed(evt);
            }
        });

        jButton3.setText("help");
        jButton3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton3MousePressed(evt);
            }
        });

        jButton4.setText("save as");
        jButton4.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton4MousePressed(evt);
            }
        });

        CalcX.setFont(new java.awt.Font("Monospaced", 0, 12));
        CalcX.setText("x[0]");

        CalcY.setFont(new java.awt.Font("Monospaced", 0, 12));
        CalcY.setText("y[0]");

        CalcZ.setFont(new java.awt.Font("Monospaced", 0, 12));
        CalcZ.setText("z[0]");

        jLabel3.setText("X =");

        jLabel4.setText("Y =");

        jLabel5.setText("Z =");

        jButton5.setText("diff");
        jButton5.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton5MousePressed(evt);
            }
        });

        jButton6.setText("rescalate");
        jButton6.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton6MousePressed(evt);
            }
        });

        resText.setText("4.0/2.0");

        jButton7.setText("rotate(Z)");
        jButton7.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton7MousePressed(evt);
            }
        });

        rotText.setText("60");

        jButton8.setText("pasar xyz");
        jButton8.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton8MousePressed(evt);
            }
        });

        jButton9.setText("interpolate");
        jButton9.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton9MousePressed(evt);
            }
        });

        n_interpol.setText("5");

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 68, Short.MAX_VALUE)
                        .add(jButton1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(jButton4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 240, Short.MAX_VALUE)
                        .add(jButton3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel4)
                            .add(jLabel3)
                            .add(jLabel5))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, CalcZ, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
                            .add(CalcY, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, CalcX, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(layout.createSequentialGroup()
                                .add(jButton7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(rotText))
                            .add(layout.createSequentialGroup()
                                .add(jButton6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(resText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 79, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(87, 87, 87)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createSequentialGroup()
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jButton5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jButton9)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(n_interpol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jButton8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(jButton1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton6)
                    .add(n_interpol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jButton9)
                    .add(jButton5)
                    .add(resText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton7)
                    .add(jButton8)
                    .add(rotText, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(CalcX, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel4)
                            .add(CalcY, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel5)
                            .add(CalcZ, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jLabel3))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jButton4)
                    .add(org.jdesktop.layout.GroupLayout.BASELINE, jButton3)
                    .add(org.jdesktop.layout.GroupLayout.BASELINE, jButton2))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                .addContainerGap())
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void jButton9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MousePressed
        interpolate((int) Double.valueOf(n_interpol.getText()).doubleValue());
    }//GEN-LAST:event_jButton9MousePressed
    
    private void jButton8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MousePressed
        pasarXYZ();
    }//GEN-LAST:event_jButton8MousePressed
    
    private void jButton7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MousePressed
        double a=Double.valueOf(rotText.getText()).doubleValue();
        a=a*Math.PI/180;
        CalcX.setText("x[0]*cos("+a+")+y[0]*sin("+a+")" );
        CalcY.setText("-x[0]*sin("+a+")+y[0]*cos("+a+")" );
        CalcZ.setText("z[0]");
        calcular();
    }//GEN-LAST:event_jButton7MousePressed
    
    private void jButton4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MousePressed
        File auxfile = fileChoose("Save *.bas","save",path) ;
        if(auxfile != null) saveFile(auxfile);
    }//GEN-LAST:event_jButton4MousePressed
    
    private void jButton3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MousePressed
        new help("help/type/other/basCalc.html").setVisible(true);
    }//GEN-LAST:event_jButton3MousePressed
    
    private void jButton6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MousePressed
        CalcX.setText("x[0]*"+resText.getText());
        CalcY.setText("y[0]*"+resText.getText());
        CalcZ.setText("z[0]*"+resText.getText());
        calcular();
    }//GEN-LAST:event_jButton6MousePressed
    
    private void jButton5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MousePressed
        CalcX.setText("x[0]-x[1]");
        CalcY.setText("y[0]-y[1]");
        CalcZ.setText("z[0]-z[1]");
        calcular();
    }//GEN-LAST:event_jButton5MousePressed
    
    private void jButton2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MousePressed
        calcular();
    }//GEN-LAST:event_jButton2MousePressed
    
    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MousePressed
        File newFile = fileChoose("Open *.bas","open",path) ;
        if(newFile!=null) inputText.setText(inputText.getText()+"\n"+newFile.getAbsolutePath());
    }//GEN-LAST:event_jButton1MousePressed
    
    
    // Declaración de variables - no modificar//GEN-BEGIN:variables
    private javax.swing.JTextField CalcX;
    private javax.swing.JTextField CalcY;
    private javax.swing.JTextField CalcZ;
    private javax.swing.JTextArea inputText;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField n_interpol;
    private javax.swing.JTextArea outputText;
    private javax.swing.JTextField resText;
    private javax.swing.JTextField rotText;
    // Fin de declaración de variables//GEN-END:variables
    
    void calcular(){
        outputText.setText(cal.calcular(CalcX.getText(),CalcY.getText(),CalcZ.getText(),inputText.getText()));
    }
    
    void pasarXYZ(){
        int nfiles=cadena.nLine(inputText.getText());
        outputText.setText("  ");
        for(int i = 0; i< nfiles; i++) {
            boolean error = false;
            if(!(new File(cadena.readLine(i+1,inputText.getText())).exists())) error=true;
            if(!error){
                try{
                    String str="";
                    BufferedReader inbas;
                    inbas = new BufferedReader(new FileReader(cadena.readLine(i+1,inputText.getText())));
                    int natom=0;
                    str = inbas.readLine(); //tomamos el numero de atomos de la primera
                    natom =cadena.readColInt(1,str);
                    int Zout=1;
                    double xout=0,yout=0,zout=0;
                    outputText.setText(outputText.getText()+"  "+natom+"\n");
                    for(int k=0;k<natom;k++){
                        str = inbas.readLine();
                        try{
                            Zout=cadena.readColInt(1,str);
                            xout=cadena.readColInt(2,str);
                            yout=cadena.readColInt(3,str);
                            zout=cadena.readColInt(4,str);
                        }catch(NumberFormatException ex){System.out.println("error read bas");}
                        //----------------------------------------
                        outputText.setText(outputText.getText()+"\n"+
                                cadena.format(4,periodicTable.getSymbol(Zout)) + cadena.formatFortran(2,12,6,xout) +
                                cadena.formatFortran(2,12,6,yout)+cadena.formatFortran(2,12,6,zout));
                    }
                    inbas.close();
                    outputText.setText(outputText.getText()+"\n");
                }catch (IOException oe) {System.out.println("error read basfile");}
            }
        }
    }
    
//--Interpolate, with the 2 first files
    void interpolate(int n){  //que chapuza, volver hacer usando infoBas !!
        n=(n<1)?1:n;
        outputText.setText("  ");
        boolean error = false;
        if(!(new File(cadena.readLine(1,inputText.getText())).exists())) error=true;
        if(!(new File(cadena.readLine(2,inputText.getText())).exists())) error=true;
        if(!error){
            try{
                String str_1="",str_2="";
                int natom=0;
                int Zout_1=1;
                int Zout_2=1;
                double xout_1=0,yout_1=0,zout_1=0;
                double xout_2=0,yout_2=0,zout_2=0;
                for(int i=0;i<=n;i++){
                    BufferedReader inbas_1,inbas_2;
                    inbas_1 = new BufferedReader(new FileReader(cadena.readLine(1,inputText.getText())));
                    inbas_2 = new BufferedReader(new FileReader(cadena.readLine(2,inputText.getText())));
                    str_1 = inbas_1.readLine(); //tomamos el numero de atomos de la primera
                    inbas_2.readLine();
                    natom =cadena.readColInt(1,str_1);
                    outputText.setText(outputText.getText()+"  "+natom+"\n");
                    for(int k=0;k<natom;k++){
                        str_1 = inbas_1.readLine();
                        str_2 = inbas_2.readLine();
                        try{
                            Zout_1=cadena.readColInt(1,str_1);
                            xout_1=cadena.readColDouble(2,str_1);
                            yout_1=cadena.readColDouble(3,str_1);
                            zout_1=cadena.readColDouble(4,str_1);
                            Zout_2=cadena.readColInt(1,str_2);
                            xout_2=cadena.readColDouble(2,str_2);
                            yout_2=cadena.readColDouble(3,str_2);
                            zout_2=cadena.readColDouble(4,str_2);
                        }catch(NumberFormatException ex){System.out.println("error read bas");}
                        //----------------------------------------
                        outputText.setText(outputText.getText()+"\n"+
                                cadena.format(4,periodicTable.getSymbol(Zout_1)) + cadena.formatFortran(2,12,6,i*(xout_2-xout_1)/n+xout_1) +
                                cadena.formatFortran(2,12,6,i*(yout_2-yout_1)/n+yout_1)+cadena.formatFortran(2,12,6,i*(zout_2-zout_1)/n+zout_1));
                    }
                    outputText.setText(outputText.getText()+"\n"); //que despilfarro !!!
                    inbas_1.close();
                    inbas_2.close(); // fatal
                }
            }catch (IOException oe) {System.out.println("error read basfile");}
        }
    }
    
    
    void saveFile(File auxFile){
        try {
            FileOutputStream archivo = new FileOutputStream(auxFile);
            DataOutputStream out = new DataOutputStream(archivo);
            out.writeBytes(outputText.getText());
            out.close();
            archivo.close();
        }catch (IOException oe) {System.out.println("error en editor: saveFile " );}
    }
    File fileChoose(String title,String boton, String file_ini){
        JFileChooser fc = new JFileChooser();
        fc.setName(title);
        if(new File(file_ini).exists()) fc.setSelectedFile(new File(file_ini));
        //fc.setSelectedFile(aux);
        int returnVal = fc.showDialog( calculadora_bas.this , boton);
        File auxfile = null;
        if(returnVal == JFileChooser.APPROVE_OPTION){
            auxfile = fc.getSelectedFile();
        }
        return auxfile;
    }
    
    
    
//-------------busqueda binaria
    
    double binario(int i,int i_ini, int i_fin,double  x_ini ,double x_fin){
        double dj = (x_ini+x_fin)*0.5; //esto lo cambiaremos pero seguira lo que hace j (busqueda binaria)
        int j=(i_ini+i_fin)/2;   //esto me da la por donde voy , el otro es ciego y carece de criterio
        if(i==i_ini)
            dj=x_ini;
        else{
            if(i==i_fin)
                dj=x_fin;
            else{
                if(i<j)dj=binario(i,i_ini,j,x_ini,dj);
                if(i>j)dj=binario(i,j,i_fin,dj,x_fin);
            }
        }
        return dj;
    }
    //------------- ejemplo de salida ------------------------
//0  0  4  0  41.930148825091486 -> 0.0
//1  0  4  0  41.930148825091486 -> 10.482537206272871
//2  0  4  0  41.930148825091486 -> 20.965074412545743
//3  0  4  0  41.930148825091486 -> 31.447611618818613
//4  0  4  0  41.930148825091486 -> 41.930148825091486
    
}
