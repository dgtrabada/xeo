/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */


package xeo;

import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.Vector;

public class editor extends javax.swing.JFrame {
    Font currentFont;
    Color currentColor;
    Vector texto = new Vector();
    String homefireball;
    /** Creates new form edit */
    public editor(String h,String path){
        initComponents();
        setTitle(path);
        homefireball=h;
        texto.clear();
        currentColor = Color.black;
        currentFont = new Font("Monospaced",Font.PLAIN,12);
        if((new File(homefireball+"iconos/open.gif")).exists()) open.setIcon(new ImageIcon(homefireball+"iconos/open.gif"));
        else open.setText("open") ;
        if((new File(homefireball+"iconos/save.gif")).exists()) save.setIcon(new ImageIcon(homefireball+"iconos/save.gif"));
        else save.setText("save") ;
        this.setVisible(true);
        
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Código Generado ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        open = new javax.swing.JMenu();
        save = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("editor");
        textArea.setColumns(20);
        textArea.setFont(new java.awt.Font("Monospaced", 0, 12));
        textArea.setRows(5);
        jScrollPane1.setViewportView(textArea);

        open.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/open.gif"));
        open.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                openMousePressed(evt);
            }
        });

        jMenuBar1.add(open);

        save.setIcon(new javax.swing.ImageIcon("/home/dani/Desktop/javaDani/fireball-GUI/iconos/save.gif"));
        save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                saveMousePressed(evt);
            }
        });

        jMenuBar1.add(save);

        setJMenuBar(jMenuBar1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void saveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveMousePressed
        File auxfile = fileChoose("save",new File(getTitle())) ;
        if(auxfile != null) saveFile(auxfile);
    }//GEN-LAST:event_saveMousePressed
    
    private void openMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_openMousePressed
        File auxfile = fileChoose("open", new File(getTitle())) ;
        if(auxfile != null) openFile(auxfile);
    }//GEN-LAST:event_openMousePressed
    
    
    // Declaración de variables - no modificar//GEN-BEGIN:variables
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu open;
    private javax.swing.JMenu save;
    private javax.swing.JTextArea textArea;
    // Fin de declaración de variables//GEN-END:variables
    
    File fileChoose(String title, File aux){
        JFileChooser fc = new JFileChooser();
        fc.setName(getTitle());
        fc.setSelectedFile(aux);
        int returnVal=fc.showDialog( editor.this , title);
        File auxfile = null;
        if(returnVal == JFileChooser.APPROVE_OPTION){
            auxfile = fc.getSelectedFile();
        }
        return auxfile;
    }
    
    void Load(Vector aux){
        textArea.setText("");
        for(int i=0;i<aux.size();i++) {
            textArea.append(aux.elementAt(i) + "\n");
        }
    }
    
    void Load(File name){
        setTitle(name.getAbsolutePath());
        textArea.setText("");
        for(int i=0;i<texto.size();i++) {
            textArea.append(texto.elementAt(i) + "\n");
        }
    }
    
    void Load(){
        textArea.setText("");
        for(int i=0;i<texto.size();i++) {
            textArea.append(texto.elementAt(i) + "\n");
        }
    }
    
    void openFile(File auxFile){
        if(auxFile.exists())
            try{
                FileReader inFile = new FileReader(auxFile);
                LineNumberReader inLines = new LineNumberReader(inFile);
                String inputLine="";
                textArea.setText("");
                setTitle(auxFile.getAbsolutePath());
                while ((inputLine=inLines.readLine()) != null) {
                    textArea.append(inputLine + "\n");
                }
                setTitle(auxFile.getAbsolutePath());
            }catch(Exception erx){System.out.println("error in editor : " + auxFile ); }
    }
    
    void saveFile(File auxFile){
        try {
            FileOutputStream archivo = new FileOutputStream(auxFile);
            DataOutputStream out = new DataOutputStream(archivo);
            out.writeBytes(textArea.getText());
            out.close();
            archivo.close();
        }catch (IOException oe) {System.out.println("error en editor: saveFile " );}
    }
/*
Copyright 2007  by Daniel Gonzalez Trabada
This editor is part of fireball-GUI.
fireball-GUI is free software; you can
redistribute it and/or modify it under
the terms of the GNU General Public License
as published by the Free Software Foundation;
either version 2 of the License,
or (at your option) any later version.
fireball-GUI is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.
You should have received a copy of the GNU
General Public License along with fireball-GUI;
if not, write to the Free Software Foundation,
Inc., 51 Franklin St, Fifth Floor, Boston, MA
02110-1301  USAinformacion
 */
}
