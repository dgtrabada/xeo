/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */

package xeo;

import java.io.*;
import java.util.ArrayList;
import java.util.Vector;

public class read_abinit {
    ArrayList<atom> bas;
    reader cadena = new reader();
    double [][] lvs = new double[3][3];
    double res;
    periodicTable  periodicTable = new  periodicTable();
    boolean Error;
    String Error_out;
    File inAB;
    //---------------
    double acellx,acelly,acellz;
    int natoms;
    int ndtset=0;
    int ntypat;
    String typat;
    String znucl;
    String acell;
    /** Creates a new instance of read_abinit */
    public read_abinit() {
        bas = new ArrayList();
    }
    //---read----
    void Load(File infile){
        if(infile.exists()){
            inAB=infile;
            read_ndtset();
            read_ntypat();
            read_typat();
            read_natoms();
            read_acell();
            read_rprim();
            bas.clear();
            read_xcart();
            read_xangst();
            read_znucl();
            
            pasar_datos_babel();
            
        }
    }
    String str="";
    
    
    void read_ndtset(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("ndtset")) {
                    ndtset=cadena.readColInt(2,str);
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read ntypat");}
        if(ndtset>1)  Error_out="ndtset > 1 it not suported for the moment ";
    }
    
    void read_ntypat(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("ntypat")) {
                    ntypat=cadena.readColInt(2,str);
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read ntypat");}
    }
    
    void read_typat(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("typat")) {
                    natoms=cadena.nCol(readAb(str))-1;
                    typat=readAb(str);
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read typat");}
    }
    
    void read_znucl(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("znucl")) znucl=readAb(str);
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read znucl");}
    }
    
    void read_natoms(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("natoms")) {
                    natoms=cadena.readColInt(2,str);
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read natoms");}
    }
    
    void read_acell(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("acell")){
                    acell=readAb(str);
                    acellx=cadena.readColDouble(2,acell);
                    acelly=cadena.readColDouble(3,acell);
                    acellz=cadena.readColDouble(4,acell);
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read acell");}
    }
    
    void read_rprim(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("rprim")){
                    lvs[0][0] = cadena.readColDouble(2,str);
                    lvs[1][0] = cadena.readColDouble(3,str);
                    lvs[2][0] = cadena.readColDouble(4,str);
                    lvs[0][1] = cadena.readColDouble(5,str);
                    lvs[1][1] = cadena.readColDouble(6,str);
                    lvs[2][1] = cadena.readColDouble(7,str);
                    lvs[0][2] = cadena.readColDouble(8,str);
                    lvs[1][2] = cadena.readColDouble(9,str);
                    lvs[2][2] = cadena.readColDouble(10,str);
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read rprim");}
    }
    
    
    void read_xcart(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            int ab=0;
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("xcart")){
                    for(int i=0;i<natoms;i++){
                        if(i==0){
                            if(cadena.nCol(str)>3) ab=1;
                            else str = in.readLine();
                        }
                        atom atom = new atom();
                        atom.posBas=i;
                        atom.posOut=i;
                        atom.R[0]=cadena.readColDouble(1+ab,str)*0.5291772108;
                        atom.R[1]=cadena.readColDouble(2+ab,str)*0.5291772108;
                        atom.R[2]=cadena.readColDouble(3+ab,str)*0.5291772108;
                        bas.add(atom);
                        str = in.readLine();
                        ab=0;
                    }
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read xcart");}
    }
    
    void read_xangst(){
        try{
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            int ab=0;
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("xangst")){
                    for(int i=0;i<natoms;i++){
                        if(i==0){
                            if(cadena.nCol(str)>3) ab=1;
                            else str = in.readLine();
                        }
                        atom atom = new atom();
                        atom.posBas=i;
                        atom.posOut=i;
                        atom.R[0]=cadena.readColDouble(1+ab,str);
                        atom.R[1]=cadena.readColDouble(2+ab,str);
                        atom.R[2]=cadena.readColDouble(3+ab,str);
                        bas.add(atom);
                        str = in.readLine();
                        ab=0;
                    }
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read xangst");}
    }
    
    void read_xred(){
        try{
            //t_cartesian = t1*r1*a1+t2*r2*a2+t3*r3*a3
            bas.clear();
            BufferedReader in = new BufferedReader(new FileReader(inAB.getAbsolutePath()));
            int ab=0;
            while ((str = in.readLine()) != null){
                if(cadena.readColString(1,str).equals("xcart")){
                    for(int i=0;i<natoms;i++){
                        if(i==0){
                            if(cadena.nCol(str)>3) ab=1;
                            else str = in.readLine();
                        }
                        atom atom = new atom();
                        atom.posBas=i;
                        atom.posOut=i;
                        atom.R[0]=cadena.readColDouble(1+ab,str);
                        atom.R[1]=cadena.readColDouble(2+ab,str);
                        atom.R[2]=cadena.readColDouble(3+ab,str);
                        bas.add(atom);
                        str = in.readLine();
                        ab=0;
                    }
                }
            }
            in.close();
        }catch (IOException oe) {System.out.println("error read xcart");}
    }
    
    void pasar_datos_babel(){
        Error=false;
        if(Error) Error_out="we can't read abinit files, we are working on";
        else{
            for(int i=0;i<natoms;i++){
                bas.get(i).Z=cadena.readColInt(cadena.readColInt(i+1,typat),znucl);
                bas.get(i).symbol=periodicTable.getSymbol(bas.get(i).Z);
            }
        }
    }
    
    
    String readAb(String input){
        String aux="",ahux="";
        for(int i=1;i<=cadena.nCol(input);i++){
            ahux=cadena.readColString(i,input);
            if(cadena.startInNumber(ahux)){
                if(!cadena.contiene(ahux,"*")){
                    aux+=ahux+" ";
                }else{
                    for(int j=0;j<(int) Double.valueOf(cadena.readColStringSEP(1,ahux,"*")).doubleValue();j++)
                        aux+=cadena.readColStringSEP(2,ahux,"*")+" ";
                }
            }
        }
        return aux;
    }
    
}
