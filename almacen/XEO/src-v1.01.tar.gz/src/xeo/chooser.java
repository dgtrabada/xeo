/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */


package xeo;

import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.*;

public class chooser extends javax.swing.JFrame {
    
    public chooser() {
        initComponents();
    }
    
    
    // <editor-fold defaultstate="collapsed" desc=" Código Generado ">//GEN-BEGIN:initComponents
    private void initComponents() {

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 300, Short.MAX_VALUE)
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    void savePicture(String title,String boton, String file,BufferedImage  Buff){
        JFileChooser fc = new JFileChooser();
        fc.setName(title);
        fc.setSelectedFile(new File(file.substring(0,file.length()-4)+".jpg"));
        int returnVal = fc.showDialog( this , boton);
        File auxfile = null;
        if(returnVal == JFileChooser.APPROVE_OPTION){
            auxfile = fc.getSelectedFile();
        }
        if(auxfile!=null)
            try {
                ImageIO.write( Buff  ,"JPG" ,auxfile);
            }catch (IOException e) {System.out.println("errors save image");}
    }
    
    
    
    File fileChoose(String title,String boton, String file_ini){
        JFileChooser fc = new JFileChooser();
        fc.setName(title);
        if(new File(file_ini).exists()) fc.setSelectedFile(new File(file_ini));
        //fc.setSelectedFile(aux);
        int returnVal = fc.showDialog(this , boton);
        File auxfile = null;
        if(returnVal == JFileChooser.APPROVE_OPTION){
            auxfile = fc.getSelectedFile();
        }
        return auxfile;
    }
    
    File ProjectChoose(String title,String boton, File aux, String path){
        JFileChooser fc = new JFileChooser();
        fc.setName(title);
        if(new File(path).exists()) fc.setSelectedFile(new File(path));
        int returnVal = fc.showDialog( this , boton);
        File auxfile = null;
        if(returnVal == JFileChooser.APPROVE_OPTION){
            auxfile = fc.getSelectedFile();
        }
        return auxfile;
    }
    
    
    // Declaración de variables - no modificar//GEN-BEGIN:variables
    // Fin de declaración de variables//GEN-END:variables
    
}
