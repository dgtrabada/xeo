/*
 * Copyright 2008 by Daniel González Trabada
 *
 *  This file is part of xeo.
 *
 *  xeo is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software Foundation;
 *  either version 2 of the License, or (at your option) any later version.
 *
 *  xeo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with xeo;
 *  if not, write to the Free Software Foundation,
 *  Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
 */
package xeo;

import java.io.*;
import java.util.ArrayList;
import java.util.Vector;

public class read_castep {
    reader cadena = new reader();
    ArrayList<atom> bas;
    double [][] lvs = new double[3][3];
    double res;
    periodicTable  periodicTable = new  periodicTable();
    boolean Error;
    String Error_out;
    /** Creates a new instance of castep */
    public read_castep() {
        bas = new ArrayList();
        res=1;
    }
    
    
    
//-----------------------------------------------------------------------------
//-----------------  CASTEP ---------------------------------------------------
//-----------------------------------------------------------------------------
    
    void LoadCell(File cellfile){
        if(cellfile.exists()){
            try{
                int il=1;
                String str="";
                bas.clear();
                BufferedReader inCell = new BufferedReader(new FileReader(cellfile.getAbsolutePath()));
                while ((str = inCell.readLine()) != null){
                    if(cadena.readColString(2,str).equals("POSITIONS_ABS")){
                        str = inCell.readLine();
                        while (!cadena.readColString(2,str).equals("POSITIONS_ABS")){
                            atom atom = new atom();
                            atom.posBas=il;
                            atom.posOut=il;
                            atom.Z=cadena.readColInt(1,str);
                            atom.R[0]=cadena.readColDouble(2,str);
                            atom.R[1]=cadena.readColDouble(3,str);
                            atom.R[2]=cadena.readColDouble(4,str);
                            atom.symbol=periodicTable.getSymbol(atom.Z);
                            bas.add(atom);
                            il++;
                            str = inCell.readLine();
                        }
                    }
                    if(cadena.readColString(2,str).equals("LATTICE_CART")){
                        for(int i=0;i<3;i++){
                            str = inCell.readLine();
                            lvs[i][0] = cadena.readColDouble(1,str);
                            lvs[i][1] = cadena.readColDouble(2,str);
                            lvs[i][2] = cadena.readColDouble(3,str);
                        }
                        str = inCell.readLine();
                    }
                    
                    if(cadena.readColString(2,str).equals("IONIC_CONSTRAINTS")){
                        str = inCell.readLine();
                        while (!cadena.readColString(2,str).equals("IONIC_CONSTRAINTS")){
                            int n=0;
                            for(int h=0;h<bas.size();h++){
                                if( periodicTable.getZ(cadena.readColString(2,str))
                                == bas.get(h).Z ){
                                    n++;
                                    if (n == cadena.readColInt(3,str)){
                                        bas.get(h).fix=true;
                                    }
                                }
                            }
                            str = inCell.readLine();
                        }
                    }
                }
                inCell.close();
                Error=false;
                if(il==1) {
                    Error=true; //System.out.println("error read CASTEP ");
                    Error_out="only read the position of atoms with the format POSITIONS_ABS";
                }
            }catch (IOException oe) {System.out.println("error read .cell");}
        }
    }
    //------ output -----
    Vector CastepCell(){
        Vector aux = new Vector();
        aux.add("%block LATTICE_CART ! In Angstroms");
        aux.add("    "+cadena.formatFortran(2,14,6,lvs[0][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[0][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[0][2]*res));
        aux.add("    "+cadena.formatFortran(2,14,6,lvs[1][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[1][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[1][2]*res));
        aux.add("    "+cadena.formatFortran(2,14,6,lvs[2][0]*res)+"    "+cadena.formatFortran(2,14,6,lvs[2][1]*res)+"    "+cadena.formatFortran(2,14,6,lvs[2][2]*res));
        aux.add("%endblock LATTICE_CART"+"\n");
        aux.add("%block POSITIONS_ABS");
        for(int i=0;i<bas.size();i++)
            aux.add(cadena.format(4,bas.get(i).Z )
            +cadena.formatFortran(2,14,6,bas.get(i).R[0]*res)
            +cadena.formatFortran(2,14,6,bas.get(i).R[1]*res)
            +cadena.formatFortran(2,14,6,bas.get(i).R[2]*res)) ;
        aux.add("%endblock POSITIONS_ABS");
        aux.add( "\n"+"%BLOCK IONIC_CONSTRAINTS" );
        int g=0;
        Vector aF = new Vector();
        for(int i=0;i<bas.size();i++) {
            int pF=1;
            boolean first_time=true;
            for(int h=0;h<aF.size();h++){
                if(cadena.readColInt(1,aF.get(h).toString())== ((atom) bas.get(i)).Z) {
                    first_time=false;
                    pF=cadena.readColInt(2,aF.get(h).toString());
                    pF++;
                    aF.remove(h);
                    aF.add(((atom) bas.get(i)).Z+" "+pF);
                }
            }
            if(first_time) aF.add(((atom) bas.get(i)).Z+" 1");
            if(((atom) bas.get(i)).fix ){ //lo de selec :)
                g++;
                aux.add(g+"     "+periodicTable.getSymbol(((atom) bas.get(i)).Z)+"  "+pF+"    1 0 0");
                g++;
                aux.add(g+"     "+periodicTable.getSymbol(((atom) bas.get(i)).Z)+"  "+pF+"    0 1 0");
                g++;
                aux.add(g+"     "+periodicTable.getSymbol(((atom) bas.get(i)).Z)+"  "+pF+"    0 0 1");
            }
        }
        aux.add("%ENDBLOCK IONIC_CONSTRAINTS");
        return aux;
    }
    
    Vector savePos(File cellfile){
        Vector aux = new Vector();
        String str="";
        boolean cont=true;
        try{
            BufferedReader inCell = new BufferedReader(new FileReader(cellfile.getAbsolutePath()));
            while (cont){
                str = inCell.readLine();
                if(cadena.readColString(2,str).equals("POSITIONS_ABS")) cont=false;
                else aux.add(str);
            }
            aux.add(str);
            for(int i=0;i<bas.size();i++)
                aux.add(cadena.format(4,bas.get(i).Z )
                +cadena.formatFortran(2,14,6,bas.get(i).R[0]*res)
                +cadena.formatFortran(2,14,6,bas.get(i).R[1]*res)
                +cadena.formatFortran(2,14,6,bas.get(i).R[2]*res)) ;
            cont=true;
            while (cont){
                str = inCell.readLine();
                if(cadena.readColString(2,str).equals("POSITIONS_ABS")) cont=false;
            }
            aux.add(str);
            while ((str = inCell.readLine()) != null){
                aux.add(str);
            }
        }catch (IOException oe) {System.out.println("error read .cell");}
        
        return aux;
    }
    
    
    Vector savefix(File cellfile){
        Vector aux = new Vector();
        String str="";
        boolean cont=true;
        try{
            BufferedReader inCell = new BufferedReader(new FileReader(cellfile.getAbsolutePath()));
            while (cont){
                str = inCell.readLine();
                if(cadena.readColString(2,str).trim().equals("IONIC_CONSTRAINTS")) cont=false;
                else aux.add(str);
            }
            aux.add(str);
            int g=0,pF=0;
            for(int i=0;i<bas.size();i++) {
                if(((atom) bas.get(i)).selec ){ //lo de selec :)
                    int k=0;
                    for(int j=0;j<bas.get(i).posBas;j++)
                        if(bas.get(j).Z==bas.get(i).Z) k++;
                    g++;
                    aux.add(g+"     "+periodicTable.getSymbol(bas.get(i).Z)+"  "+k+"    1 0 0");
                    g++;
                    aux.add(g+"     "+periodicTable.getSymbol(bas.get(i).Z)+"  "+k+"    0 1 0");
                    g++;
                    aux.add(g+"     "+periodicTable.getSymbol(bas.get(i).Z)+"  "+k+"    0 0 1");
                }
            }
            cont=true;
            while (cont){
                str = inCell.readLine();
                if(cadena.readColString(2,str).equals("IONIC_CONSTRAINTS")) cont=false;
            }
            aux.add(str);
            while ((str = inCell.readLine()) != null){
                aux.add(str);
            }
        }catch (IOException oe) {System.out.println("error read .cell");}
        
        return aux;
    }
    
}


