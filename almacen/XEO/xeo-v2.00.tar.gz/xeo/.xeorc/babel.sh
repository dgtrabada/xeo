here=$1

babel -H  > ${here}/babel.temp

