cd src/ ; ./configure ; cd .. ;java -jar xeoBabel.jar -i xeo example.xeo -o more example.xyz 
 cat example.xyz 

